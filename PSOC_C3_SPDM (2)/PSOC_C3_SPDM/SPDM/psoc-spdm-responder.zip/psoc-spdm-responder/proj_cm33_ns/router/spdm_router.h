/*****************************************************************************
 * File Name        : spdm_router.h
 *
 * Description      : Public interface for the non-secure SPDM command router.
 *                    The router is registered with the DFU middleware as a
 *                    user-defined command handler; it decodes the SPDM transfer
 *                    opcode (0x80), stages the inbound MCTP-framed SPDM request
 *                    into the carrier bridge (spdm_transport_dfu), drives the
 *                    libspdm responder dispatch, and returns the produced
 *                    response to the host.
 *
 *                    The module also owns the DFU command/response service loop
 *                    (spdm_router_run), so main.c only performs board / DFU /
 *                    transport bring-up and then hands control to the router.
 *
 *                    Stage 5 wires the transport carrier: opcode 0x80 stages the
 *                    request and returns a single-byte "responder not ready"
 *                    status. The libspdm responder context and dispatch (which
 *                    replace the placeholder with the real MCTP-framed SPDM
 *                    response) are added in Stage 6.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef SPDM_ROUTER_H
#define SPDM_ROUTER_H

#include <stdint.h>

#include "cy_dfu.h"

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Macros
 *****************************************************************************/

/* Timeout for a single Cy_DFU_Continue() iteration, in milliseconds. Used by
 * the service loop and by main.c to seed cy_stc_dfu_params_t.timeout so both
 * agree on the per-iteration tick used for the command/LED timers. */
#define SPDM_ROUTER_SESSION_TIMEOUT_MS  (20U)

/******************************************************************************
 * Enumerations
 *****************************************************************************/

/**
 * DFU user-defined command opcodes serviced by the SPDM router. The SPDM
 * binding uses a single opcode that carries one MCTP-framed SPDM transport
 * message (request in, response out); the DFU command ID is the opcode. It
 * lives in the DFU user-defined command space (0x80 is reserved here for SPDM,
 * clear of the provisioning app's 0x50-0x7F range).
 */
typedef enum
{
    SPDM_CMD_TRANSFER = 0x80U    /* MCTP-framed SPDM request/response transfer */
} spdm_opcode_t;

/**
 * Stage-5 placeholder status returned as the single response byte of an SPDM
 * transfer while the responder context is not yet initialized. In Stage 6 the
 * response payload becomes the raw MCTP-framed SPDM response produced by
 * libspdm, and these codes are no longer emitted.
 */
typedef enum
{
    SPDM_XFER_OK        = 0x00U, /* reserved for Stage 6 (real SPDM response) */
    SPDM_XFER_NOT_READY = 0x01U, /* responder context not yet initialized      */
    SPDM_XFER_BAD_LEN   = 0x02U  /* request empty or larger than the carrier   */
} spdm_xfer_status_t;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Register the SPDM command router with the DFU middleware.
 *
 * Installs the router as the DFU user-command handler so that the SPDM transfer
 * opcode (0x80) is dispatched to the carrier bridge / libspdm responder.
 *
 * @param dfu_params  Initialized DFU parameters structure.
 *
 * @return CY_DFU_SUCCESS on success, otherwise a DFU error code.
 */
cy_en_dfu_status_t spdm_router_register(cy_stc_dfu_params_t *dfu_params);

/**
 * @brief Run the DFU command/response service loop (does not return).
 *
 * Repeatedly calls Cy_DFU_Continue() and keeps the responder available: SPDM
 * rides on DFU user-defined commands, so a finished/failed/timed-out session is
 * transparently re-armed (re-init + re-register + transport reset + carrier
 * reset) and the heartbeat LED is toggled while idle.
 *
 * @param dfu_params  Initialized DFU parameters structure (its .timeout must be
 *                    SPDM_ROUTER_SESSION_TIMEOUT_MS).
 * @param dfu_state   DFU state variable, seeded by Cy_DFU_Init().
 */
void spdm_router_run(cy_stc_dfu_params_t *dfu_params, uint32_t *dfu_state);

#if defined(__cplusplus)
}
#endif

#endif /* SPDM_ROUTER_H */

/* [] END OF FILE */
