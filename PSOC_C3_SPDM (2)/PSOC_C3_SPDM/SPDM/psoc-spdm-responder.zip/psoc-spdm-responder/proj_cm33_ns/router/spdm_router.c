/*****************************************************************************
 * File Name        : spdm_router.c
 *
 * Description      : Non-secure SPDM command router. Registered with the DFU
 *                    middleware as the user-defined command handler and owns the
 *                    DFU command/response service loop. See spdm_router.h.
 *
 *                    The SPDM transfer opcode stages the inbound MCTP-framed
 *                    request into the carrier bridge, runs one libspdm responder
 *                    dispatch (spdm_responder.c) that consumes the request and
 *                    produces the MCTP-framed response through the carrier
 *                    device-I/O callbacks, then copies that response back into
 *                    the DFU reply.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>

#include "cybsp.h"
#include "cy_pdl.h"

#include "spdm_router.h"
#include "spdm_transport_dfu.h"
#include "spdm_responder.h"
#include "log/log.h"

/******************************************************************************
 * Macros
 *****************************************************************************/

/* LED blink period in milliseconds (idle heartbeat). */
#define BLINKY_LED_DELAY_MSEC       (500U)

/* No command received within this window restarts the DFU session. */
#define DFU_COMMAND_TIMEOUT_MS      (5000U)

/******************************************************************************
 * Local Function Prototypes
 *****************************************************************************/

static cy_en_dfu_status_t spdm_router_handle_command(uint32_t command, uint8_t *packetData,
                                                     uint32_t dataSize, uint32_t *rspSize,
                                                     struct cy_stc_dfu_params_s *params,
                                                     bool *noResponse);

static cy_en_dfu_status_t spdm_router_handle_transfer(uint8_t *pd, uint32_t dataSize,
                                                      uint32_t *rspSize);

/* Re-arm the DFU session and the SPDM carrier after a finished/failed/timed-out
 * transaction so the responder stays available for the next request. */
static void spdm_router_rearm(cy_stc_dfu_params_t *dfu_params, uint32_t *dfu_state);

/******************************************************************************
 * Public Functions
 *****************************************************************************/

cy_en_dfu_status_t spdm_router_register(cy_stc_dfu_params_t *dfu_params)
{
    return Cy_DFU_RegisterUserCommand(dfu_params, spdm_router_handle_command);
}

void spdm_router_run(cy_stc_dfu_params_t *dfu_params, uint32_t *dfu_state)
{
    cy_en_dfu_status_t dfu_status;
    uint32_t count = 0U;
    uint32_t tick  = (dfu_params->timeout != 0U) ? dfu_params->timeout
                                                  : SPDM_ROUTER_SESSION_TIMEOUT_MS;

    for (;;)
    {
        dfu_status = Cy_DFU_Continue(dfu_state, dfu_params);
        count++;

        if (*dfu_state == CY_DFU_STATE_FINISHED)
        {
            /* SPDM rides on user-defined commands; reset the session so the
             * device stays available for the next transaction. */
            LOG_INFO("DFU session finished; restarting session");
            spdm_router_rearm(dfu_params, dfu_state);
            count = 0U;
        }
        else if (*dfu_state == CY_DFU_STATE_FAILED)
        {
            LOG_ERR("DFU session failed: 0x%X; restarting session", (unsigned int)dfu_status);
            spdm_router_rearm(dfu_params, dfu_state);
            count = 0U;
        }
        else if (*dfu_state == CY_DFU_STATE_UPDATING)
        {
            if ((dfu_status == CY_DFU_ERROR_TIMEOUT) &&
                (count >= (DFU_COMMAND_TIMEOUT_MS / tick)))
            {
                /* No command received recently; restart the DFU session. */
                LOG_WARN("Command timeout; restarting session");
                spdm_router_rearm(dfu_params, dfu_state);
                count = 0U;
            }
            else if (dfu_status == CY_DFU_SUCCESS)
            {
                count = 0U;
            }
            else
            {
                /* Other transient errors: keep servicing the session. */
            }
        }
        else
        {
            /* CY_DFU_STATE_NONE: idle. Toggle the heartbeat LED. */
            if (count >= (BLINKY_LED_DELAY_MSEC / tick))
            {
                Cy_GPIO_Inv(CYBSP_USER_LED_PORT, CYBSP_USER_LED_PIN);
                count = 0U;
            }
        }
    }
}

/******************************************************************************
 * Local Functions
 *****************************************************************************/

static void spdm_router_rearm(cy_stc_dfu_params_t *dfu_params, uint32_t *dfu_state)
{
    spdm_transport_dfu_reset();
    (void)Cy_DFU_Init(dfu_state, dfu_params);
    (void)spdm_router_register(dfu_params);
    Cy_DFU_TransportReset();
}

/*******************************************************************************
 * Function Name: spdm_router_handle_command
 ********************************************************************************
 * Summary:
 *  DFU user-defined command handler (Cy_DFU_CustomCommandHandler). Decodes the
 *  opcode and dispatches to the matching handler. The DFU-level status is the
 *  function return value; the response payload is opcode-specific.
 *
 *******************************************************************************/
static cy_en_dfu_status_t spdm_router_handle_command(uint32_t command, uint8_t *packetData,
                                                     uint32_t dataSize, uint32_t *rspSize,
                                                     struct cy_stc_dfu_params_s *params,
                                                     bool *noResponse)
{
    cy_en_dfu_status_t status;

    CY_UNUSED_PARAMETER(params);

    /* The SPDM transfer always sends a response packet. */
    *noResponse = false;
    *rspSize = 0U;

    LOG_INFO("Command 0x%02X received (dataSize=%u)",
             (unsigned int)command, (unsigned int)dataSize);

    switch ((spdm_opcode_t)command)
    {
        case SPDM_CMD_TRANSFER:
            status = spdm_router_handle_transfer(packetData, dataSize, rspSize);
            break;

        default:
            /* Not an SPDM opcode; let the DFU core report an error. */
            LOG_WARN("Unknown opcode 0x%02X; rejecting", (unsigned int)command);
            status = CY_DFU_ERROR_CMD;
            break;
    }

    LOG_DBG("Command 0x%02X handled: status=0x%X, rspSize=%u",
            (unsigned int)command, (unsigned int)status, (unsigned int)*rspSize);

    return status;
}

/*******************************************************************************
 * Function Name: spdm_router_handle_transfer  (SPDM_CMD_TRANSFER / 0x80)
 ********************************************************************************
 * Request : MCTP-framed SPDM request (1-byte MCTP type + SPDM message bytes).
 * Response: MCTP-framed SPDM response, or a single-byte carrier status.
 *
 * Stage the inbound request into the carrier bridge, run one libspdm responder
 * dispatch that pulls the request and pushes the framed response back into the
 * bridge, then copy that response into the DFU reply. If the dispatch produces
 * no response (an error, or a silently-dropped request) the handler returns a
 * single-byte SPDM_XFER_NOT_READY status so the host does not block; the staged
 * request is left in the bridge and cleared at the next session re-arm.
 *******************************************************************************/
static cy_en_dfu_status_t spdm_router_handle_transfer(uint8_t *pd, uint32_t dataSize,
                                                      uint32_t *rspSize)
{
    libspdm_return_t status;
    size_t rsp_len = 0U;

    if (dataSize == 0U)
    {
        pd[0] = (uint8_t)SPDM_XFER_BAD_LEN;
        *rspSize = 1U;
        LOG_WARN("SPDM transfer: empty request");
        return CY_DFU_SUCCESS;
    }

    if (!spdm_transport_dfu_stage_request(pd, (size_t)dataSize))
    {
        pd[0] = (uint8_t)SPDM_XFER_BAD_LEN;
        *rspSize = 1U;
        LOG_ERR("SPDM transfer too large (%u B); rejecting", (unsigned int)dataSize);
        return CY_DFU_SUCCESS;
    }

    /* One responder dispatch consumes the staged request and produces the
     * MCTP-framed response through the carrier device-I/O callbacks. */
    status = spdm_responder_dispatch();

    if (LIBSPDM_STATUS_IS_SUCCESS(status) &&
        spdm_transport_dfu_take_response(pd, (size_t)SPDM_DFU_TRANSPORT_MSG_SIZE, &rsp_len))
    {
        *rspSize = (uint32_t)rsp_len;
        LOG_DBG("SPDM transfer: response %u B", (unsigned int)rsp_len);
        return CY_DFU_SUCCESS;
    }

    /* No response produced (error or silently-dropped request). */
    pd[0] = (uint8_t)SPDM_XFER_NOT_READY;
    *rspSize = 1U;
    LOG_WARN("SPDM transfer: no response (dispatch=0x%X)", (unsigned int)status);
    return CY_DFU_SUCCESS;
}

/* [] END OF FILE */
