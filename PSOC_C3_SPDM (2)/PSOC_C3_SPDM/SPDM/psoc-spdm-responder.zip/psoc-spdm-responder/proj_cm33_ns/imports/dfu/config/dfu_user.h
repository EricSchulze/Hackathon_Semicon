/***************************************************************************//**
* \file dfu_user.h
*
* This file provides declarations that can be modified by the user but
* are used by the DFU SDK.
*
********************************************************************************
* \copyright
* (c) (2016-2026), Infineon Technologies AG, or an affiliate of Infineon
* Technologies AG. All rights reserved.
********************************************************************************
* This software, associated documentation and materials ("Software") is
* owned by Infineon Technologies AG or one of its affiliates ("Infineon")
* and is protected by and subject to worldwide patent protection, worldwide
* copyright laws, and international treaty provisions. Therefore, you may use
* this Software only as provided in the license agreement accompanying the
* software package from which you obtained this Software. If no license
* agreement applies, then any use, reproduction, modification, translation, or
* compilation of this Software is prohibited without the express written
* permission of Infineon.
*
* Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
* IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
* THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
* SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
* Infineon reserves the right to make changes to the Software without notice.
* You are responsible for properly designing, programming, and testing the
* functionality and safety of your intended application of the Software, as
* well as complying with any legal requirements related to its use. Infineon
* does not guarantee that the Software will be free from intrusion, data theft
* or loss, or other breaches ("Security Breaches"), and Infineon shall have
* no liability arising out of any Security Breaches. Unless otherwise
* explicitly approved by Infineon, the Software may not be used in any
* application where a failure of the Product or any consequences of the use
* thereof can reasonably be expected to result in personal injury.
*******************************************************************************/

#if !defined(DFU_USER_H)
#define DFU_USER_H

#include <stdint.h> //Check if could be removed
#include "cy_device_headers.h"

#ifdef CY_IP_MXS40FLASHC   /* Needed for device with internal flash present */
    #include "cy_flash.h"
#endif /* CY_IP_MXS40FLASHC */

#if defined(__cplusplus)
extern "C" {
#endif


/**
* \addtogroup group_dfu_macro_config
* \{
*/

#ifndef CY_DFU_LOG_LEVEL
    #define CY_DFU_LOG_LEVEL CY_DFU_LOG_LEVEL_OFF /**< Defines log level */
#endif

#define CY_DFU_BASIC_FLOW               (0U) /**< (NOT SUPPORTED) Basic Bootloader flow includes
                                              * application transfer and bootload. */
#define CY_DFU_MCUBOOT_FLOW             (1U) /**< MCUBoot compatibility flow includes
                                              * only application transport. */

/**
 * Configuration option to select DFU flow. CY_DFU_MCUBOOT_FLOW is only one possible option
 */
#ifndef CY_DFU_FLOW
    #if defined COMPONENT_CAT1A || defined COMPONENT_CAT2
        #define CY_DFU_FLOW                     (CY_DFU_BASIC_FLOW)
    #else
        #define CY_DFU_FLOW                     (CY_DFU_MCUBOOT_FLOW)
    #endif
#endif /* CY_DFU_FLOW */

/** Define program row size of the Non-Volatile memory */
#ifndef CY_NVM_SIZEOF_ROW
    #ifdef  CY_FLASH_SIZEOF_ROW
        #define CY_NVM_SIZEOF_ROW       CY_FLASH_SIZEOF_ROW
    #else
        #define CY_NVM_SIZEOF_ROW       (512U)
    #endif /* CY_FLASH_SIZEOF_ROW */
#endif /* CY_NVM_SIZEOF_ROW */

/** The size of a buffer to hold DFU commands */
/* 16 bytes is a maximum overhead of a DFU packet and additional data for the Program Data command */
#define CY_DFU_SIZEOF_CMD_BUFFER  (CY_NVM_SIZEOF_ROW + 16U)

/** The size of a buffer to hold an NVM row of data to write or verify */
#define CY_DFU_SIZEOF_DATA_BUFFER (CY_NVM_SIZEOF_ROW + 16U)

/** A non-zero value enables the Verify Data DFU command  */
#ifndef CY_DFU_OPT_VERIFY_DATA
    #define CY_DFU_OPT_VERIFY_DATA     (1)
#endif /* CY_DFU_OPT_VERIFY_DATA */

/** A non-zero value enables the Erase Data DFU command   */
#ifndef CY_DFU_OPT_ERASE_DATA
    #define CY_DFU_OPT_ERASE_DATA      (1)
#endif /* CY_DFU_OPT_ERASE_DATA */

/** A non-zero value enables the Verify App DFU command   */
#ifndef CY_DFU_OPT_VERIFY_APP
    #define CY_DFU_OPT_VERIFY_APP      (1)
#endif /* CY_DFU_OPT_VERIFY_APP */

/**
* A non-zero value enables the Send Data DFU command.
* If the "Send Data" DFU command is enabled, \c packetBuffer and \c dataBuffer
* must be non-overlapping.
*
* Else, \c dataBuffer must be inside \c packetBuffer with an offset of
* \c CY_DFU_PACKET_DATA_IDX, typically 4 bytes. \n
* <code>params->dataBuffer = &packetBuffer[4];</code> \n
* \note that \c packetBuffer in this case must be 4 bytes aligned, as
* \c dataBuffer is required to be 4 bytes aligned.
*/

#ifndef CY_DFU_OPT_SEND_DATA
    #define CY_DFU_OPT_SEND_DATA       (1)
#endif /* CY_DFU_OPT_SEND_DATA */

/** A non-zero value enables the usage of CRC-16 for DFU packet verification */
#ifndef CY_DFU_OPT_PACKET_CRC
    #define CY_DFU_OPT_PACKET_CRC      (0)
#endif /* CY_DFU_OPT_PACKET_CRC */

/** A non-zero value enables the user custom command support */
#ifndef CY_DFU_OPT_CUSTOM_CMD
    #define CY_DFU_OPT_CUSTOM_CMD      (0)
#endif /* CY_DFU_OPT_CUSTOM_CMD */

#if CY_DFU_OPT_CUSTOM_CMD != 0
    #ifndef CY_DFU_USER_CMD_LAST
        #define CY_DFU_USER_CMD_LAST  (CY_DFU_USER_CMD_END) /**< The last user command ID */
    #endif /* CY_DFU_USER_CMD_LAST */
#endif //* CY_DFU_OPT_CUSTOM_CMD != 0 */

/**
* The number of applications in the metadata,
* for 512 bytes in a flash row - 63 is the maximum possible value,
* because 4 bytes are reserved for the entire metadata CRC.
*
* The smallest metadata size if CY_DFU_MAX_APPS * 8 (bytes per one app) + 4 (bytes for CRC-32C)
*/
#ifndef CY_DFU_MAX_APPS
    #define CY_DFU_MAX_APPS            (2U)
#endif /* CY_DFU_MAX_APPS */

/** The timeout for the default Cy_DFU_TransportWrite() call in milliseconds */
#ifndef CY_DFU_TRANSPORT_WRITE_TIMEOUT
    #define CY_DFU_TRANSPORT_WRITE_TIMEOUT             (150U)
#endif /* CY_DFU_TRANSPORT_WRITE_TIMEOUT */

/* MCUBoot compatibility flow specific constants */
#if (CY_DFU_FLOW == CY_DFU_MCUBOOT_FLOW) && !defined(CY_DOXYGEN)
    #if !defined CY_DFU_PRODUCT
        #define CY_DFU_PRODUCT          (0x01020304)  /**< Default value for Product ID*/
        #warning "CY_DFU_PRODUCT is set to default value"
    #endif /* !defined CY_DFU_PRODUCT */

    /** A non-zero value enables usage of external memory for placement of the App */
    #ifndef CY_DFU_OPT_EXTERNAL_MEMORY
        #ifndef CY_IP_MXS40FLASHC
            #define CY_DFU_OPT_EXTERNAL_MEMORY (1U)
        #else
            #define CY_DFU_OPT_EXTERNAL_MEMORY (0U)
        #endif
    #endif /* CY_DFU_OPT_EXTERNAL_MEMORY */

    #if (CY_DFU_OPT_EXTERNAL_MEMORY != 0U)
        #ifdef USE_SMIF_PDL_INIT
            #include "cycfg_qspi_memslot.h"
        #else
            #include "mtb_serial_memory.h"
        #endif
    #endif /* (CY_DFU_OPT_EXTERNAL_MEMORY != 0U) */
#endif /* CY_DFU_FLOW == CY_DFU_MCUBOOT_FLOW */

/** A non-zero value enables the external memory support and
 * automatically disables internal memory support.
 */
#ifndef CY_DFU_OPT_EXTERNAL_MEMORY
    #define CY_DFU_OPT_EXTERNAL_MEMORY      (0)
#endif /* CY_DFU_OPT_EXTERNAL_MEMORY */

/** \} group_dfu_macro_config */

#if ((CY_DFU_OPT_EXTERNAL_MEMORY != 0U) && !defined (USE_SMIF_PDL_INIT)) || defined(CY_DOXYGEN)
/**
* \addtogroup group_dfu_functions
* \{
*/
/*******************************************************************************
* Function Name: Cy_DFU_AddExtMemory
****************************************************************************//**
*
* This function receives and stores an object for external memory
*
* \param serialMemObj   The pointer to an object for serial memory middleware
*
* \note This function is applicable only when \ref CY_DFU_OPT_EXTERNAL_MEMORY
* is not equal to zero.
*
*******************************************************************************/
void Cy_DFU_AddExtMemory(mtb_serial_memory_t *serialMemObj);
/** \} group_dfu_functions */
#endif /* #if ((CY_DFU_OPT_EXTERNAL_MEMORY != 0U) && !defined (USE_SMIF_PDL_INIT)) || defined(CY_DOXYGEN) */

/** \cond INTERNAL */
/* Basic bootloader flow specific constants. Do not update this section */
#if (CY_DFU_FLOW == CY_DFU_BASIC_FLOW) || defined(CY_DOXYGEN)

    /**
    * Set to non-zero for the DFU SDK Program Data command to check
    * if the Golden image is going to be overwritten while updating.
    */
    #ifndef CY_DFU_OPT_GOLDEN_IMAGE
        #define CY_DFU_OPT_GOLDEN_IMAGE    (0)
    #endif /* CY_DFU_OPT_GOLDEN_IMAGE */

    /**
    * List of Golden Image Application IDs.
    * Here "Golden Image Application" means an application that cannot be changed with
    * CommandProgramData()
    *
    * Usage. Define the list of Golden Image Application IDs without enclosing
    * parenthesis, e.g.
    * \code #define CY_DFU_GOLDEN_IMAGE_IDS()     0U, 1U, 3U \endcode
    * later it is used in cy_dfu.c file:
    * \code uint8_t goldenImages[] = { CY_DFU_GOLDEN_IMAGE_IDS() }; \endcode
    */
    #ifndef CY_DFU_GOLDEN_IMAGE_IDS
        #define CY_DFU_GOLDEN_IMAGE_IDS()  0U
    #endif /* CY_DFU_GOLDEN_IMAGE_IDS */

    /** A non-zero value enables the Get Metadata DFU command */
    #ifndef CY_DFU_OPT_GET_METADATA
        #define CY_DFU_OPT_GET_METADATA    (1)
    #endif /* CY_DFU_OPT_GET_METADATA */

    /** A non-zero value enables the Set EI Vector DFU command */
    #ifndef CY_DFU_OPT_SET_EIVECTOR
        #define CY_DFU_OPT_SET_EIVECTOR    (0)
    #endif /* CY_DFU_OPT_SET_EIVECTOR */

    /** A non-zero value allows writing metadata with the Set App Metadata DFU command. */
    #ifndef CY_DFU_METADATA_WRITABLE
        #define CY_DFU_METADATA_WRITABLE   (1)
    #endif /* CY_DFU_METADATA_WRITABLE */

    /** Non-zero value enables the usage of hardware Crypto API */
    #ifndef CY_DFU_OPT_CRYPTO_HW
        #define CY_DFU_OPT_CRYPTO_HW       (0)
    #endif /* CY_DFU_OPT_CRYPTO_HW */

    #if defined(__ARMCC_VERSION)
        #include "dfu_common.h"

        #define CY_DFU_SIGNATURE_SIZE          CY_BOOT_SIGNATURE_SIZE
        #define CY_DFU_APP0_VERIFY_START       ( CY_APP0_FLASH_ADDR )
        #define CY_DFU_APP0_VERIFY_LENGTH      ( CY_APP0_FLASH_LENGTH - CY_DFU_SIGNATURE_SIZE)
        #define CY_DFU_APP1_VERIFY_START       ( CY_APP1_FLASH_ADDR )
        #define CY_DFU_APP1_VERIFY_LENGTH      ( CY_APP1_FLASH_LENGTH - CY_DFU_SIGNATURE_SIZE)

    #elif defined(__GNUC__) || defined(__ICCARM__)
        /*
        * These variables are defined in the linker scripts, the values of their addresses define
        * corresponding applications start address and length.
        */
        extern uint8_t __cy_app0_verify_start;
        extern uint8_t __cy_app0_verify_length;
        extern uint8_t __cy_app1_verify_start;
        extern uint8_t __cy_app1_verify_length;
        extern uint8_t __cy_boot_signature_size;

        #define CY_DFU_APP0_VERIFY_START       ( (uint32_t)&__cy_app0_verify_start )
        #define CY_DFU_APP0_VERIFY_LENGTH      ( (uint32_t)&__cy_app0_verify_length )
        #define CY_DFU_APP1_VERIFY_START       ( (uint32_t)&__cy_app1_verify_start )
        #define CY_DFU_APP1_VERIFY_LENGTH      ( (uint32_t)&__cy_app1_verify_length )
        #define CY_DFU_SIGNATURE_SIZE          ( (uint32_t)&__cy_boot_signature_size )
    #else
        #error "Not implemented for this compiler"
    #endif /* defined(__CC_ARM) */
#endif /* (CY_DFU_FLOW == CY_DFU_BASIC_FLOW) && defined(CY_DOXYGEN) */
/** \endcond*/

#if defined(__cplusplus)
}
#endif

#endif /* !defined(DFU_USER_H) */


/* [] END OF FILE */
