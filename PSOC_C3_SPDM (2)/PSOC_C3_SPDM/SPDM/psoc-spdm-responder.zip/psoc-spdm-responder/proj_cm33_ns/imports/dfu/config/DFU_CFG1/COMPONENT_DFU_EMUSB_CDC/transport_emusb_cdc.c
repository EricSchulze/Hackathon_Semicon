/***************************************************************************//**
* \file transport_emusb_cdc.c
*
* This file provides the source code of the DFU communication API implementation
* for the emUSB-Device that implements a virtual COM port (CDC class).
*
* Note
* This file supports only the ModusToolbox flow.
* For the ModusToolbox flow, the USB device personality alias must be
* "DFU_EMUSB_CDC".
* This file serves as a template and can be modified defining any component
* name or personality alias.
*
********************************************************************************
* \copyright
* (c) (2016-2026), Infineon Technologies AG, or an affiliate of Infineon
* Technologies AG. All rights reserved.
********************************************************************************
* This software, associated documentation and materials ("Software") is
* owned by Infineon Technologies AG or one of its affiliates ("Infineon")
* and is protected by and subject to worldwide patent protection, worldwide
* copyright laws, and international treaty provisions. Therefore, you may use
* this Software only as provided in the license agreement accompanying the
* software package from which you obtained this Software. If no license
* agreement applies, then any use, reproduction, modification, translation, or
* compilation of this Software is prohibited without the express written
* permission of Infineon.
*
* Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
* IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
* THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
* SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
* Infineon reserves the right to make changes to the Software without notice.
* You are responsible for properly designing, programming, and testing the
* functionality and safety of your intended application of the Software, as
* well as complying with any legal requirements related to its use. Infineon
* does not guarantee that the Software will be free from intrusion, data theft
* or loss, or other breaches ("Security Breaches"), and Infineon shall have
* no liability arising out of any Security Breaches. Unless otherwise
* explicitly approved by Infineon, the Software may not be used in any
* application where a failure of the Product or any consequences of the use
* thereof can reasonably be expected to result in personal injury.
*******************************************************************************/

#include "USB.h"
#include "USB_CDC.h"
#include "transport_emusb_cdc.h"


/* USER CONFIGURABLE: The USB device COM port data endpoint maximum packet size */
#ifndef CY_DFU_USB_CDC_ENDPOINT_MAX_PACKET
    #if defined (CY_IP_MXUSBFS) || defined (CY_IP_MXS40SUSBFS)
        #define CY_DFU_USB_CDC_ENDPOINT_MAX_PACKET   (USB_FS_BULK_MAX_PACKET_SIZE)
    #elif defined (CY_IP_MXS22USBHS)
        #define CY_DFU_USB_CDC_ENDPOINT_MAX_PACKET   (USB_HS_BULK_MAX_PACKET_SIZE)
    #endif /* #if defined (CY_IP_MXUSBFS) || defined (CY_IP_MXS40SUSBFS) */
#endif /* #ifndef CY_DFU_USB_CDC_ENDPOINT_MAX_PACKET */

/* Interrupt endpoint size */
#if defined (CY_IP_MXUSBFS) || defined (CY_IP_MXS40SUSBFS)
    #define CY_DFU_USB_HID_ENDPOINT_SIZE         (USB_FS_INT_MAX_PACKET_SIZE)
#elif defined (CY_IP_MXS22USBHS)
    #define CY_DFU_USB_HID_ENDPOINT_SIZE         (USB_HS_INT_MAX_PACKET_SIZE)
#endif /* #if defined (CY_IP_MXUSBFS) || defined (CY_IP_MXS40SUSBFS) */


/* Handle for emUSB CDC instance */
static USB_CDC_HANDLE    hInst;

/* Buffer for store data in OUT direction (Host to Device) */
static uint8_t OutBuffer[CY_DFU_USB_CDC_ENDPOINT_MAX_PACKET];

/* The pointer to the initialization/de-initialization callback function
 * USB hardware
 */
static Cy_DFU_TransportUsbCdcCallback usb_callback;

/*******************************************************************************
* Function Name: Cy_DFU_TransportUsbCdcConfig
****************************************************************************//**
*
* Configure DFU USB CDC Transport
*
* Call this function in the user application to provide the HAL object and callback
* function to DFU transport.
*
* \param config Configuration structure
*
*******************************************************************************/
void Cy_DFU_TransportUsbCdcConfig(cy_stc_dfu_transport_usb_cdc_cfg_t * config)
{
    CY_ASSERT(NULL != config);
    CY_ASSERT(NULL != config->callback);

    usb_callback = config->callback;
}


/*******************************************************************************
* Function Name: USB_CDC_CyBtldrCommStart
****************************************************************************//**
*
* Starts the USB device operation.
*
* \note
* This function configures USB block but the pins/clocks need to be configured
* in User Application or in Device Configurator.
*
*******************************************************************************/
void USB_CDC_CyBtldrCommStart(void)
{
    CY_ASSERT(NULL != usb_callback);
    if (NULL != usb_callback)
    {
        usb_callback(CY_DFU_TRANSPORT_USB_CDC_INIT);

        USB_ADD_EP_INFO EPBulkIn;
        USB_ADD_EP_INFO EPBulkOut;
        USB_ADD_EP_INFO EPIntIn;
        USB_CDC_INIT_DATA InitData;

        (void) memset(&EPBulkIn, 0x0, sizeof(EPBulkIn));
        (void) memset(&EPBulkOut, 0x0, sizeof(EPBulkOut));
        (void) memset(&EPIntIn, 0x0, sizeof(EPIntIn));
        (void) memset(&InitData, 0x0, sizeof(InitData));

        /* IN direction (Device to Host) endpoint */
        EPBulkIn.Flags          = 0;                                  /* Flags not used.                                                         */
        EPBulkIn.InDir          = USB_DIR_IN;                         /* IN direction (Device to Host)                                           */
        EPBulkIn.Interval       = 0;                                  /* Interval not used for Bulk endpoints.                                   */
        EPBulkIn.MaxPacketSize  = CY_DFU_USB_CDC_ENDPOINT_MAX_PACKET; /* Maximum packet size (64 for Bulk in full-speed and 512 for high-speed). */
        EPBulkIn.TransferType   = USB_TRANSFER_TYPE_BULK;             /* Endpoint type - Bulk.                                                   */
        InitData.EPIn  = (uint8_t)USBD_AddEPEx(&EPBulkIn, NULL, 0);

        /* OUT direction (Device to Host) endpoint */
        EPBulkOut.Flags         = 0;                                  /* Flags not used.                                                          */
        EPBulkOut.InDir         = USB_DIR_OUT;                        /* OUT direction (Host to Device)                                           */
        EPBulkOut.Interval      = 0;                                  /* Interval not used for Bulk endpoints.                                    */
        EPBulkOut.MaxPacketSize = CY_DFU_USB_CDC_ENDPOINT_MAX_PACKET; /* Maximum packet size (64 for Bulk in full-speed and 512 for high-speed).  */
        EPBulkOut.TransferType  = USB_TRANSFER_TYPE_BULK;             /* Endpoint type - Bulk.                                                    */
        InitData.EPOut = (uint8_t)USBD_AddEPEx(&EPBulkOut, OutBuffer, sizeof(OutBuffer));

        /* Interrupt endpoint */
        EPIntIn.Flags           = 0;                                  /* Flags not used.                         */
        EPIntIn.InDir           = USB_DIR_IN;                         /* IN direction (Device to Host)           */
        EPIntIn.Interval        = 64;                                 /* Interval of 8 ms (64 * 125us)           */
        EPIntIn.MaxPacketSize   = CY_DFU_USB_HID_ENDPOINT_SIZE;       /* Maximum packet size (64 for Interrupt). */
        EPIntIn.TransferType    = USB_TRANSFER_TYPE_INT;              /* Endpoint type - Interrupt.              */
        InitData.EPInt = (uint8_t)USBD_AddEPEx(&EPIntIn, NULL, 0);

        /* Adds a CDC class to the stack */
        hInst = USBD_CDC_Add(&InitData);

        usb_callback(CY_DFU_TRANSPORT_USB_CDC_ENABLE);
    }
}


/*******************************************************************************
* Function Name: USB_CDC_CyBtldrCommStop
****************************************************************************//**
*
* Disables the USB device component.
*
*******************************************************************************/
void USB_CDC_CyBtldrCommStop(void)
{
    CY_ASSERT(NULL != usb_callback);
    if (NULL != usb_callback)
    {
        usb_callback(CY_DFU_TRANSPORT_USB_CDC_DISABLE);
        usb_callback(CY_DFU_TRANSPORT_USB_CDC_DEINIT);
    }
}


/*******************************************************************************
* Function Name: USB_CDC_CyBtldrCommReset
****************************************************************************//**
*
* Resets the receive and transmits communication buffers.
*
*******************************************************************************/
void USB_CDC_CyBtldrCommReset(void)
{
    if (((int8_t)USBD_IsConfigured()) > 0)
    {
        /* Cancel any read or write operation */
        USBD_CDC_CancelRead(hInst);
        USBD_CDC_CancelWrite(hInst);
    }
}


/*******************************************************************************
* Function Name: USB_CDC_CyBtldrCommRead
****************************************************************************//**
*
* Allows the caller to read data from the DFU host (the host writes the
* data). The function handles polling to allow a block of data to be completely
* received from the host device.
*
* \param pData   The pointer to a buffer to store a received command.
* \param size    The number of bytes to be read.
* \param count   The pointer to the variable that contains the number of received bytes.
* \param timeout The time to wait before the function returns because of a timeout,
*                in milliseconds.
*
* \return
* The status of the operation:
* - \ref CY_DFU_SUCCESS - If successful.
* - \ref CY_DFU_ERROR_TIMEOUT - If no data has been received.
* - See \ref cy_en_dfu_status_t.
*
*******************************************************************************/
cy_en_dfu_status_t USB_CDC_CyBtldrCommRead(uint8_t pData[], uint32_t size, uint32_t *count, uint32_t timeout)
{
    cy_en_dfu_status_t retCode = CY_DFU_ERROR_TIMEOUT;

    CY_ASSERT_L1((pData != NULL) && (size > 0U) && (count != NULL));

    /* Check Device enumeration */
    if ((USBD_GetState() & (USB_STAT_CONFIGURED | USB_STAT_SUSPENDED)) == USB_STAT_CONFIGURED)
    {
        /* Wait (blocking with timeout) for data to be available for a read */
        int32_t retVal = USBD_CDC_Receive(hInst, pData, size, (int32_t)timeout);

        /* Data received successfully */
        if (retVal > 0)
        {
            *count = (uint32_t)retVal;
            retCode = CY_DFU_SUCCESS;
        }

        /* An error occurred */
        if (retVal < 0)
        {
            retCode = CY_DFU_ERROR_UNKNOWN;
        }
    }

    return (retCode);
}


/*******************************************************************************
* Function Name: USB_CDC_CyBtldrCommWrite
****************************************************************************//**
*
* Allows the caller to write data to the DFU host (the host reads the
* data). The function uses a timeout and returns after data has been
* copied into the transmit buffer. The data transmission starts immediately
* after the first data element is written into the buffer and lasts until all
* data elements from the buffer are sent.
*
* \param pData     The pointer to the block of data to be written to the DFU
*                  host.
* \param size      The number of bytes to be written.
* \param count     The pointer to the variable to write the number of actually written bytes.
* \param timeout   The time out to wait for before the data is copied to the transmit buffer.
*                  The function returns as soon as data is copied into the
*                  transmit buffer.
* \return
* The status of the operation:
* - \ref CY_DFU_SUCCESS - If successful.
* - See \ref cy_en_dfu_status_t.
*
*******************************************************************************/
cy_en_dfu_status_t USB_CDC_CyBtldrCommWrite(const uint8_t pData[], uint32_t size, uint32_t *count, uint32_t timeout)
{
    cy_en_dfu_status_t retCode = CY_DFU_ERROR_TIMEOUT;

    CY_ASSERT_L1((pData != NULL) && (size > 0U) && (count != NULL));
    CY_ASSERT_L1(size <= CY_DFU_USB_CDC_ENDPOINT_MAX_PACKET);

    /* Check Device enumeration */
    if ((USBD_GetState() & (USB_STAT_CONFIGURED | USB_STAT_SUSPENDED)) == USB_STAT_CONFIGURED)
    {
        /* Wait (blocking with timeout) for an endpoint availability for a write */
        if (USBD_CDC_WaitForTX(hInst, timeout) == 0)
        {
            /* Write data to the Host (blocking with timeout) */
            int32_t retVal = USBD_CDC_Write(hInst, pData, size, (int32_t)timeout);
            int32_t numBytes = (int32_t)size;

            /* Data sent successfully */
            if (retVal == numBytes)
            {
                *count = size;
                retCode = CY_DFU_SUCCESS;
            }

            /* An error occurred */
            if (retVal < 0)
            {
                retCode = CY_DFU_ERROR_UNKNOWN;
            }
        }
    }

    return (retCode);
}


/* [] END OF FILE */
