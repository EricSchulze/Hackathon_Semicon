set(CMAKE_HOST_SYSTEM "Windows-10.0.22631")
set(CMAKE_HOST_SYSTEM_NAME "Windows")
set(CMAKE_HOST_SYSTEM_VERSION "10.0.22631")
set(CMAKE_HOST_SYSTEM_PROCESSOR "AMD64")

include("P:/psoc-spdm-responder/proj_cm33_ns/spdm/toolchain_arm_none_eabi.cmake")

set(CMAKE_SYSTEM "Generic")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "arm")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
