/*****************************************************************************
* File Name        : spdm_debuglib.c
*
* Description      : libspdm debug-output hook (debuglib) for the PSOC(TM)
*                    Control C3 SPDM Responder.
*
*                    libspdm emits its own diagnostic prints and assertion
*                    failures through libspdm_debug_print() / libspdm_debug_
*                    assert(). This hook routes both onto the same debug UART
*                    the application's LOG_* facility uses (retarget-io), and
*                    ties libspdm's verbosity to the compile-time LOG_LEVEL:
*                    libspdm ERROR output is always surfaced, while its (chatty)
*                    INFO traffic is emitted only when the image is built at
*                    LOG_LEVEL_DEBUG. Building with LIBSPDM_DEBUG_ENABLE=0 (or a
*                    CMake Release archive build) drops these routines and all
*                    libspdm debug strings from the image entirely.
*
* Related Document : See docs/implementation.md
*
*******************************************************************************
* (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
* Technologies AG. All rights reserved.
* This software, associated documentation and materials ("Software") is
* owned by Infineon Technologies AG or one of its affiliates ("Infineon")
* and is protected by and subject to worldwide patent protection, worldwide
* copyright laws, and international treaty provisions. Therefore, you may use
* this Software only as provided in the license agreement accompanying the
* software package from which you obtained this Software. If no license
* agreement applies, then any use, reproduction, modification, translation, or
* compilation of this Software is prohibited without the express written
* permission of Infineon.
*
* Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
* IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
* THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
* SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
* Infineon reserves the right to make changes to the Software without notice.
* You are responsible for properly designing, programming, and testing the
* functionality and safety of your intended application of the Software, as
* well as complying with any legal requirements related to its use. Infineon
* does not guarantee that the Software will be free from intrusion, data theft
* or loss, or other breaches ("Security Breaches"), and Infineon shall have
* no liability arising out of any Security Breaches. Unless otherwise
* explicitly approved by Infineon, the Software may not be used in any
* application where a failure of the Product or any consequences of the use
* thereof can reasonably be expected to result in personal injury.
*****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdarg.h>
#include <stdio.h>

#include "log.h"
#include "hal/library/debuglib.h"

/* Maximum length of a single formatted libspdm debug line (matches libspdm's
 * own os_stub debuglib). Longer messages are truncated rather than allocated. */
#define SPDM_DEBUG_MSG_MAX  (256u)

/******************************************************************************
 * Public functions (libspdm debuglib interface)
 *****************************************************************************/

#if LIBSPDM_DEBUG_PRINT_ENABLE
void libspdm_debug_print(size_t error_level, const char *format, ...)
{
    char buffer[SPDM_DEBUG_MSG_MAX];
    va_list marker;

    /* Gate libspdm's verbosity behind the app-wide compile-time log level:
     * always surface ERROR output, but only emit the verbose INFO stream when
     * the image is built at LOG_LEVEL_DEBUG. */
#if (LOG_LEVEL < LOG_LEVEL_DEBUG)
    if ((error_level & LIBSPDM_DEBUG_ERROR) == 0) {
        return;
    }
#else
    (void)error_level;
#endif

    va_start(marker, format);
    (void)vsnprintf(buffer, sizeof(buffer), format, marker);
    va_end(marker);

    /* libspdm formats its own (often partial-line) messages, so emit them
     * verbatim on the same debug UART the LOG_* macros use (retarget-io),
     * without adding a tag or line ending. */
    (void)printf("%s", buffer);
}
#endif /* LIBSPDM_DEBUG_PRINT_ENABLE */

#if LIBSPDM_DEBUG_ASSERT_ENABLE
void libspdm_debug_assert(const char *file_name, size_t line_number,
                          const char *description)
{
    LOG_ERR("SPDM assert: %s(%u): %s",
            file_name, (unsigned int)line_number, description);

    /* Halt so the failure is observable during bring-up (this mirrors
     * libspdm's default dead-loop assert behavior). */
    for (volatile int hold = 1; hold != 0; ) {
    }
}
#endif /* LIBSPDM_DEBUG_ASSERT_ENABLE */

/* [] END OF FILE */
