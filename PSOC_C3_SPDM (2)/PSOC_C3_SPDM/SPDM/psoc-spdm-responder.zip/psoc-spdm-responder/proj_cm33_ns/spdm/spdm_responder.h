/*****************************************************************************
 * File Name        : spdm_responder.h
 *
 * Description      : Non-secure libspdm Responder context owner for the SPDM
 *                    Responder. Builds and holds the single libspdm responder
 *                    context, registers the DFU/I2C carrier device-I/O, the
 *                    MCTP transport layer and the capability / algorithm /
 *                    certificate-chain data, and exposes a one-shot dispatch
 *                    entry the SPDM router calls per DFU transaction.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef SPDM_RESPONDER_H
#define SPDM_RESPONDER_H

#include <stdbool.h>

/* Pulls in libspdm_return_t. */
#include "library/spdm_common_lib.h"

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * @brief Build and configure the libspdm responder context.
 *
 * Allocates the context, scratch and certificate-chain storage statically,
 * registers the DFU/I2C carrier device-I/O callbacks and the MCTP transport
 * layer, sets the supported capabilities and algorithms, and loads the
 * provisioned SPDM certificate chain from the secure PAS into the context.
 *
 * Must be called once from non-secure main() before starting the SPDM router
 * service loop.
 *
 * @return true on success; false if any libspdm configuration step fails, the
 *         static buffers are too small, or the certificate chain cannot be
 *         read from the PAS.
 */
bool spdm_responder_init(void);

/**
 * @brief Run one libspdm responder dispatch cycle.
 *
 * Consumes the request currently staged in the carrier bridge (through the
 * registered receive callback), processes it, and produces the MCTP-framed
 * response (through the registered send callback) into the carrier bridge,
 * from which the router copies it into the DFU reply. Exactly one transport
 * message is consumed and one produced per call, matching one DFU transaction.
 *
 * @return LIBSPDM_STATUS_SUCCESS if a response was produced; a libspdm error
 *         status otherwise (including if the context is not initialized).
 */
libspdm_return_t spdm_responder_dispatch(void);

#if defined(__cplusplus)
}
#endif

#endif /* SPDM_RESPONDER_H */

/* [] END OF FILE */
