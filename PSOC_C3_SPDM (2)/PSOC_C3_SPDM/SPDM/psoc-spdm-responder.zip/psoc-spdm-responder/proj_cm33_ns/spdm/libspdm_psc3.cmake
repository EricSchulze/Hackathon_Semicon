#################################################################################
# \file libspdm_psc3.cmake
# \version 1.0
#
# \brief
# Builds the libspdm 4.0.0 Responder-side static libraries for the PSOC(TM)
# Control C3 non-secure core, from the pristine git submodule at
# third_party/libspdm.
#
# Only the Responder set is built:
#     spdm_common_lib
#     spdm_responder_lib
#     spdm_secured_message_lib
#     spdm_crypt_lib
#     spdm_transport_mctp_lib
#
# The .a archives are CONFIG-SPECIALIZED: they are compiled with
# spdm_lib_config_psc3.h (via -DLIBSPDM_CONFIG). The crypto backend, the
# device-secret/signing hook, debuglib and memlib are intentionally NOT built
# here; those symbols are left as unresolved externals in the archives and are
# resolved at the final ModusToolbox NS link against our NSC forwarders and the
# log facility.
#
# This file is included by the sibling CMakeLists.txt. Configure with the
# arm-none-eabi toolchain file (toolchain_arm_none_eabi.cmake), e.g.:
#
#   cmake -S proj_cm33_ns/spdm -B build/libspdm \
#         -G Ninja \
#         -DCMAKE_TOOLCHAIN_FILE=proj_cm33_ns/spdm/toolchain_arm_none_eabi.cmake \
#         -DARM_TOOLCHAIN_DIR=<MTB gcc bin> \
#         -DCMAKE_BUILD_TYPE=Debug
#   cmake --build build/libspdm
#
#################################################################################
# \copyright
# (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
# Technologies AG.  SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#################################################################################

# ------------------------------------------------------------------------------
# Paths.
#   LIBSPDM_DIR    : the pristine submodule (the per-directory CMakeLists use it).
#   SPDM_GLUE_DIR  : this directory, holding spdm_lib_config_psc3.h.
# ------------------------------------------------------------------------------
get_filename_component(SPDM_GLUE_DIR "${CMAKE_CURRENT_LIST_DIR}" ABSOLUTE)
get_filename_component(LIBSPDM_DIR
    "${SPDM_GLUE_DIR}/../../third_party/libspdm" ABSOLUTE)

if(NOT EXISTS "${LIBSPDM_DIR}/include/library/spdm_lib_config.h")
    message(FATAL_ERROR
        "libspdm submodule not found at ${LIBSPDM_DIR}. "
        "Run 'git submodule update --init third_party/libspdm'.")
endif()

set(SPDM_CONFIG_HEADER "${SPDM_GLUE_DIR}/spdm_lib_config_psc3.h")

# ------------------------------------------------------------------------------
# Global compile settings applied to every libspdm target added below.
#   * LIBSPDM_CONFIG points internal/libspdm_lib_config.h at our tailored header.
#   * The glue dir is on the include path so the bare filename resolves.
#   * The submodule include dir is added so the config's own
#     #include "library/spdm_lib_config.h" resolves.
# ------------------------------------------------------------------------------
add_compile_definitions(LIBSPDM_CONFIG="spdm_lib_config_psc3.h")
include_directories(
    "${SPDM_GLUE_DIR}"
    "${LIBSPDM_DIR}/include"
)

# SPDM profile include dir (mirrors common.mk). The NS Makefile PREBUILD passes
# -DSPDM_PROFILE_INCLUDE_DIR=<abs path to profiles/$(SPDM_PROFILE)>; put it on the
# archive include path so spdm_lib_config_psc3.h's #include "profile.h" resolves
# to the same SPDM_HAVE_* capability flags the app compiles against. Default to
# profiles/P1 (the repo default profile) so a bare cmake invocation still
# configures.
if(NOT DEFINED SPDM_PROFILE_INCLUDE_DIR)
    get_filename_component(SPDM_PROFILE_INCLUDE_DIR
        "${SPDM_GLUE_DIR}/../../profiles/P1" ABSOLUTE)
endif()
if(NOT EXISTS "${SPDM_PROFILE_INCLUDE_DIR}/profile.h")
    message(FATAL_ERROR
        "SPDM profile.h not found at ${SPDM_PROFILE_INCLUDE_DIR}.")
endif()
include_directories("${SPDM_PROFILE_INCLUDE_DIR}")

# Collect every static archive in one predictable directory (<build>/lib) so the
# ModusToolbox NS link can reference them by a single path.
set(CMAKE_ARCHIVE_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/lib")

# ------------------------------------------------------------------------------
# Build only the Responder-side libraries. Each subdirectory's CMakeLists owns
# the authoritative source list (so version upgrades stay clean).
# ------------------------------------------------------------------------------
set(SPDM_RESPONDER_LIBS
    spdm_common_lib
    spdm_crypt_lib
    spdm_secured_message_lib
    spdm_responder_lib
    spdm_transport_mctp_lib
)

foreach(_lib ${SPDM_RESPONDER_LIBS})
    add_subdirectory(
        "${LIBSPDM_DIR}/library/${_lib}"
        "${CMAKE_BINARY_DIR}/${_lib}")
endforeach()
