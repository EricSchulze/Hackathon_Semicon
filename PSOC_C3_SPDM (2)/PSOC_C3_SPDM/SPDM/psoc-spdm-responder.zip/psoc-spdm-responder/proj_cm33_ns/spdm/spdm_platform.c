/*****************************************************************************
* File Name        : spdm_platform.c
*
* Description      : libspdm platform-services hook (platform_lib) for the
*                    PSOC(TM) Control C3 SPDM Responder.
*
*                    Supplies the timing primitive that libspdm leaves to the
*                    integrator: libspdm_sleep(), a blocking delay implemented
*                    on the PDL SysLib delay. No dynamic allocation and no RTOS
*                    dependency.
*
*                    (The heartbeat watchdog hooks are not implemented here: the
*                    HBEAT capability is disabled in spdm_lib_config_psc3.h, so
*                    the libspdm Responder never references them.)
*
* Related Document : See docs/implementation.md
*
*******************************************************************************
* (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
* Technologies AG. All rights reserved.
* This software, associated documentation and materials ("Software") is
* owned by Infineon Technologies AG or one of its affiliates ("Infineon")
* and is protected by and subject to worldwide patent protection, worldwide
* copyright laws, and international treaty provisions. Therefore, you may use
* this Software only as provided in the license agreement accompanying the
* software package from which you obtained this Software. If no license
* agreement applies, then any use, reproduction, modification, translation, or
* compilation of this Software is prohibited without the express written
* permission of Infineon.
*
* Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
* IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
* THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
* SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
* Infineon reserves the right to make changes to the Software without notice.
* You are responsible for properly designing, programming, and testing the
* functionality and safety of your intended application of the Software, as
* well as complying with any legal requirements related to its use. Infineon
* does not guarantee that the Software will be free from intrusion, data theft
* or loss, or other breaches ("Security Breaches"), and Infineon shall have
* no liability arising out of any Security Breaches. Unless otherwise
* explicitly approved by Infineon, the Software may not be used in any
* application where a failure of the Product or any consequences of the use
* thereof can reasonably be expected to result in personal injury.
*****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include "cy_pdl.h"

#include "hal/library/requester/timelib.h"

/* Number of microseconds in a millisecond, used to split a sleep request into
 * millisecond and sub-millisecond delays. */
#define SPDM_US_PER_MS  (1000u)

/******************************************************************************
 * Public functions (libspdm platform_lib interface)
 *****************************************************************************/

void libspdm_sleep(uint64_t duration)
{
    /* duration is expressed in microseconds. Cy_SysLib_Delay() takes whole
     * milliseconds; Cy_SysLib_DelayUs() takes microseconds up to 65535. Split
     * the request so both parts stay within range. */
    uint32_t milliseconds = (uint32_t)(duration / SPDM_US_PER_MS);
    uint16_t microseconds = (uint16_t)(duration % SPDM_US_PER_MS);

    if (milliseconds != 0u) {
        Cy_SysLib_Delay(milliseconds);
    }
    if (microseconds != 0u) {
        Cy_SysLib_DelayUs(microseconds);
    }
}

/* [] END OF FILE */
