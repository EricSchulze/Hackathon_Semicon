/*****************************************************************************
 * File Name        : spdm_transport_dfu.c
 *
 * Description      : Implementation of the non-secure DFU/I2C carrier bridge
 *                    for the SPDM responder. See spdm_transport_dfu.h for the
 *                    push/pull bridging rationale.
 *
 *                    The bridge holds one in-flight transport message. Two
 *                    working buffers are handed to libspdm through the acquire
 *                    callbacks (its transport encode/decode scratch), and two
 *                    staging buffers carry the request from / the response to
 *                    the DFU handler:
 *
 *                      DFU 0x80 handler --stage_request--> [rx staging]
 *                          libspdm receive_message  <-- copies rx staging
 *                          ... responder processing ...
 *                          libspdm send_message     --> copies to [tx staging]
 *                      DFU 0x80 handler <--take_response-- [tx staging]
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <string.h>

#include "spdm_transport_dfu.h"

/******************************************************************************
 * Module State
 *****************************************************************************/

/* libspdm transport working buffers handed out by the acquire callbacks. There
 * is a single sender and a single receiver buffer (MAX_SESSION_COUNT == 1 and
 * one in-flight transport message), so the acquire calls never fail. */
static uint8_t s_sender_buffer[LIBSPDM_SENDER_BUFFER_SIZE];
static uint8_t s_receiver_buffer[LIBSPDM_RECEIVER_BUFFER_SIZE];

/* Staging for the single in-flight transport message. */
static uint8_t s_rx_buffer[SPDM_DFU_TRANSPORT_MSG_SIZE];
static size_t  s_rx_len;
static bool    s_rx_ready;      /* a staged request awaits receive_message()  */

static uint8_t s_tx_buffer[SPDM_DFU_TRANSPORT_MSG_SIZE];
static size_t  s_tx_len;
static bool    s_tx_ready;      /* a response awaits take_response()          */

/******************************************************************************
 * Router-facing staging API
 *****************************************************************************/

void spdm_transport_dfu_reset(void)
{
    s_rx_len   = 0U;
    s_rx_ready = false;
    s_tx_len   = 0U;
    s_tx_ready = false;
}

bool spdm_transport_dfu_stage_request(const uint8_t *data, size_t len)
{
    if ((data == NULL) || (len == 0U) || (len > sizeof(s_rx_buffer)))
    {
        return false;
    }

    (void)memcpy(s_rx_buffer, data, len);
    s_rx_len   = len;
    s_rx_ready = true;

    /* A fresh request starts a new exchange; drop any stale response. */
    s_tx_len   = 0U;
    s_tx_ready = false;
    return true;
}

bool spdm_transport_dfu_take_response(uint8_t *out, size_t out_cap, size_t *out_len)
{
    if (!s_tx_ready || (out == NULL) || (out_len == NULL) || (out_cap < s_tx_len))
    {
        return false;
    }

    (void)memcpy(out, s_tx_buffer, s_tx_len);
    *out_len   = s_tx_len;
    s_tx_ready = false;
    return true;
}

bool spdm_transport_dfu_response_pending(void)
{
    return s_tx_ready;
}

/******************************************************************************
 * libspdm device-I/O callbacks
 *****************************************************************************/

libspdm_return_t spdm_transport_dfu_send_message(void *spdm_context, size_t message_size,
                                                 const void *message, uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    if ((message == NULL) || (message_size == 0U) || (message_size > sizeof(s_tx_buffer)))
    {
        return LIBSPDM_STATUS_SEND_FAIL;
    }

    (void)memcpy(s_tx_buffer, message, message_size);
    s_tx_len   = message_size;
    s_tx_ready = true;
    return LIBSPDM_STATUS_SUCCESS;
}

libspdm_return_t spdm_transport_dfu_receive_message(void *spdm_context, size_t *message_size,
                                                    void **message, uint64_t timeout)
{
    (void)spdm_context;
    (void)timeout;

    if ((message_size == NULL) || (message == NULL) || (*message == NULL))
    {
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }

    if (!s_rx_ready)
    {
        return LIBSPDM_STATUS_RECEIVE_FAIL;
    }

    /* On input *message == the acquired receiver buffer; copy the staged
     * request into it and report its size. */
    (void)memcpy(*message, s_rx_buffer, s_rx_len);
    *message_size = s_rx_len;
    s_rx_ready    = false;
    return LIBSPDM_STATUS_SUCCESS;
}

libspdm_return_t spdm_transport_dfu_acquire_sender_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;

    if (msg_buf_ptr == NULL)
    {
        return LIBSPDM_STATUS_ACQUIRE_FAIL;
    }

    *msg_buf_ptr = s_sender_buffer;
    return LIBSPDM_STATUS_SUCCESS;
}

void spdm_transport_dfu_release_sender_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
}

libspdm_return_t spdm_transport_dfu_acquire_receiver_buffer(void *spdm_context, void **msg_buf_ptr)
{
    (void)spdm_context;

    if (msg_buf_ptr == NULL)
    {
        return LIBSPDM_STATUS_ACQUIRE_FAIL;
    }

    *msg_buf_ptr = s_receiver_buffer;
    return LIBSPDM_STATUS_SUCCESS;
}

void spdm_transport_dfu_release_receiver_buffer(void *spdm_context, const void *msg_buf_ptr)
{
    (void)spdm_context;
    (void)msg_buf_ptr;
}

/* [] END OF FILE */
