/*****************************************************************************
* File Name        : spdm_memlib.c
*
* Description      : libspdm memory-services hook (memlib) for the PSOC(TM)
*                    Control C3 SPDM Responder.
*
*                    libspdm's core/crypt/transport archives call these four
*                    memory primitives but deliberately ship no implementation,
*                    so the integrator can supply one matched to the platform.
*                    This implementation is fully static (no dynamic
*                    allocation) and self-contained. The copy/zero/compare
*                    routines use volatile accesses so the compiler cannot
*                    elide security-relevant clears or fold constant-time
*                    comparisons into early-out branches.
*
* Related Document : See docs/implementation.md
*
*******************************************************************************
* (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
* Technologies AG. All rights reserved.
* This software, associated documentation and materials ("Software") is
* owned by Infineon Technologies AG or one of its affiliates ("Infineon")
* and is protected by and subject to worldwide patent protection, worldwide
* copyright laws, and international treaty provisions. Therefore, you may use
* this Software only as provided in the license agreement accompanying the
* software package from which you obtained this Software. If no license
* agreement applies, then any use, reproduction, modification, translation, or
* compilation of this Software is prohibited without the express written
* permission of Infineon.
*
* Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
* IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
* THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
* SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
* Infineon reserves the right to make changes to the Software without notice.
* You are responsible for properly designing, programming, and testing the
* functionality and safety of your intended application of the Software, as
* well as complying with any legal requirements related to its use. Infineon
* does not guarantee that the Software will be free from intrusion, data theft
* or loss, or other breaches ("Security Breaches"), and Infineon shall have
* no liability arising out of any Security Breaches. Unless otherwise
* explicitly approved by Infineon, the Software may not be used in any
* application where a failure of the Product or any consequences of the use
* thereof can reasonably be expected to result in personal injury.
*****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include "hal/library/memlib.h"
#include "hal/library/debuglib.h"

/******************************************************************************
 * Public functions (libspdm memlib interface)
 *****************************************************************************/

void libspdm_copy_mem(void *dst_buf, size_t dst_len,
                      const void *src_buf, size_t src_len)
{
    volatile uint8_t *dst = (volatile uint8_t *)dst_buf;
    const volatile uint8_t *src = (const volatile uint8_t *)src_buf;

    /* Reject null pointers, overlapping ranges, and truncating copies. These
     * are programming errors in the caller; assert so they surface loudly
     * during bring-up rather than corrupting memory silently. */
    if ((dst == NULL) || (src == NULL)) {
        LIBSPDM_ASSERT(0);
        return;
    }
    if (((src < dst) && ((src + src_len) > dst)) ||
        ((dst < src) && ((dst + src_len) > src))) {
        LIBSPDM_ASSERT(0);
        return;
    }
    if (src_len > dst_len) {
        LIBSPDM_ASSERT(0);
        return;
    }

    while (src_len-- != 0) {
        *(dst++) = *(src++);
    }
}

void libspdm_set_mem(void *buffer, size_t length, uint8_t value)
{
    volatile uint8_t *pointer = (volatile uint8_t *)buffer;

    while (length-- != 0) {
        *(pointer++) = value;
    }
}

void libspdm_zero_mem(void *buffer, size_t length)
{
    volatile uint8_t *pointer = (volatile uint8_t *)buffer;

    while (length-- != 0) {
        *(pointer++) = 0;
    }

    /* Prevent the compiler from optimizing the clear away when the buffer is
     * not read afterwards (secret scrubbing). */
#if defined(__GNUC__)
    __asm__ __volatile__ ("" : : : "memory");
#endif
}

bool libspdm_consttime_is_mem_equal(const void *destination_buffer,
                                    const void *source_buffer, size_t length)
{
    const volatile uint8_t *pointer_dst = (const volatile uint8_t *)destination_buffer;
    const volatile uint8_t *pointer_src = (const volatile uint8_t *)source_buffer;
    uint8_t delta = 0;

    /* Constant-time: always walk the whole length, accumulating differences,
     * so timing does not leak where the first mismatch occurs. */
    while (length-- != 0) {
        delta |= (uint8_t)(*(pointer_dst++) ^ *(pointer_src++));
    }

    return (delta == 0);
}

/* [] END OF FILE */
