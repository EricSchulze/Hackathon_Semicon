/*****************************************************************************
 * File Name        : spdm_measlib.c
 *
 * Description      : Non-secure libspdm responder measurement HAL glue for the
 *                    SPDM Responder. Implements the responder measurement hooks
 *                    of hal/library/responder/measlib.h:
 *                      - libspdm_measurement_collection()
 *                      - libspdm_measurement_opaque_data()
 *                      - libspdm_generate_measurement_summary_hash()
 *                    so that signed GET_MEASUREMENTS and the
 *                    measurement_summary_hash embedded in CHALLENGE_AUTH /
 *                    KEY_EXCHANGE_RSP are answered by the device.
 *
 *                    These hooks are thin wrappers: the measurement policy, the
 *                    DMTF record assembly and the summary-hash computation all
 *                    live in the secure world (SPE) and are reached over the
 *                    measurement NSC veneers (shared/nsc_meas.h). This module
 *                    only translates between the libspdm HAL calling convention
 *                    and those veneers and applies the SPDM protocol framing
 *                    concerns that belong to the non-secure responder (DMTF
 *                    specification check, content-changed reporting, summary
 *                    hash-type / size validation).
 *
 *                    Keeping assembly and hashing in the SPE means a compromised
 *                    non-secure world cannot forge the measurement summary hash
 *                    that is subsequently signed with the device identity key.
 *                    The negotiated hash algorithms (base_hash_algo,
 *                    measurement_hash_algo) are forwarded to the SPE so it
 *                    hashes with the negotiated algorithm.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "hal/library/responder/measlib.h"
#include "industry_standard/spdm.h"
#include "library/spdm_crypt_lib.h"
#include "library/spdm_return_status.h"

#include "nsc_meas.h"

#if LIBSPDM_ENABLE_CAPABILITY_MEAS_CAP

/******************************************************************************
 * Static Helper Functions
 *****************************************************************************/

/* Translate a measurement NSC veneer status into a libspdm measurement status. */
static libspdm_return_t measlib_map_status(nsc_meas_status_t st)
{
    switch (st) {
    case NSC_MEAS_SUCCESS:
        return LIBSPDM_STATUS_SUCCESS;
    case NSC_MEAS_ERROR_BUFFER_TOO_SMALL:
        return LIBSPDM_STATUS_BUFFER_TOO_SMALL;
    case NSC_MEAS_ERROR_DOES_NOT_EXIST:
        return LIBSPDM_STATUS_MEAS_INVALID_INDEX;
    case NSC_MEAS_ERROR_NOT_SUPPORTED:
        return LIBSPDM_STATUS_UNSUPPORTED_CAP;
    default:
        return LIBSPDM_STATUS_MEAS_INTERNAL_ERROR;
    }
}

/******************************************************************************
 * libspdm responder measurement HAL (hal/library/responder/measlib.h)
 *****************************************************************************/

libspdm_return_t libspdm_measurement_collection(
    void *spdm_context,
    const uint32_t *session_id,
    spdm_version_number_t spdm_version,
    uint8_t measurement_specification,
    uint32_t measurement_hash_algo,
    uint8_t measurement_index,
    uint8_t request_attribute,
    const uint8_t *requester_nonce,
    uint8_t slot_id_param,
    size_t request_context_size,
    const void *request_context,
    uint8_t *content_changed,
    uint8_t *measurements_count,
    void *measurements,
    size_t *measurements_size)
{
    nsc_meas_record_params_t params;
    size_t record_size = 0U;
    uint8_t block_count = 0U;
    nsc_meas_status_t st;

    (void)spdm_context;
    (void)session_id;
    (void)requester_nonce;
    (void)slot_id_param;
    (void)request_context_size;
    (void)request_context;

    if ((measurement_specification != SPDM_MEASUREMENT_SPECIFICATION_DMTF) ||
        (measurement_hash_algo == 0)) {
        return LIBSPDM_STATUS_UNSUPPORTED_CAP;
    }

    /* Delegate record assembly to the secure world. It owns the measurement
     * policy and hashes the digest blocks with the negotiated algorithm. */
    params.measurement_hash_algo = measurement_hash_algo;
    params.measurement_index = measurement_index;
    params.record = (uint8_t *)measurements;
    params.record_cap = (measurements == NULL) ? 0U : *measurements_size;
    params.record_size = &record_size;
    params.block_count = &block_count;

    st = nsc_get_measurement_record(&params);
    if (st != NSC_MEAS_SUCCESS) {
        if (st == NSC_MEAS_ERROR_DOES_NOT_EXIST) {
            *measurements_count = 0;
        }
        return measlib_map_status(st);
    }

    *measurements_count = block_count;
    if (measurement_index !=
        SPDM_GET_MEASUREMENTS_REQUEST_MEASUREMENT_OPERATION_TOTAL_NUMBER_OF_MEASUREMENTS) {
        *measurements_size = record_size;
    }

    if ((content_changed != NULL) &&
        ((spdm_version >> SPDM_VERSION_NUMBER_SHIFT_BIT) >= SPDM_MESSAGE_VERSION_12)) {
        /* Measurements are static, so no change is ever detected. When a
         * signature is requested the response reports NO_CHANGE_DETECTED;
         * otherwise it reports that change detection is not provided. */
        if ((request_attribute &
             SPDM_GET_MEASUREMENTS_REQUEST_ATTRIBUTES_GENERATE_SIGNATURE) != 0) {
            *content_changed = SPDM_MEASUREMENTS_RESPONSE_CONTENT_NO_CHANGE_DETECTED;
        } else {
            *content_changed = SPDM_MEASUREMENTS_RESPONSE_CONTENT_CHANGE_NO_DETECTION;
        }
    }

    return LIBSPDM_STATUS_SUCCESS;
}

bool libspdm_measurement_opaque_data(
    void *spdm_context,
    const uint32_t *session_id,
    spdm_version_number_t spdm_version,
    uint8_t measurement_specification,
    uint32_t measurement_hash_algo,
    uint8_t measurement_index,
    uint8_t request_attribute,
    size_t request_context_size,
    const void *request_context,
    void *opaque_data,
    size_t *opaque_data_size)
{
    (void)spdm_context;
    (void)session_id;
    (void)spdm_version;
    (void)measurement_specification;
    (void)measurement_hash_algo;
    (void)measurement_index;
    (void)request_attribute;
    (void)request_context_size;
    (void)request_context;
    (void)opaque_data;

    /* This responder carries no measurement opaque data. */
    *opaque_data_size = 0;
    return true;
}

bool libspdm_generate_measurement_summary_hash(
    void *spdm_context,
    spdm_version_number_t spdm_version,
    uint32_t base_hash_algo,
    uint8_t measurement_specification,
    uint32_t measurement_hash_algo,
    uint8_t measurement_summary_hash_type,
    uint8_t *measurement_summary_hash,
    uint32_t measurement_summary_hash_size)
{
    nsc_meas_summary_params_t params;
    size_t summary_size = 0U;

    (void)spdm_context;
    (void)spdm_version;

    switch (measurement_summary_hash_type) {
    case SPDM_REQUEST_NO_MEASUREMENT_SUMMARY_HASH:
        return false;
    case SPDM_REQUEST_TCB_COMPONENT_MEASUREMENT_HASH:
    case SPDM_REQUEST_ALL_MEASUREMENTS_HASH:
        break;
    default:
        return false;
    }

    if ((measurement_specification != SPDM_MEASUREMENT_SPECIFICATION_DMTF) ||
        (measurement_hash_algo == 0)) {
        return false;
    }
    if (measurement_summary_hash_size != libspdm_get_hash_size(base_hash_algo)) {
        return false;
    }

    /* The record is assembled AND hashed inside the secure world, so the
     * non-secure responder cannot influence the signed summary hash. */
    params.base_hash_algo = base_hash_algo;
    params.measurement_hash_algo = measurement_hash_algo;
    params.summary_type = measurement_summary_hash_type;
    params.summary_hash = measurement_summary_hash;
    params.summary_cap = measurement_summary_hash_size;
    params.summary_size = &summary_size;

    return (nsc_get_measurement_summary(&params) == NSC_MEAS_SUCCESS);
}

#endif /* LIBSPDM_ENABLE_CAPABILITY_MEAS_CAP */
