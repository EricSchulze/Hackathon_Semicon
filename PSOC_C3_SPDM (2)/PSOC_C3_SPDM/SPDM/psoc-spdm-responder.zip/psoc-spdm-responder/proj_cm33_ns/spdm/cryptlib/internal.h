/*****************************************************************************
 * File Name        : internal.h
 *
 * Description      : Shared internals for the non-secure libspdm cryptlib
 *                    implementation (proj_cm33_ns/spdm/cryptlib/).
 *
 *                    The cryptlib is split by primitive family into one file
 *                    each (rand/hash/mac/kdf/aead). This header holds only the
 *                    handful of constants and the best-effort buffer-clear
 *                    helper shared by the HMAC (mac.c) and HKDF (kdf.c)
 *                    constructions, which run in the non-secure world on top of
 *                    the generic hash veneers.
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef SPDM_CRYPTLIB_INTERNAL_H
#define SPDM_CRYPTLIB_INTERNAL_H

#include <stddef.h>
#include <stdint.h>

/* SHA-256 digest and internal block (HMAC pad) sizes in bytes. */
#define SPDM_CRYPTLIB_SHA256_SIZE       (32U)
#define SPDM_CRYPTLIB_SHA256_BLOCK      (64U)

/* SHA-384 digest and internal block (HMAC pad) sizes in bytes. The block is the
 * SHA-512 compression block (128), not 48. */
#define SPDM_CRYPTLIB_SHA384_SIZE       (48U)
#define SPDM_CRYPTLIB_SHA384_BLOCK      (128U)

/* SHA-512 digest and internal block (HMAC pad) sizes in bytes. */
#define SPDM_CRYPTLIB_SHA512_SIZE       (64U)
#define SPDM_CRYPTLIB_SHA512_BLOCK      (128U)

/**
 * @brief Best-effort clear of a non-secure buffer that held key material.
 *
 * The non-secure world lacks mbedtls_platform_zeroize(); this volatile loop
 * prevents the compiler from optimizing the wipe away. Defense in depth only:
 * the key bytes cleared here (HMAC ipad/opad, intermediate PRK/T blocks) are
 * derived from keys libspdm already holds in non-secure memory.
 */
static inline void spdm_cryptlib_zeroize(void *buf, size_t len)
{
    volatile uint8_t *p = (volatile uint8_t *)buf;
    while (len-- != 0U) {
        *p++ = 0U;
    }
}

#endif /* SPDM_CRYPTLIB_INTERNAL_H */
