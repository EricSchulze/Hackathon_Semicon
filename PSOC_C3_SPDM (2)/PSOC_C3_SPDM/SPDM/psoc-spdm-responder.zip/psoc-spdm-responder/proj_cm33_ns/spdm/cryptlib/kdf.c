/*****************************************************************************
 * File Name        : kdf.c
 *
 * Description      : Non-secure libspdm cryptlib -- HKDF (RFC 5869) over
 *                    SHA-256 and/or SHA-384, per the profile's hash selection.
 *
 *                    HKDF runs in the NON-SECURE world, layered on the
 *                    non-secure HMAC-SHA256 (mac.c) via libspdm_hmac_sha256_all
 *                    -- which in turn runs the SHA-256 compression in the secure
 *                    world. It lives here (rather than as a secure veneer)
 *                    because it is a pure composition of HMAC, and the SPDM
 *                    input/output key material it processes is already held by
 *                    libspdm in non-secure memory. Under TF-M this maps onto the
 *                    PSA key-derivation API (psa_key_derivation_*).
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "hal/library/cryptlib.h"

#include "internal.h"

/******************************************************************************
 * Macros
 *****************************************************************************/

/* Upper bound on the HKDF-Expand info string. SPDM bin_str values are short
 * (label + context + length); 128 bytes is comfortably above the worst case. */
#define HKDF_INFO_MAX           (128U)

#if LIBSPDM_SHA256_SUPPORT

/******************************************************************************
 * HKDF-SHA256 (cryptlib_hkdf.h)
 *****************************************************************************/

bool libspdm_hkdf_sha256_extract(const uint8_t *key, size_t key_size,
                                 const uint8_t *salt, size_t salt_size,
                                 uint8_t *prk_out, size_t prk_out_size)
{
    uint8_t zero_salt[SPDM_CRYPTLIB_SHA256_SIZE];

    if ((prk_out == NULL) || (prk_out_size != SPDM_CRYPTLIB_SHA256_SIZE)) {
        return false;
    }

    /* PRK = HMAC(salt, IKM). An empty salt defaults to HashLen zero bytes. */
    if ((salt == NULL) || (salt_size == 0U)) {
        (void)memset(zero_salt, 0, sizeof(zero_salt));
        return libspdm_hmac_sha256_all(key, key_size, zero_salt,
                                       sizeof(zero_salt), prk_out);
    }
    return libspdm_hmac_sha256_all(key, key_size, salt, salt_size, prk_out);
}

bool libspdm_hkdf_sha256_expand(const uint8_t *prk, size_t prk_size,
                                const uint8_t *info, size_t info_size,
                                uint8_t *out, size_t out_size)
{
    uint8_t t_block[SPDM_CRYPTLIB_SHA256_SIZE];
    uint8_t msg[SPDM_CRYPTLIB_SHA256_SIZE + HKDF_INFO_MAX + 1U];
    size_t t_len = 0;
    size_t done = 0;
    uint8_t counter = 0;
    bool ok = true;

    if ((prk == NULL) || (out == NULL) || (info_size > HKDF_INFO_MAX) ||
        ((info == NULL) && (info_size != 0U))) {
        return false;
    }
    /* RFC 5869: L must be <= 255 * HashLen. */
    if (out_size > (255U * SPDM_CRYPTLIB_SHA256_SIZE)) {
        return false;
    }

    while (done < out_size) {
        size_t msg_len = 0;
        size_t chunk;

        counter++; /* T(1), T(2), ... */

        if (t_len != 0U) {
            (void)memcpy(msg, t_block, t_len);
            msg_len = t_len;
        }
        if (info_size != 0U) {
            (void)memcpy(msg + msg_len, info, info_size);
            msg_len += info_size;
        }
        msg[msg_len] = counter;
        msg_len += 1U;

        /* T(i) = HMAC(prk, T(i-1) || info || i) */
        if (!libspdm_hmac_sha256_all(msg, msg_len, prk, prk_size, t_block)) {
            ok = false;
            break;
        }
        t_len = SPDM_CRYPTLIB_SHA256_SIZE;

        chunk = out_size - done;
        if (chunk > SPDM_CRYPTLIB_SHA256_SIZE) {
            chunk = SPDM_CRYPTLIB_SHA256_SIZE;
        }
        (void)memcpy(out + done, t_block, chunk);
        done += chunk;
    }

    spdm_cryptlib_zeroize(t_block, sizeof(t_block));
    spdm_cryptlib_zeroize(msg, sizeof(msg));
    return ok;
}

#endif /* LIBSPDM_SHA256_SUPPORT */

#if LIBSPDM_SHA384_SUPPORT

/******************************************************************************
 * HKDF-SHA384 (cryptlib_hkdf.h)
 *****************************************************************************/

bool libspdm_hkdf_sha384_extract(const uint8_t *key, size_t key_size,
                                 const uint8_t *salt, size_t salt_size,
                                 uint8_t *prk_out, size_t prk_out_size)
{
    uint8_t zero_salt[SPDM_CRYPTLIB_SHA384_SIZE];

    if ((prk_out == NULL) || (prk_out_size != SPDM_CRYPTLIB_SHA384_SIZE)) {
        return false;
    }

    /* PRK = HMAC(salt, IKM). An empty salt defaults to HashLen zero bytes. */
    if ((salt == NULL) || (salt_size == 0U)) {
        (void)memset(zero_salt, 0, sizeof(zero_salt));
        return libspdm_hmac_sha384_all(key, key_size, zero_salt,
                                       sizeof(zero_salt), prk_out);
    }
    return libspdm_hmac_sha384_all(key, key_size, salt, salt_size, prk_out);
}

bool libspdm_hkdf_sha384_expand(const uint8_t *prk, size_t prk_size,
                                const uint8_t *info, size_t info_size,
                                uint8_t *out, size_t out_size)
{
    uint8_t t_block[SPDM_CRYPTLIB_SHA384_SIZE];
    uint8_t msg[SPDM_CRYPTLIB_SHA384_SIZE + HKDF_INFO_MAX + 1U];
    size_t t_len = 0;
    size_t done = 0;
    uint8_t counter = 0;
    bool ok = true;

    if ((prk == NULL) || (out == NULL) || (info_size > HKDF_INFO_MAX) ||
        ((info == NULL) && (info_size != 0U))) {
        return false;
    }
    /* RFC 5869: L must be <= 255 * HashLen. */
    if (out_size > (255U * SPDM_CRYPTLIB_SHA384_SIZE)) {
        return false;
    }

    while (done < out_size) {
        size_t msg_len = 0;
        size_t chunk;

        counter++; /* T(1), T(2), ... */

        if (t_len != 0U) {
            (void)memcpy(msg, t_block, t_len);
            msg_len = t_len;
        }
        if (info_size != 0U) {
            (void)memcpy(msg + msg_len, info, info_size);
            msg_len += info_size;
        }
        msg[msg_len] = counter;
        msg_len += 1U;

        /* T(i) = HMAC(prk, T(i-1) || info || i) */
        if (!libspdm_hmac_sha384_all(msg, msg_len, prk, prk_size, t_block)) {
            ok = false;
            break;
        }
        t_len = SPDM_CRYPTLIB_SHA384_SIZE;

        chunk = out_size - done;
        if (chunk > SPDM_CRYPTLIB_SHA384_SIZE) {
            chunk = SPDM_CRYPTLIB_SHA384_SIZE;
        }
        (void)memcpy(out + done, t_block, chunk);
        done += chunk;
    }

    spdm_cryptlib_zeroize(t_block, sizeof(t_block));
    spdm_cryptlib_zeroize(msg, sizeof(msg));
    return ok;
}

#endif /* LIBSPDM_SHA384_SUPPORT */

#if LIBSPDM_SHA512_SUPPORT

/******************************************************************************
 * HKDF-SHA512 (cryptlib_hkdf.h)
 *****************************************************************************/

bool libspdm_hkdf_sha512_extract(const uint8_t *key, size_t key_size,
                                 const uint8_t *salt, size_t salt_size,
                                 uint8_t *prk_out, size_t prk_out_size)
{
    uint8_t zero_salt[SPDM_CRYPTLIB_SHA512_SIZE];

    if ((prk_out == NULL) || (prk_out_size != SPDM_CRYPTLIB_SHA512_SIZE)) {
        return false;
    }

    /* PRK = HMAC(salt, IKM). An empty salt defaults to HashLen zero bytes. */
    if ((salt == NULL) || (salt_size == 0U)) {
        (void)memset(zero_salt, 0, sizeof(zero_salt));
        return libspdm_hmac_sha512_all(key, key_size, zero_salt,
                                       sizeof(zero_salt), prk_out);
    }
    return libspdm_hmac_sha512_all(key, key_size, salt, salt_size, prk_out);
}

bool libspdm_hkdf_sha512_expand(const uint8_t *prk, size_t prk_size,
                                const uint8_t *info, size_t info_size,
                                uint8_t *out, size_t out_size)
{
    uint8_t t_block[SPDM_CRYPTLIB_SHA512_SIZE];
    uint8_t msg[SPDM_CRYPTLIB_SHA512_SIZE + HKDF_INFO_MAX + 1U];
    size_t t_len = 0;
    size_t done = 0;
    uint8_t counter = 0;
    bool ok = true;

    if ((prk == NULL) || (out == NULL) || (info_size > HKDF_INFO_MAX) ||
        ((info == NULL) && (info_size != 0U))) {
        return false;
    }
    /* RFC 5869: L must be <= 255 * HashLen. */
    if (out_size > (255U * SPDM_CRYPTLIB_SHA512_SIZE)) {
        return false;
    }

    while (done < out_size) {
        size_t msg_len = 0;
        size_t chunk;

        counter++; /* T(1), T(2), ... */

        if (t_len != 0U) {
            (void)memcpy(msg, t_block, t_len);
            msg_len = t_len;
        }
        if (info_size != 0U) {
            (void)memcpy(msg + msg_len, info, info_size);
            msg_len += info_size;
        }
        msg[msg_len] = counter;
        msg_len += 1U;

        /* T(i) = HMAC(prk, T(i-1) || info || i) */
        if (!libspdm_hmac_sha512_all(msg, msg_len, prk, prk_size, t_block)) {
            ok = false;
            break;
        }
        t_len = SPDM_CRYPTLIB_SHA512_SIZE;

        chunk = out_size - done;
        if (chunk > SPDM_CRYPTLIB_SHA512_SIZE) {
            chunk = SPDM_CRYPTLIB_SHA512_SIZE;
        }
        (void)memcpy(out + done, t_block, chunk);
        done += chunk;
    }

    spdm_cryptlib_zeroize(t_block, sizeof(t_block));
    spdm_cryptlib_zeroize(msg, sizeof(msg));
    return ok;
}

#endif /* LIBSPDM_SHA512_SUPPORT */

/* [] END OF FILE */
