/*****************************************************************************
 * File Name        : rand.c
 *
 * Description      : Non-secure libspdm cryptlib -- random number generation.
 *
 *                    Resolves libspdm_random_bytes() by forwarding to the
 *                    PSA-shaped Non-Secure-Callable veneer
 *                    (nsc_psa_generate_random), which validates the caller's
 *                    buffer and calls the secure PSA DRBG (TRNG-seeded). No
 *                    cryptography is performed here. Under TF-M this becomes a
 *                    direct psa_generate_random() call.
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "hal/library/cryptlib.h"

#include "nsc_psa.h"

/******************************************************************************
 * RNG (cryptlib_rng.h)
 *****************************************************************************/

bool libspdm_random_bytes(uint8_t *output, size_t size)
{
    return (nsc_psa_generate_random(output, size) == NSC_PSA_SUCCESS);
}

/* [] END OF FILE */
