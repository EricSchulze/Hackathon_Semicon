/*****************************************************************************
 * File Name        : mlkem.c
 *
 * Description      : Non-secure libspdm cryptlib ML-KEM (CRYSTALS-Kyber /
 *                    FIPS-203) glue for the SPDM Responder, ML-KEM-1024 profile
 *                    (SPDM_HAVE_MLKEM1024).
 *
 *                    This translation unit provides the ML-KEM primitives of
 *                    hal/library/cryptlib/cryptlib_mlkem.h. The Responder is
 *                    the ML-KEM-1024 encapsulator in SPDM KEY_EXCHANGE: it
 *                    decodes the requester's public encapsulation key and runs
 *                    encapsulate, both of which happen in the SPE. This file
 *                    only marshals the operands across the NSC boundary --
 *                    new_by_name()/free() manage a tiny non-secure context and
 *                    encapsulate() forwards to the secure veneer
 *                    (nsc_psa_mlkem_encapsulate, shared/nsc_psa.h). No ML-KEM
 *                    key or secret material is ever handled in the non-secure
 *                    world. generate_key()/decapsulate() are not used by the
 *                    Responder role and remain fail-closed stubs.
 *
 *                    The whole file compiles to nothing in profiles without
 *                    ML-KEM because it self-guards on LIBSPDM_ML_KEM_SUPPORT,
 *                    which is 0 unless SPDM_HAVE_MLKEM1024 is enabled
 *                    (spdm/spdm_lib_config_psc3.h).
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "hal/library/cryptlib.h"

#include "nsc_psa.h"

#if LIBSPDM_ML_KEM_SUPPORT

/******************************************************************************
 * ML-KEM context lifecycle
 *
 * The Responder only supports ML-KEM-1024 and only ever encapsulates, so the
 * non-secure context carries nothing but the negotiated algorithm id (used to
 * reject a mismatched request before crossing into the SPE). A single static
 * slot is sufficient: libspdm establishes one key at a time in KEY_EXCHANGE.
 *****************************************************************************/

typedef struct {
    size_t nid;
    bool   in_use;
} ns_mlkem_ctx_t;

static ns_mlkem_ctx_t s_mlkem_ctx;

void *libspdm_mlkem_new_by_name(size_t nid)
{
    if (nid != LIBSPDM_CRYPTO_NID_ML_KEM_1024) {
        return NULL;
    }
    if (s_mlkem_ctx.in_use) {
        return NULL;
    }
    s_mlkem_ctx.in_use = true;
    s_mlkem_ctx.nid = nid;
    return &s_mlkem_ctx;
}

void libspdm_mlkem_free(void *kem_context)
{
    ns_mlkem_ctx_t *c = (ns_mlkem_ctx_t *)kem_context;

    if (c == NULL) {
        return;
    }
    c->nid = 0U;
    c->in_use = false;
}

/******************************************************************************
 * Key generation / encapsulation / decapsulation
 *
 * The Responder is the KEM encapsulator in SPDM KEY_EXCHANGE: encapsulate()
 * validates the boundary sizes and forwards to the SPE veneer, which decodes
 * the peer public key and produces the ciphertext + shared secret. No secret
 * material is ever visible in the non-secure world. generate_key() and
 * decapsulate() are not used by the Responder role and fail closed.
 *****************************************************************************/

bool libspdm_mlkem_generate_key(void *kem_context, uint8_t *encap_key, size_t *encap_key_size)
{
    (void)kem_context;
    (void)encap_key;
    (void)encap_key_size;
    return false;
}

bool libspdm_mlkem_encapsulate(void *kem_context, const uint8_t *peer_encap_key,
                               size_t peer_encap_key_size, uint8_t *cipher_text,
                               size_t *cipher_text_size, uint8_t *shared_secret,
                               size_t *shared_secret_size)
{
    ns_mlkem_ctx_t *c = (ns_mlkem_ctx_t *)kem_context;
    nsc_psa_mlkem_encapsulate_params_t p;
    size_t ct_out = 0U;
    size_t ss_out = 0U;

    if ((c == NULL) || (peer_encap_key == NULL) || (cipher_text == NULL) ||
        (cipher_text_size == NULL) || (shared_secret == NULL) ||
        (shared_secret_size == NULL)) {
        return false;
    }
    if (peer_encap_key_size != NSC_PSA_MLKEM1024_PUB_LEN) {
        return false;
    }
    if ((*cipher_text_size < NSC_PSA_MLKEM1024_CT_LEN) ||
        (*shared_secret_size < NSC_PSA_MLKEM1024_SS_LEN)) {
        return false;
    }

    p.peer_encap_key = peer_encap_key;
    p.peer_encap_key_size = peer_encap_key_size;
    p.cipher_text = cipher_text;
    p.cipher_text_cap = *cipher_text_size;
    p.cipher_text_size = &ct_out;
    p.shared_secret = shared_secret;
    p.shared_secret_cap = *shared_secret_size;
    p.shared_secret_size = &ss_out;

    if (nsc_psa_mlkem_encapsulate(&p) != NSC_PSA_SUCCESS) {
        return false;
    }

    *cipher_text_size = ct_out;
    *shared_secret_size = ss_out;
    return true;
}

bool libspdm_mlkem_decapsulate(void *kem_context, const uint8_t *peer_cipher_text,
                               size_t peer_cipher_text_size, uint8_t *shared_secret,
                               size_t *shared_secret_size)
{
    (void)kem_context;
    (void)peer_cipher_text;
    (void)peer_cipher_text_size;
    (void)shared_secret;
    (void)shared_secret_size;
    return false;
}

#endif /* LIBSPDM_ML_KEM_SUPPORT */
