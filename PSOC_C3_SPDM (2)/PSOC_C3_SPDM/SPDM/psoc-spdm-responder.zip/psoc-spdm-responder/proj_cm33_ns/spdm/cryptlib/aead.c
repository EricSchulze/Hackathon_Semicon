/*****************************************************************************
 * File Name        : aead.c
 *
 * Description      : Non-secure libspdm cryptlib -- AEAD (AES-256-GCM).
 *
 *                    Forwards libspdm_aead_aes_gcm_encrypt/decrypt to the
 *                    PSA-shaped Non-Secure-Callable veneers
 *                    (nsc_psa_aead_encrypt/decrypt). The AEAD veneer is
 *                    intentionally coarse: it takes the raw session key bytes
 *                    and a SEPARATE tag buffer (matching libspdm's per-record
 *                    interface). The secure world imports the volatile key,
 *                    runs the GCM via the PSA multipart AEAD API (so ciphertext
 *                    and tag stay in separate buffers with no payload-sized
 *                    bounce), and destroys the key -- all inside the single
 *                    call. Decrypt uses a constant-time tag verify in the SPE.
 *
 *                    No cryptography or key material handling is performed in
 *                    the non-secure world here. Under TF-M, aead.c is the one
 *                    cryptlib file needing real rework rather than a mechanical
 *                    rename (import key -> PSA multipart -> destroy).
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "hal/library/cryptlib.h"

#include "nsc_psa.h"

/******************************************************************************
 * AEAD AES-GCM (cryptlib_aead.h)
 *****************************************************************************/

bool libspdm_aead_aes_gcm_encrypt(const uint8_t *key, size_t key_size,
                                  const uint8_t *iv, size_t iv_size,
                                  const uint8_t *a_data, size_t a_data_size,
                                  const uint8_t *data_in, size_t data_in_size,
                                  uint8_t *tag_out, size_t tag_size,
                                  uint8_t *data_out, size_t *data_out_size)
{
    nsc_psa_aead_encrypt_params_t p = {
        .key = key, .key_size = key_size,
        .iv = iv, .iv_size = iv_size,
        .a_data = a_data, .a_data_size = a_data_size,
        .data_in = data_in, .data_in_size = data_in_size,
        .tag_out = tag_out, .tag_size = tag_size,
        .data_out = data_out, .data_out_size = data_out_size,
    };
    return (nsc_psa_aead_encrypt(&p) == NSC_PSA_SUCCESS);
}

bool libspdm_aead_aes_gcm_decrypt(const uint8_t *key, size_t key_size,
                                  const uint8_t *iv, size_t iv_size,
                                  const uint8_t *a_data, size_t a_data_size,
                                  const uint8_t *data_in, size_t data_in_size,
                                  const uint8_t *tag, size_t tag_size,
                                  uint8_t *data_out, size_t *data_out_size)
{
    nsc_psa_aead_decrypt_params_t p = {
        .key = key, .key_size = key_size,
        .iv = iv, .iv_size = iv_size,
        .a_data = a_data, .a_data_size = a_data_size,
        .data_in = data_in, .data_in_size = data_in_size,
        .tag = tag, .tag_size = tag_size,
        .data_out = data_out, .data_out_size = data_out_size,
    };
    return (nsc_psa_aead_decrypt(&p) == NSC_PSA_SUCCESS);
}

/* [] END OF FILE */
