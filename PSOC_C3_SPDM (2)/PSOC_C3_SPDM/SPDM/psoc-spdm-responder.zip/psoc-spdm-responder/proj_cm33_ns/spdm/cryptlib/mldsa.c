/*****************************************************************************
 * File Name        : mldsa.c
 *
 * Description      : Non-secure libspdm cryptlib ML-DSA (CRYSTALS-Dilithium /
 *                    FIPS-204) glue for the SPDM Responder, ML-DSA-87 profile
 *                    (SPDM_HAVE_MLDSA87).
 *
 *                    This translation unit provides the ML-DSA primitives of
 *                    hal/library/cryptlib/cryptlib_mldsa.h. The Responder never
 *                    performs ML-DSA verification and never parses X.509, so the
 *                    verify / DER / X.509 entry points are stubbed to fail
 *                    closed. Responder ML-DSA-87 *signing* does not flow through
 *                    libspdm_mldsa_sign(): it goes through the device-secret HAL
 *                    (spdm/device_secret.c), which forwards to the wolfCrypt
 *                    ML-DSA sign service in the SPE across the NSC veneer. These
 *                    stubs exist only to resolve the libspdm crypt-library
 *                    externals; the sign stub therefore also fails closed.
 *
 *                    The whole file compiles to nothing in profiles without
 *                    ML-DSA because it self-guards on LIBSPDM_ML_DSA_SUPPORT,
 *                    which is 0 unless SPDM_HAVE_MLDSA87 is enabled
 *                    (spdm/spdm_lib_config_psc3.h).
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "hal/library/cryptlib.h"

#if LIBSPDM_ML_DSA_SUPPORT

/******************************************************************************
 * ML-DSA context lifecycle
 *
 * No non-secure ML-DSA context is ever created: signing lives in the SPE and
 * verification is not performed. new() fails closed so any accidental caller
 * gets a NULL context, and free() tolerates the NULL.
 *****************************************************************************/

void *libspdm_mldsa_new(size_t nid)
{
    (void)nid;
    return NULL;
}

void libspdm_mldsa_free(void *dsa_context)
{
    (void)dsa_context;
}

/******************************************************************************
 * Key import
 *
 * Not used by the Responder (it neither imports peer keys nor loads its own
 * ML-DSA key on the non-secure side).
 *****************************************************************************/

bool libspdm_mldsa_set_pubkey(void *dsa_context, const uint8_t *key_data, size_t key_size)
{
    (void)dsa_context;
    (void)key_data;
    (void)key_size;
    return false;
}

bool libspdm_mldsa_get_pubkey(void *dsa_context, uint8_t *key_data, size_t *key_size)
{
    (void)dsa_context;
    (void)key_data;
    (void)key_size;
    return false;
}

bool libspdm_mldsa_set_privkey(void *dsa_context, const uint8_t *key_data, size_t key_size)
{
    (void)dsa_context;
    (void)key_data;
    (void)key_size;
    return false;
}

bool libspdm_mldsa_get_public_key_from_der(const uint8_t *der_data,
                                           size_t der_size,
                                           void **dsa_context)
{
    (void)der_data;
    (void)der_size;
    (void)dsa_context;
    return false;
}

/******************************************************************************
 * X.509 public-key extraction
 *
 * Declared (in spdm/spdm_lib_config_psc3.h) to satisfy an upstream
 * call-site/guard mismatch in libspdm_crypt_pqc_asym.c, which references this
 * getter under LIBSPDM_ML_DSA_SUPPORT alone while the header only declares it
 * when LIBSPDM_CERT_PARSE_SUPPORT is also set. The Responder keeps
 * CERT_PARSE off and serves its certificate chain verbatim, so this path is
 * never taken; the stub fails closed.
 *****************************************************************************/

bool libspdm_mldsa_get_public_key_from_x509(const uint8_t *cert,
                                            size_t cert_size,
                                            void **context)
{
    (void)cert;
    (void)cert_size;
    (void)context;
    return false;
}

/******************************************************************************
 * Signature generation / verification
 *
 * Signing is performed in the SPE via the device-secret HAL, not here; this
 * entry point is only linked to resolve the libspdm crypt-library external and
 * fails closed. Verification is never performed by the Responder.
 *****************************************************************************/

bool libspdm_mldsa_sign(void *dsa_context,
                        const uint8_t *context, size_t context_size,
                        const uint8_t *message, size_t message_size,
                        uint8_t *signature, size_t *sig_size)
{
    (void)dsa_context;
    (void)context;
    (void)context_size;
    (void)message;
    (void)message_size;
    (void)signature;
    (void)sig_size;
    return false;
}

bool libspdm_mldsa_verify(void *dsa_context,
                          const uint8_t *context, size_t context_size,
                          const uint8_t *message, size_t message_size,
                          const uint8_t *signature, size_t sig_size)
{
    (void)dsa_context;
    (void)context;
    (void)context_size;
    (void)message;
    (void)message_size;
    (void)signature;
    (void)sig_size;
    return false;
}

#endif /* LIBSPDM_ML_DSA_SUPPORT */
