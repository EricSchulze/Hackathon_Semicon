/*****************************************************************************
 * File Name        : ec.c
 *
 * Description      : Non-secure libspdm cryptlib EC (Elliptic Curve) glue for
 *                    the SPDM Responder. Implements the ephemeral ECDHE P-256
 *                    key-agreement primitives of hal/library/cryptlib/
 *                    cryptlib_ec.h by forwarding to the secure PSA crypto
 *                    service through the Non-Secure-Callable EC veneers
 *                    (shared/nsc_psa.h).
 *
 *                    The libspdm EC "context" is opaque to libspdm. Here it is
 *                    a small non-secure descriptor that merely holds the handle
 *                    of a secure EC context; the ephemeral private key is
 *                    generated, held and destroyed entirely inside the SPE, and
 *                    only the public point and the shared secret cross the
 *                    boundary.
 *
 *                    The ECDSA signing / verification and the DER/X.509
 *                    public-key extraction primitives of cryptlib_ec.h are NOT
 *                    implemented here: responder signing goes through the
 *                    device-secret HAL (spdm/device_secret.c), and the
 *                    certificate-chain parsing crypto is wired with the slot-1
 *                    certificate support in a later stage.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "hal/library/cryptlib.h"

#include "nsc_psa.h"

/******************************************************************************
 * EC context lifecycle (cryptlib_ec.h)
 *****************************************************************************/

#if (LIBSPDM_ECDHE_SUPPORT) || (LIBSPDM_ECDSA_SUPPORT)

/******************************************************************************
 * Non-secure EC context pool
 *
 * Only one secure session is supported (MAX_SESSION_COUNT == 1); two contexts
 * give headroom for an in-flight generate/compute overlap. Each descriptor is
 * a thin non-secure token wrapping a secure EC context handle.
 *****************************************************************************/

#define NS_EC_CTX_COUNT     (2U)

/* NID of the active profile's ephemeral ECDHE curve (one curve per profile). */
#if LIBSPDM_ECDHE_P384_SUPPORT
#define NS_EC_EXPECTED_NID  LIBSPDM_CRYPTO_NID_SECP384R1
#elif LIBSPDM_ECDHE_P521_SUPPORT
#define NS_EC_EXPECTED_NID  LIBSPDM_CRYPTO_NID_SECP521R1
#else
#define NS_EC_EXPECTED_NID  LIBSPDM_CRYPTO_NID_SECP256R1
#endif

typedef struct {
    bool            in_use;
    nsc_psa_ec_op_t op;
} ns_ec_ctx_t;

static ns_ec_ctx_t g_ns_ec_ctx[NS_EC_CTX_COUNT];

void *libspdm_ec_new_by_nid(size_t nid)
{
    /* Only the active profile's ephemeral ECDHE curve is created here. */
    if (nid != NS_EC_EXPECTED_NID) {
        return NULL;
    }

    for (uint32_t i = 0U; i < NS_EC_CTX_COUNT; i++) {
        if (!g_ns_ec_ctx[i].in_use) {
            nsc_psa_ec_op_t op = NSC_PSA_EC_OP_NONE;
            if (nsc_psa_ec_new(&op) != NSC_PSA_SUCCESS) {
                return NULL;
            }
            g_ns_ec_ctx[i].in_use = true;
            g_ns_ec_ctx[i].op = op;
            return &g_ns_ec_ctx[i];
        }
    }
    return NULL;
}

void libspdm_ec_free(void *ec_context)
{
    ns_ec_ctx_t *c = (ns_ec_ctx_t *)ec_context;
    if (c == NULL) {
        return;
    }
    (void)nsc_psa_ec_free(c->op);
    c->op = NSC_PSA_EC_OP_NONE;
    c->in_use = false;
}

#endif /* (LIBSPDM_ECDHE_SUPPORT) || (LIBSPDM_ECDSA_SUPPORT) */

/******************************************************************************
 * ECDHE key agreement (cryptlib_ec.h)
 *****************************************************************************/

#if LIBSPDM_ECDHE_SUPPORT

bool libspdm_ec_generate_key(void *ec_context, uint8_t *public_key,
                             size_t *public_key_size)
{
    ns_ec_ctx_t *c = (ns_ec_ctx_t *)ec_context;
    size_t out_len = 0U;

    if ((c == NULL) || (public_key == NULL) || (public_key_size == NULL)) {
        return false;
    }
    if (*public_key_size < NSC_PSA_EC_PUB_LEN) {
        *public_key_size = NSC_PSA_EC_PUB_LEN;
        return false;
    }

    if (nsc_psa_ec_generate(c->op, public_key, *public_key_size, &out_len)
        != NSC_PSA_SUCCESS) {
        return false;
    }
    *public_key_size = out_len;
    return true;
}

bool libspdm_ec_compute_key(void *ec_context, const uint8_t *peer_public,
                            size_t peer_public_size, uint8_t *key,
                            size_t *key_size)
{
    ns_ec_ctx_t *c = (ns_ec_ctx_t *)ec_context;
    nsc_psa_ec_compute_params_t p;
    size_t out_len = 0U;

    if ((c == NULL) || (peer_public == NULL) || (key == NULL) ||
        (key_size == NULL)) {
        return false;
    }
    if (*key_size < NSC_PSA_EC_SECRET_LEN) {
        *key_size = NSC_PSA_EC_SECRET_LEN;
        return false;
    }

    p.op = c->op;
    p.peer_public = peer_public;
    p.peer_public_size = peer_public_size;
    p.secret = key;
    p.secret_cap = *key_size;
    p.secret_size = &out_len;

    if (nsc_psa_ec_compute(&p) != NSC_PSA_SUCCESS) {
        return false;
    }
    *key_size = out_len;
    return true;
}

#endif /* LIBSPDM_ECDHE_SUPPORT */

/* [] END OF FILE */
