/*****************************************************************************
 * File Name        : mac.c
 *
 * Description      : Non-secure libspdm cryptlib -- HMAC over SHA-256 and/or
 *                    SHA-384, per the profile's hash selection.
 *
 *                    HMAC runs in the NON-SECURE world, reconstructed on top of
 *                    the generic secure hash veneers (nsc_psa_hash_*) as
 *                    H((k ^ opad) || H((k ^ ipad) || msg)). It cannot be a
 *                    secure PSA MAC operation because the SPDM key schedule
 *                    duplicates a partially-updated HMAC context and the PSA MAC
 *                    API has no clone -- but the PSA hash API does
 *                    (psa_hash_clone, exposed here as nsc_psa_hash_clone), so
 *                    the inner streaming hash is what gets cloned. Only the
 *                    (k ^ opad) block and the inner hash handle are kept in
 *                    non-secure memory; the SHA-256 compression still executes
 *                    in the secure world.
 *
 *                    The HMAC keys handled here (SPDM finished_key etc.) are
 *                    already present in non-secure memory: libspdm derives them
 *                    from the session secrets it owns, so keeping the pad blocks
 *                    non-secure exposes nothing new. Under TF-M each hash call
 *                    below becomes a direct psa_hash_* call.
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "hal/library/cryptlib.h"

#include "nsc_psa.h"

#include "internal.h"

#if LIBSPDM_SHA256_SUPPORT

/******************************************************************************
 * Non-secure context pool
 *****************************************************************************/

#define NS_HMAC_CTX_COUNT       (4U)

typedef struct {
    bool               in_use;
    bool               key_set;
    /* (key ^ opad), retained for the outer hash at final() and duplicated by
     * duplicate(). */
    uint8_t            k_opad[SPDM_CRYPTLIB_SHA256_BLOCK];
    /* Handle of the secure streaming inner hash: H((key ^ ipad) || msg ...). */
    nsc_psa_hash_op_t  inner;
} ns_hmac_ctx_t;

static ns_hmac_ctx_t g_ns_hmac_pool[NS_HMAC_CTX_COUNT];

/******************************************************************************
 * Internal helpers
 *****************************************************************************/

/* Derive the ipad/opad blocks for the supplied key. Keys longer than the block
 * size are first hashed (FIPS 198-1) via the secure one-shot hash. */
static bool hmac_derive_pads(const uint8_t *key, size_t key_size,
                             uint8_t k_ipad[SPDM_CRYPTLIB_SHA256_BLOCK],
                             uint8_t k_opad[SPDM_CRYPTLIB_SHA256_BLOCK])
{
    uint8_t block[SPDM_CRYPTLIB_SHA256_BLOCK];

    (void)memset(block, 0, sizeof(block));

    if (key_size > SPDM_CRYPTLIB_SHA256_BLOCK) {
        if (!libspdm_sha256_hash_all(key, key_size, block)) {
            return false;
        }
    } else if (key_size != 0U) {
        (void)memcpy(block, key, key_size);
    }

    for (size_t i = 0U; i < SPDM_CRYPTLIB_SHA256_BLOCK; i++) {
        k_ipad[i] = block[i] ^ 0x36U;
        k_opad[i] = block[i] ^ 0x5CU;
    }

    spdm_cryptlib_zeroize(block, sizeof(block));
    return true;
}

/******************************************************************************
 * HMAC-SHA256 (cryptlib_mac.h)
 *****************************************************************************/

void *libspdm_hmac_sha256_new(void)
{
    for (uint32_t i = 0U; i < NS_HMAC_CTX_COUNT; i++) {
        if (!g_ns_hmac_pool[i].in_use) {
            g_ns_hmac_pool[i].in_use = true;
            g_ns_hmac_pool[i].key_set = false;
            g_ns_hmac_pool[i].inner = NSC_PSA_HASH_OP_NONE;
            (void)memset(g_ns_hmac_pool[i].k_opad, 0,
                         sizeof(g_ns_hmac_pool[i].k_opad));
            return &g_ns_hmac_pool[i];
        }
    }
    return NULL;
}

void libspdm_hmac_sha256_free(void *hmac_sha256_ctx)
{
    ns_hmac_ctx_t *ctx = (ns_hmac_ctx_t *)hmac_sha256_ctx;
    if (ctx == NULL) {
        return;
    }
    if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->inner);
        ctx->inner = NSC_PSA_HASH_OP_NONE;
    }
    spdm_cryptlib_zeroize(ctx->k_opad, sizeof(ctx->k_opad));
    ctx->key_set = false;
    ctx->in_use = false;
}

bool libspdm_hmac_sha256_set_key(void *hmac_sha256_ctx, const uint8_t *key,
                                 size_t key_size)
{
    ns_hmac_ctx_t *ctx = (ns_hmac_ctx_t *)hmac_sha256_ctx;
    uint8_t k_ipad[SPDM_CRYPTLIB_SHA256_BLOCK];
    bool ok = false;

    if (ctx == NULL) {
        return false;
    }
    if (!hmac_derive_pads(key, key_size, k_ipad, ctx->k_opad)) {
        return false;
    }

    if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->inner);
        ctx->inner = NSC_PSA_HASH_OP_NONE;
    }
    if (nsc_psa_hash_setup(&ctx->inner, NSC_PSA_ALG_SHA_256) ==
        NSC_PSA_SUCCESS) {
        ok = (nsc_psa_hash_update(ctx->inner, k_ipad, sizeof(k_ipad)) ==
              NSC_PSA_SUCCESS);
    }

    ctx->key_set = ok;
    if (!ok) {
        if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
            (void)nsc_psa_hash_abort(ctx->inner);
            ctx->inner = NSC_PSA_HASH_OP_NONE;
        }
        spdm_cryptlib_zeroize(ctx->k_opad, sizeof(ctx->k_opad));
    }
    spdm_cryptlib_zeroize(k_ipad, sizeof(k_ipad));
    return ok;
}

bool libspdm_hmac_sha256_duplicate(const void *hmac_sha256_ctx,
                                   void *new_hmac_sha256_ctx)
{
    const ns_hmac_ctx_t *src = (const ns_hmac_ctx_t *)hmac_sha256_ctx;
    ns_hmac_ctx_t *dst = (ns_hmac_ctx_t *)new_hmac_sha256_ctx;

    if ((src == NULL) || (dst == NULL) || !src->key_set) {
        return false;
    }
    if (dst->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(dst->inner);
        dst->inner = NSC_PSA_HASH_OP_NONE;
    }
    if (nsc_psa_hash_clone(src->inner, &dst->inner) != NSC_PSA_SUCCESS) {
        return false;
    }
    (void)memcpy(dst->k_opad, src->k_opad, sizeof(dst->k_opad));
    dst->key_set = true;
    return true;
}

bool libspdm_hmac_sha256_update(void *hmac_sha256_ctx, const void *data,
                                size_t data_size)
{
    ns_hmac_ctx_t *ctx = (ns_hmac_ctx_t *)hmac_sha256_ctx;
    if ((ctx == NULL) || !ctx->key_set) {
        return false;
    }
    return (nsc_psa_hash_update(ctx->inner, (const uint8_t *)data,
                                 data_size) == NSC_PSA_SUCCESS);
}

bool libspdm_hmac_sha256_final(void *hmac_sha256_ctx, uint8_t *hmac_value)
{
    ns_hmac_ctx_t *ctx = (ns_hmac_ctx_t *)hmac_sha256_ctx;
    uint8_t inner_hash[SPDM_CRYPTLIB_SHA256_SIZE];
    uint8_t outer_buf[SPDM_CRYPTLIB_SHA256_BLOCK + SPDM_CRYPTLIB_SHA256_SIZE];
    size_t inner_len = 0;
    nsc_psa_status_t st;
    bool ok = false;

    if ((ctx == NULL) || !ctx->key_set) {
        return false;
    }

    st = nsc_psa_hash_finish(ctx->inner, inner_hash, sizeof(inner_hash),
                              &inner_len);
    /* finish() consumes the secure inner operation. */
    ctx->inner = NSC_PSA_HASH_OP_NONE;
    ctx->key_set = false;

    if ((st == NSC_PSA_SUCCESS) && (inner_len == SPDM_CRYPTLIB_SHA256_SIZE)) {
        (void)memcpy(outer_buf, ctx->k_opad, sizeof(ctx->k_opad));
        (void)memcpy(outer_buf + sizeof(ctx->k_opad), inner_hash,
                     sizeof(inner_hash));
        ok = libspdm_sha256_hash_all(outer_buf, sizeof(outer_buf), hmac_value);
    }

    spdm_cryptlib_zeroize(inner_hash, sizeof(inner_hash));
    spdm_cryptlib_zeroize(outer_buf, sizeof(outer_buf));
    return ok;
}

bool libspdm_hmac_sha256_all(const void *data, size_t data_size,
                             const uint8_t *key, size_t key_size,
                             uint8_t *hmac_value)
{
    uint8_t k_ipad[SPDM_CRYPTLIB_SHA256_BLOCK];
    uint8_t k_opad[SPDM_CRYPTLIB_SHA256_BLOCK];
    uint8_t inner_hash[SPDM_CRYPTLIB_SHA256_SIZE];
    uint8_t outer_buf[SPDM_CRYPTLIB_SHA256_BLOCK + SPDM_CRYPTLIB_SHA256_SIZE];
    nsc_psa_hash_op_t op = NSC_PSA_HASH_OP_NONE;
    size_t inner_len = 0;
    bool ok = false;

    if (!hmac_derive_pads(key, key_size, k_ipad, k_opad)) {
        return false;
    }

    /* inner_hash = H((key ^ ipad) || msg) */
    if ((nsc_psa_hash_setup(&op, NSC_PSA_ALG_SHA_256) == NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_update(op, k_ipad, sizeof(k_ipad)) ==
         NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_update(op, (const uint8_t *)data, data_size) ==
         NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_finish(op, inner_hash, sizeof(inner_hash), &inner_len) ==
         NSC_PSA_SUCCESS) &&
        (inner_len == SPDM_CRYPTLIB_SHA256_SIZE)) {
        /* finish() consumed the operation. hmac = H((key ^ opad) || inner) */
        op = NSC_PSA_HASH_OP_NONE;
        (void)memcpy(outer_buf, k_opad, sizeof(k_opad));
        (void)memcpy(outer_buf + sizeof(k_opad), inner_hash,
                     sizeof(inner_hash));
        ok = libspdm_sha256_hash_all(outer_buf, sizeof(outer_buf), hmac_value);
    }

    if (op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(op);
    }
    spdm_cryptlib_zeroize(k_ipad, sizeof(k_ipad));
    spdm_cryptlib_zeroize(k_opad, sizeof(k_opad));
    spdm_cryptlib_zeroize(inner_hash, sizeof(inner_hash));
    spdm_cryptlib_zeroize(outer_buf, sizeof(outer_buf));
    return ok;
}

#endif /* LIBSPDM_SHA256_SUPPORT */

#if LIBSPDM_SHA384_SUPPORT

/******************************************************************************
 * Non-secure context pool (SHA-384)
 *****************************************************************************/

#define NS_HMAC384_CTX_COUNT    (4U)

typedef struct {
    bool               in_use;
    bool               key_set;
    /* (key ^ opad), retained for the outer hash at final() and duplicated by
     * duplicate(). */
    uint8_t            k_opad[SPDM_CRYPTLIB_SHA384_BLOCK];
    /* Handle of the secure streaming inner hash: H((key ^ ipad) || msg ...). */
    nsc_psa_hash_op_t  inner;
} ns_hmac384_ctx_t;

static ns_hmac384_ctx_t g_ns_hmac384_pool[NS_HMAC384_CTX_COUNT];

/******************************************************************************
 * Internal helpers (SHA-384)
 *****************************************************************************/

/* Derive the ipad/opad blocks for the supplied key. Keys longer than the block
 * size are first hashed (FIPS 198-1) via the secure one-shot hash. */
static bool hmac384_derive_pads(const uint8_t *key, size_t key_size,
                                uint8_t k_ipad[SPDM_CRYPTLIB_SHA384_BLOCK],
                                uint8_t k_opad[SPDM_CRYPTLIB_SHA384_BLOCK])
{
    uint8_t block[SPDM_CRYPTLIB_SHA384_BLOCK];

    (void)memset(block, 0, sizeof(block));

    if (key_size > SPDM_CRYPTLIB_SHA384_BLOCK) {
        if (!libspdm_sha384_hash_all(key, key_size, block)) {
            return false;
        }
    } else if (key_size != 0U) {
        (void)memcpy(block, key, key_size);
    }

    for (size_t i = 0U; i < SPDM_CRYPTLIB_SHA384_BLOCK; i++) {
        k_ipad[i] = block[i] ^ 0x36U;
        k_opad[i] = block[i] ^ 0x5CU;
    }

    spdm_cryptlib_zeroize(block, sizeof(block));
    return true;
}

/******************************************************************************
 * HMAC-SHA384 (cryptlib_mac.h)
 *****************************************************************************/

void *libspdm_hmac_sha384_new(void)
{
    for (uint32_t i = 0U; i < NS_HMAC384_CTX_COUNT; i++) {
        if (!g_ns_hmac384_pool[i].in_use) {
            g_ns_hmac384_pool[i].in_use = true;
            g_ns_hmac384_pool[i].key_set = false;
            g_ns_hmac384_pool[i].inner = NSC_PSA_HASH_OP_NONE;
            (void)memset(g_ns_hmac384_pool[i].k_opad, 0,
                         sizeof(g_ns_hmac384_pool[i].k_opad));
            return &g_ns_hmac384_pool[i];
        }
    }
    return NULL;
}

void libspdm_hmac_sha384_free(void *hmac_sha384_ctx)
{
    ns_hmac384_ctx_t *ctx = (ns_hmac384_ctx_t *)hmac_sha384_ctx;
    if (ctx == NULL) {
        return;
    }
    if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->inner);
        ctx->inner = NSC_PSA_HASH_OP_NONE;
    }
    spdm_cryptlib_zeroize(ctx->k_opad, sizeof(ctx->k_opad));
    ctx->key_set = false;
    ctx->in_use = false;
}

bool libspdm_hmac_sha384_set_key(void *hmac_sha384_ctx, const uint8_t *key,
                                 size_t key_size)
{
    ns_hmac384_ctx_t *ctx = (ns_hmac384_ctx_t *)hmac_sha384_ctx;
    uint8_t k_ipad[SPDM_CRYPTLIB_SHA384_BLOCK];
    bool ok = false;

    if (ctx == NULL) {
        return false;
    }
    if (!hmac384_derive_pads(key, key_size, k_ipad, ctx->k_opad)) {
        return false;
    }

    if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->inner);
        ctx->inner = NSC_PSA_HASH_OP_NONE;
    }
    if (nsc_psa_hash_setup(&ctx->inner, NSC_PSA_ALG_SHA_384) ==
        NSC_PSA_SUCCESS) {
        ok = (nsc_psa_hash_update(ctx->inner, k_ipad, sizeof(k_ipad)) ==
              NSC_PSA_SUCCESS);
    }

    ctx->key_set = ok;
    if (!ok) {
        if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
            (void)nsc_psa_hash_abort(ctx->inner);
            ctx->inner = NSC_PSA_HASH_OP_NONE;
        }
        spdm_cryptlib_zeroize(ctx->k_opad, sizeof(ctx->k_opad));
    }
    spdm_cryptlib_zeroize(k_ipad, sizeof(k_ipad));
    return ok;
}

bool libspdm_hmac_sha384_duplicate(const void *hmac_sha384_ctx,
                                   void *new_hmac_sha384_ctx)
{
    const ns_hmac384_ctx_t *src = (const ns_hmac384_ctx_t *)hmac_sha384_ctx;
    ns_hmac384_ctx_t *dst = (ns_hmac384_ctx_t *)new_hmac_sha384_ctx;

    if ((src == NULL) || (dst == NULL) || !src->key_set) {
        return false;
    }
    if (dst->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(dst->inner);
        dst->inner = NSC_PSA_HASH_OP_NONE;
    }
    if (nsc_psa_hash_clone(src->inner, &dst->inner) != NSC_PSA_SUCCESS) {
        return false;
    }
    (void)memcpy(dst->k_opad, src->k_opad, sizeof(dst->k_opad));
    dst->key_set = true;
    return true;
}

bool libspdm_hmac_sha384_update(void *hmac_sha384_ctx, const void *data,
                                size_t data_size)
{
    ns_hmac384_ctx_t *ctx = (ns_hmac384_ctx_t *)hmac_sha384_ctx;
    if ((ctx == NULL) || !ctx->key_set) {
        return false;
    }
    return (nsc_psa_hash_update(ctx->inner, (const uint8_t *)data,
                                 data_size) == NSC_PSA_SUCCESS);
}

bool libspdm_hmac_sha384_final(void *hmac_sha384_ctx, uint8_t *hmac_value)
{
    ns_hmac384_ctx_t *ctx = (ns_hmac384_ctx_t *)hmac_sha384_ctx;
    uint8_t inner_hash[SPDM_CRYPTLIB_SHA384_SIZE];
    uint8_t outer_buf[SPDM_CRYPTLIB_SHA384_BLOCK + SPDM_CRYPTLIB_SHA384_SIZE];
    size_t inner_len = 0;
    nsc_psa_status_t st;
    bool ok = false;

    if ((ctx == NULL) || !ctx->key_set) {
        return false;
    }

    st = nsc_psa_hash_finish(ctx->inner, inner_hash, sizeof(inner_hash),
                              &inner_len);
    /* finish() consumes the secure inner operation. */
    ctx->inner = NSC_PSA_HASH_OP_NONE;
    ctx->key_set = false;

    if ((st == NSC_PSA_SUCCESS) && (inner_len == SPDM_CRYPTLIB_SHA384_SIZE)) {
        (void)memcpy(outer_buf, ctx->k_opad, sizeof(ctx->k_opad));
        (void)memcpy(outer_buf + sizeof(ctx->k_opad), inner_hash,
                     sizeof(inner_hash));
        ok = libspdm_sha384_hash_all(outer_buf, sizeof(outer_buf), hmac_value);
    }

    spdm_cryptlib_zeroize(inner_hash, sizeof(inner_hash));
    spdm_cryptlib_zeroize(outer_buf, sizeof(outer_buf));
    return ok;
}

bool libspdm_hmac_sha384_all(const void *data, size_t data_size,
                             const uint8_t *key, size_t key_size,
                             uint8_t *hmac_value)
{
    uint8_t k_ipad[SPDM_CRYPTLIB_SHA384_BLOCK];
    uint8_t k_opad[SPDM_CRYPTLIB_SHA384_BLOCK];
    uint8_t inner_hash[SPDM_CRYPTLIB_SHA384_SIZE];
    uint8_t outer_buf[SPDM_CRYPTLIB_SHA384_BLOCK + SPDM_CRYPTLIB_SHA384_SIZE];
    nsc_psa_hash_op_t op = NSC_PSA_HASH_OP_NONE;
    size_t inner_len = 0;
    bool ok = false;

    if (!hmac384_derive_pads(key, key_size, k_ipad, k_opad)) {
        return false;
    }

    /* inner_hash = H((key ^ ipad) || msg) */
    if ((nsc_psa_hash_setup(&op, NSC_PSA_ALG_SHA_384) == NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_update(op, k_ipad, sizeof(k_ipad)) ==
         NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_update(op, (const uint8_t *)data, data_size) ==
         NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_finish(op, inner_hash, sizeof(inner_hash), &inner_len) ==
         NSC_PSA_SUCCESS) &&
        (inner_len == SPDM_CRYPTLIB_SHA384_SIZE)) {
        /* finish() consumed the operation. hmac = H((key ^ opad) || inner) */
        op = NSC_PSA_HASH_OP_NONE;
        (void)memcpy(outer_buf, k_opad, sizeof(k_opad));
        (void)memcpy(outer_buf + sizeof(k_opad), inner_hash,
                     sizeof(inner_hash));
        ok = libspdm_sha384_hash_all(outer_buf, sizeof(outer_buf), hmac_value);
    }

    if (op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(op);
    }
    spdm_cryptlib_zeroize(k_ipad, sizeof(k_ipad));
    spdm_cryptlib_zeroize(k_opad, sizeof(k_opad));
    spdm_cryptlib_zeroize(inner_hash, sizeof(inner_hash));
    spdm_cryptlib_zeroize(outer_buf, sizeof(outer_buf));
    return ok;
}

#endif /* LIBSPDM_SHA384_SUPPORT */

#if LIBSPDM_SHA512_SUPPORT

/******************************************************************************
 * Non-secure context pool (SHA-512)
 *****************************************************************************/

#define NS_HMAC512_CTX_COUNT    (4U)

typedef struct {
    bool               in_use;
    bool               key_set;
    /* (key ^ opad), retained for the outer hash at final() and duplicated by
     * duplicate(). */
    uint8_t            k_opad[SPDM_CRYPTLIB_SHA512_BLOCK];
    /* Handle of the secure streaming inner hash: H((key ^ ipad) || msg ...). */
    nsc_psa_hash_op_t  inner;
} ns_hmac512_ctx_t;

static ns_hmac512_ctx_t g_ns_hmac512_pool[NS_HMAC512_CTX_COUNT];

/******************************************************************************
 * Internal helpers (SHA-512)
 *****************************************************************************/

/* Derive the ipad/opad blocks for the supplied key. Keys longer than the block
 * size are first hashed (FIPS 198-1) via the secure one-shot hash. */
static bool hmac512_derive_pads(const uint8_t *key, size_t key_size,
                                uint8_t k_ipad[SPDM_CRYPTLIB_SHA512_BLOCK],
                                uint8_t k_opad[SPDM_CRYPTLIB_SHA512_BLOCK])
{
    uint8_t block[SPDM_CRYPTLIB_SHA512_BLOCK];

    (void)memset(block, 0, sizeof(block));

    if (key_size > SPDM_CRYPTLIB_SHA512_BLOCK) {
        if (!libspdm_sha512_hash_all(key, key_size, block)) {
            return false;
        }
    } else if (key_size != 0U) {
        (void)memcpy(block, key, key_size);
    }

    for (size_t i = 0U; i < SPDM_CRYPTLIB_SHA512_BLOCK; i++) {
        k_ipad[i] = block[i] ^ 0x36U;
        k_opad[i] = block[i] ^ 0x5CU;
    }

    spdm_cryptlib_zeroize(block, sizeof(block));
    return true;
}

/******************************************************************************
 * HMAC-SHA512 (cryptlib_mac.h)
 *****************************************************************************/

void *libspdm_hmac_sha512_new(void)
{
    for (uint32_t i = 0U; i < NS_HMAC512_CTX_COUNT; i++) {
        if (!g_ns_hmac512_pool[i].in_use) {
            g_ns_hmac512_pool[i].in_use = true;
            g_ns_hmac512_pool[i].key_set = false;
            g_ns_hmac512_pool[i].inner = NSC_PSA_HASH_OP_NONE;
            (void)memset(g_ns_hmac512_pool[i].k_opad, 0,
                         sizeof(g_ns_hmac512_pool[i].k_opad));
            return &g_ns_hmac512_pool[i];
        }
    }
    return NULL;
}

void libspdm_hmac_sha512_free(void *hmac_sha512_ctx)
{
    ns_hmac512_ctx_t *ctx = (ns_hmac512_ctx_t *)hmac_sha512_ctx;
    if (ctx == NULL) {
        return;
    }
    if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->inner);
        ctx->inner = NSC_PSA_HASH_OP_NONE;
    }
    spdm_cryptlib_zeroize(ctx->k_opad, sizeof(ctx->k_opad));
    ctx->key_set = false;
    ctx->in_use = false;
}

bool libspdm_hmac_sha512_set_key(void *hmac_sha512_ctx, const uint8_t *key,
                                 size_t key_size)
{
    ns_hmac512_ctx_t *ctx = (ns_hmac512_ctx_t *)hmac_sha512_ctx;
    uint8_t k_ipad[SPDM_CRYPTLIB_SHA512_BLOCK];
    bool ok = false;

    if (ctx == NULL) {
        return false;
    }
    if (!hmac512_derive_pads(key, key_size, k_ipad, ctx->k_opad)) {
        return false;
    }

    if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->inner);
        ctx->inner = NSC_PSA_HASH_OP_NONE;
    }
    if (nsc_psa_hash_setup(&ctx->inner, NSC_PSA_ALG_SHA_512) ==
        NSC_PSA_SUCCESS) {
        ok = (nsc_psa_hash_update(ctx->inner, k_ipad, sizeof(k_ipad)) ==
              NSC_PSA_SUCCESS);
    }

    ctx->key_set = ok;
    if (!ok) {
        if (ctx->inner != NSC_PSA_HASH_OP_NONE) {
            (void)nsc_psa_hash_abort(ctx->inner);
            ctx->inner = NSC_PSA_HASH_OP_NONE;
        }
        spdm_cryptlib_zeroize(ctx->k_opad, sizeof(ctx->k_opad));
    }
    spdm_cryptlib_zeroize(k_ipad, sizeof(k_ipad));
    return ok;
}

bool libspdm_hmac_sha512_duplicate(const void *hmac_sha512_ctx,
                                   void *new_hmac_sha512_ctx)
{
    const ns_hmac512_ctx_t *src = (const ns_hmac512_ctx_t *)hmac_sha512_ctx;
    ns_hmac512_ctx_t *dst = (ns_hmac512_ctx_t *)new_hmac_sha512_ctx;

    if ((src == NULL) || (dst == NULL) || !src->key_set) {
        return false;
    }
    if (dst->inner != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(dst->inner);
        dst->inner = NSC_PSA_HASH_OP_NONE;
    }
    if (nsc_psa_hash_clone(src->inner, &dst->inner) != NSC_PSA_SUCCESS) {
        return false;
    }
    (void)memcpy(dst->k_opad, src->k_opad, sizeof(dst->k_opad));
    dst->key_set = true;
    return true;
}

bool libspdm_hmac_sha512_update(void *hmac_sha512_ctx, const void *data,
                                size_t data_size)
{
    ns_hmac512_ctx_t *ctx = (ns_hmac512_ctx_t *)hmac_sha512_ctx;
    if ((ctx == NULL) || !ctx->key_set) {
        return false;
    }
    return (nsc_psa_hash_update(ctx->inner, (const uint8_t *)data,
                                 data_size) == NSC_PSA_SUCCESS);
}

bool libspdm_hmac_sha512_final(void *hmac_sha512_ctx, uint8_t *hmac_value)
{
    ns_hmac512_ctx_t *ctx = (ns_hmac512_ctx_t *)hmac_sha512_ctx;
    uint8_t inner_hash[SPDM_CRYPTLIB_SHA512_SIZE];
    uint8_t outer_buf[SPDM_CRYPTLIB_SHA512_BLOCK + SPDM_CRYPTLIB_SHA512_SIZE];
    size_t inner_len = 0;
    nsc_psa_status_t st;
    bool ok = false;

    if ((ctx == NULL) || !ctx->key_set) {
        return false;
    }

    st = nsc_psa_hash_finish(ctx->inner, inner_hash, sizeof(inner_hash),
                              &inner_len);
    /* finish() consumes the secure inner operation. */
    ctx->inner = NSC_PSA_HASH_OP_NONE;
    ctx->key_set = false;

    if ((st == NSC_PSA_SUCCESS) && (inner_len == SPDM_CRYPTLIB_SHA512_SIZE)) {
        (void)memcpy(outer_buf, ctx->k_opad, sizeof(ctx->k_opad));
        (void)memcpy(outer_buf + sizeof(ctx->k_opad), inner_hash,
                     sizeof(inner_hash));
        ok = libspdm_sha512_hash_all(outer_buf, sizeof(outer_buf), hmac_value);
    }

    spdm_cryptlib_zeroize(inner_hash, sizeof(inner_hash));
    spdm_cryptlib_zeroize(outer_buf, sizeof(outer_buf));
    return ok;
}

bool libspdm_hmac_sha512_all(const void *data, size_t data_size,
                             const uint8_t *key, size_t key_size,
                             uint8_t *hmac_value)
{
    uint8_t k_ipad[SPDM_CRYPTLIB_SHA512_BLOCK];
    uint8_t k_opad[SPDM_CRYPTLIB_SHA512_BLOCK];
    uint8_t inner_hash[SPDM_CRYPTLIB_SHA512_SIZE];
    uint8_t outer_buf[SPDM_CRYPTLIB_SHA512_BLOCK + SPDM_CRYPTLIB_SHA512_SIZE];
    nsc_psa_hash_op_t op = NSC_PSA_HASH_OP_NONE;
    size_t inner_len = 0;
    bool ok = false;

    if (!hmac512_derive_pads(key, key_size, k_ipad, k_opad)) {
        return false;
    }

    /* inner_hash = H((key ^ ipad) || msg) */
    if ((nsc_psa_hash_setup(&op, NSC_PSA_ALG_SHA_512) == NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_update(op, k_ipad, sizeof(k_ipad)) ==
         NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_update(op, (const uint8_t *)data, data_size) ==
         NSC_PSA_SUCCESS) &&
        (nsc_psa_hash_finish(op, inner_hash, sizeof(inner_hash), &inner_len) ==
         NSC_PSA_SUCCESS) &&
        (inner_len == SPDM_CRYPTLIB_SHA512_SIZE)) {
        /* finish() consumed the operation. hmac = H((key ^ opad) || inner) */
        op = NSC_PSA_HASH_OP_NONE;
        (void)memcpy(outer_buf, k_opad, sizeof(k_opad));
        (void)memcpy(outer_buf + sizeof(k_opad), inner_hash,
                     sizeof(inner_hash));
        ok = libspdm_sha512_hash_all(outer_buf, sizeof(outer_buf), hmac_value);
    }

    if (op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(op);
    }
    spdm_cryptlib_zeroize(k_ipad, sizeof(k_ipad));
    spdm_cryptlib_zeroize(k_opad, sizeof(k_opad));
    spdm_cryptlib_zeroize(inner_hash, sizeof(inner_hash));
    spdm_cryptlib_zeroize(outer_buf, sizeof(outer_buf));
    return ok;
}

#endif /* LIBSPDM_SHA512_SUPPORT */

/* [] END OF FILE */
