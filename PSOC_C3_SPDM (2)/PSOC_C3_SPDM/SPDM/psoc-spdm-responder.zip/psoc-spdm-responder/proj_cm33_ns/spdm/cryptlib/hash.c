/*****************************************************************************
 * File Name        : hash.c
 *
 * Description      : Non-secure libspdm cryptlib -- SHA-256 / SHA-384 / SHA-512.
 *
 *                    Resolves the libspdm_sha256_* / libspdm_sha384_* /
 *                    libspdm_sha512_* streaming + one-shot hash interface on top
 *                    of the PSA-shaped
 *                    multipart-hash veneers (nsc_psa_hash_*). One digest family
 *                    is compiled per the profile's hash selection (SHA-256,
 *                    SHA-384, and/or SHA-512).
 *                    The hash state lives in the secure world; libspdm holds an
 *                    opaque context that here carries only the secure operation
 *                    handle. No cryptography is performed in the non-secure
 *                    world.
 *
 *                    libspdm passes the SAME context pointer to init/update/
 *                    final, so the secure handle cannot be packed into the
 *                    pointer value (init would have nowhere to store it): a
 *                    small fixed non-secure pool holds one handle cell per live
 *                    context and libspdm receives a pointer to the cell.
 *
 *                    Under TF-M each forwarder becomes a direct psa_hash_*
 *                    call, with a real psa_hash_operation_t in place of the
 *                    handle cell.
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "hal/library/cryptlib.h"

#include "nsc_psa.h"

#include "internal.h"

/******************************************************************************
 * Non-secure context pool
 *
 * One cell per live hash context. Each cell holds only the opaque secure
 * hash-operation handle; the actual hash state lives in the secure world.
 * Exactly one digest family is compiled per the profile's hash selection
 * (SHA-256 and/or SHA-384), matching the libspdm config support macros.
 *****************************************************************************/

typedef struct {
    bool               in_use;
    nsc_psa_hash_op_t  op;
} ns_hash_ctx_t;

#if LIBSPDM_SHA256_SUPPORT

#define NS_SHA256_CTX_COUNT     (6U)

static ns_hash_ctx_t g_ns_hash_pool[NS_SHA256_CTX_COUNT];

/******************************************************************************
 * SHA-256 (cryptlib_hash.h)
 *****************************************************************************/

void *libspdm_sha256_new(void)
{
    for (uint32_t i = 0U; i < NS_SHA256_CTX_COUNT; i++) {
        if (!g_ns_hash_pool[i].in_use) {
            g_ns_hash_pool[i].in_use = true;
            g_ns_hash_pool[i].op = NSC_PSA_HASH_OP_NONE;
            return &g_ns_hash_pool[i];
        }
    }
    return NULL;
}

void libspdm_sha256_free(void *sha256_context)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha256_context;
    if (ctx == NULL) {
        return;
    }
    if (ctx->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->op);
        ctx->op = NSC_PSA_HASH_OP_NONE;
    }
    ctx->in_use = false;
}

bool libspdm_sha256_init(void *sha256_context)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha256_context;
    if (ctx == NULL) {
        return false;
    }
    if (ctx->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->op);
        ctx->op = NSC_PSA_HASH_OP_NONE;
    }
    return (nsc_psa_hash_setup(&ctx->op, NSC_PSA_ALG_SHA_256) ==
            NSC_PSA_SUCCESS);
}

bool libspdm_sha256_duplicate(const void *sha256_context,
                              void *new_sha256_context)
{
    const ns_hash_ctx_t *src = (const ns_hash_ctx_t *)sha256_context;
    ns_hash_ctx_t *dst = (ns_hash_ctx_t *)new_sha256_context;
    if ((src == NULL) || (dst == NULL)) {
        return false;
    }
    if (dst->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(dst->op);
        dst->op = NSC_PSA_HASH_OP_NONE;
    }
    return (nsc_psa_hash_clone(src->op, &dst->op) == NSC_PSA_SUCCESS);
}

bool libspdm_sha256_update(void *sha256_context, const void *data,
                           size_t data_size)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha256_context;
    if (ctx == NULL) {
        return false;
    }
    return (nsc_psa_hash_update(ctx->op, (const uint8_t *)data, data_size) ==
            NSC_PSA_SUCCESS);
}

bool libspdm_sha256_final(void *sha256_context, uint8_t *hash_value)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha256_context;
    size_t hash_len = 0;
    nsc_psa_status_t st;

    if (ctx == NULL) {
        return false;
    }
    st = nsc_psa_hash_finish(ctx->op, hash_value, SPDM_CRYPTLIB_SHA256_SIZE,
                              &hash_len);
    /* finish() consumes the secure operation; the handle is now stale. */
    ctx->op = NSC_PSA_HASH_OP_NONE;
    return (st == NSC_PSA_SUCCESS) && (hash_len == SPDM_CRYPTLIB_SHA256_SIZE);
}

bool libspdm_sha256_hash_all(const void *data, size_t data_size,
                             uint8_t *hash_value)
{
    nsc_psa_hash_op_t op = NSC_PSA_HASH_OP_NONE;
    size_t hash_len = 0;
    nsc_psa_status_t st;

    /* One-shot = setup + update + finish. There is no compute veneer (it would
     * exceed the four-register CMSE argument limit), so it is recomposed here
     * from the multipart primitives -- exactly what psa_hash_compute does. */
    if (nsc_psa_hash_setup(&op, NSC_PSA_ALG_SHA_256) != NSC_PSA_SUCCESS) {
        return false;
    }
    if (nsc_psa_hash_update(op, (const uint8_t *)data, data_size) !=
        NSC_PSA_SUCCESS) {
        /* update() did not consume the operation; release the secure slot. */
        (void)nsc_psa_hash_abort(op);
        return false;
    }
    /* finish() consumes the secure operation regardless of outcome. */
    st = nsc_psa_hash_finish(op, hash_value, SPDM_CRYPTLIB_SHA256_SIZE,
                             &hash_len);
    return (st == NSC_PSA_SUCCESS) && (hash_len == SPDM_CRYPTLIB_SHA256_SIZE);
}

#endif /* LIBSPDM_SHA256_SUPPORT */

#if LIBSPDM_SHA384_SUPPORT

#define NS_SHA384_CTX_COUNT     (6U)

static ns_hash_ctx_t g_ns_hash384_pool[NS_SHA384_CTX_COUNT];

/******************************************************************************
 * SHA-384 (cryptlib_hash.h)
 *****************************************************************************/

void *libspdm_sha384_new(void)
{
    for (uint32_t i = 0U; i < NS_SHA384_CTX_COUNT; i++) {
        if (!g_ns_hash384_pool[i].in_use) {
            g_ns_hash384_pool[i].in_use = true;
            g_ns_hash384_pool[i].op = NSC_PSA_HASH_OP_NONE;
            return &g_ns_hash384_pool[i];
        }
    }
    return NULL;
}

void libspdm_sha384_free(void *sha384_context)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha384_context;
    if (ctx == NULL) {
        return;
    }
    if (ctx->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->op);
        ctx->op = NSC_PSA_HASH_OP_NONE;
    }
    ctx->in_use = false;
}

bool libspdm_sha384_init(void *sha384_context)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha384_context;
    if (ctx == NULL) {
        return false;
    }
    if (ctx->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->op);
        ctx->op = NSC_PSA_HASH_OP_NONE;
    }
    return (nsc_psa_hash_setup(&ctx->op, NSC_PSA_ALG_SHA_384) ==
            NSC_PSA_SUCCESS);
}

bool libspdm_sha384_duplicate(const void *sha384_context,
                              void *new_sha384_context)
{
    const ns_hash_ctx_t *src = (const ns_hash_ctx_t *)sha384_context;
    ns_hash_ctx_t *dst = (ns_hash_ctx_t *)new_sha384_context;
    if ((src == NULL) || (dst == NULL)) {
        return false;
    }
    if (dst->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(dst->op);
        dst->op = NSC_PSA_HASH_OP_NONE;
    }
    return (nsc_psa_hash_clone(src->op, &dst->op) == NSC_PSA_SUCCESS);
}

bool libspdm_sha384_update(void *sha384_context, const void *data,
                           size_t data_size)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha384_context;
    if (ctx == NULL) {
        return false;
    }
    return (nsc_psa_hash_update(ctx->op, (const uint8_t *)data, data_size) ==
            NSC_PSA_SUCCESS);
}

bool libspdm_sha384_final(void *sha384_context, uint8_t *hash_value)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha384_context;
    size_t hash_len = 0;
    nsc_psa_status_t st;

    if (ctx == NULL) {
        return false;
    }
    st = nsc_psa_hash_finish(ctx->op, hash_value, SPDM_CRYPTLIB_SHA384_SIZE,
                              &hash_len);
    /* finish() consumes the secure operation; the handle is now stale. */
    ctx->op = NSC_PSA_HASH_OP_NONE;
    return (st == NSC_PSA_SUCCESS) && (hash_len == SPDM_CRYPTLIB_SHA384_SIZE);
}

bool libspdm_sha384_hash_all(const void *data, size_t data_size,
                             uint8_t *hash_value)
{
    nsc_psa_hash_op_t op = NSC_PSA_HASH_OP_NONE;
    size_t hash_len = 0;
    nsc_psa_status_t st;

    /* One-shot = setup + update + finish. There is no compute veneer (it would
     * exceed the four-register CMSE argument limit), so it is recomposed here
     * from the multipart primitives -- exactly what psa_hash_compute does. */
    if (nsc_psa_hash_setup(&op, NSC_PSA_ALG_SHA_384) != NSC_PSA_SUCCESS) {
        return false;
    }
    if (nsc_psa_hash_update(op, (const uint8_t *)data, data_size) !=
        NSC_PSA_SUCCESS) {
        /* update() did not consume the operation; release the secure slot. */
        (void)nsc_psa_hash_abort(op);
        return false;
    }
    /* finish() consumes the secure operation regardless of outcome. */
    st = nsc_psa_hash_finish(op, hash_value, SPDM_CRYPTLIB_SHA384_SIZE,
                             &hash_len);
    return (st == NSC_PSA_SUCCESS) && (hash_len == SPDM_CRYPTLIB_SHA384_SIZE);
}

#endif /* LIBSPDM_SHA384_SUPPORT */

#if LIBSPDM_SHA512_SUPPORT

#define NS_SHA512_CTX_COUNT     (6U)

static ns_hash_ctx_t g_ns_hash512_pool[NS_SHA512_CTX_COUNT];

/******************************************************************************
 * SHA-512 (cryptlib_hash.h)
 *****************************************************************************/

void *libspdm_sha512_new(void)
{
    for (uint32_t i = 0U; i < NS_SHA512_CTX_COUNT; i++) {
        if (!g_ns_hash512_pool[i].in_use) {
            g_ns_hash512_pool[i].in_use = true;
            g_ns_hash512_pool[i].op = NSC_PSA_HASH_OP_NONE;
            return &g_ns_hash512_pool[i];
        }
    }
    return NULL;
}

void libspdm_sha512_free(void *sha512_context)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha512_context;
    if (ctx == NULL) {
        return;
    }
    if (ctx->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->op);
        ctx->op = NSC_PSA_HASH_OP_NONE;
    }
    ctx->in_use = false;
}

bool libspdm_sha512_init(void *sha512_context)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha512_context;
    if (ctx == NULL) {
        return false;
    }
    if (ctx->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(ctx->op);
        ctx->op = NSC_PSA_HASH_OP_NONE;
    }
    return (nsc_psa_hash_setup(&ctx->op, NSC_PSA_ALG_SHA_512) ==
            NSC_PSA_SUCCESS);
}

bool libspdm_sha512_duplicate(const void *sha512_context,
                              void *new_sha512_context)
{
    const ns_hash_ctx_t *src = (const ns_hash_ctx_t *)sha512_context;
    ns_hash_ctx_t *dst = (ns_hash_ctx_t *)new_sha512_context;
    if ((src == NULL) || (dst == NULL)) {
        return false;
    }
    if (dst->op != NSC_PSA_HASH_OP_NONE) {
        (void)nsc_psa_hash_abort(dst->op);
        dst->op = NSC_PSA_HASH_OP_NONE;
    }
    return (nsc_psa_hash_clone(src->op, &dst->op) == NSC_PSA_SUCCESS);
}

bool libspdm_sha512_update(void *sha512_context, const void *data,
                           size_t data_size)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha512_context;
    if (ctx == NULL) {
        return false;
    }
    return (nsc_psa_hash_update(ctx->op, (const uint8_t *)data, data_size) ==
            NSC_PSA_SUCCESS);
}

bool libspdm_sha512_final(void *sha512_context, uint8_t *hash_value)
{
    ns_hash_ctx_t *ctx = (ns_hash_ctx_t *)sha512_context;
    size_t hash_len = 0;
    nsc_psa_status_t st;

    if (ctx == NULL) {
        return false;
    }
    st = nsc_psa_hash_finish(ctx->op, hash_value, SPDM_CRYPTLIB_SHA512_SIZE,
                              &hash_len);
    /* finish() consumes the secure operation; the handle is now stale. */
    ctx->op = NSC_PSA_HASH_OP_NONE;
    return (st == NSC_PSA_SUCCESS) && (hash_len == SPDM_CRYPTLIB_SHA512_SIZE);
}

bool libspdm_sha512_hash_all(const void *data, size_t data_size,
                             uint8_t *hash_value)
{
    nsc_psa_hash_op_t op = NSC_PSA_HASH_OP_NONE;
    size_t hash_len = 0;
    nsc_psa_status_t st;

    /* One-shot = setup + update + finish. There is no compute veneer (it would
     * exceed the four-register CMSE argument limit), so it is recomposed here
     * from the multipart primitives -- exactly what psa_hash_compute does. */
    if (nsc_psa_hash_setup(&op, NSC_PSA_ALG_SHA_512) != NSC_PSA_SUCCESS) {
        return false;
    }
    if (nsc_psa_hash_update(op, (const uint8_t *)data, data_size) !=
        NSC_PSA_SUCCESS) {
        /* update() did not consume the operation; release the secure slot. */
        (void)nsc_psa_hash_abort(op);
        return false;
    }
    /* finish() consumes the secure operation regardless of outcome. */
    st = nsc_psa_hash_finish(op, hash_value, SPDM_CRYPTLIB_SHA512_SIZE,
                             &hash_len);
    return (st == NSC_PSA_SUCCESS) && (hash_len == SPDM_CRYPTLIB_SHA512_SIZE);
}

#endif /* LIBSPDM_SHA512_SUPPORT */

/* [] END OF FILE */
