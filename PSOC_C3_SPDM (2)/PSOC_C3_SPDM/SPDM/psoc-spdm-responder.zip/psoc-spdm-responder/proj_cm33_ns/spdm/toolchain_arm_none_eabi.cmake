#################################################################################
# \file toolchain_arm_none_eabi.cmake
# \version 1.0
#
# \brief
# CMake toolchain file for cross-compiling the libspdm Responder static
# libraries for the PSOC(TM) Control C3 Cortex-M33 non-secure core
# with the GNU Arm Embedded (arm-none-eabi) toolchain.
#
# The compile/ABI flags below EXACTLY mirror the ModusToolbox non-secure
# (proj_cm33_ns) GCC_ARM build so the produced .a archives are ABI-compatible
# with the app that links them:
#
#     -mcpu=cortex-m33 --specs=nano.specs -mthumb
#     -ffunction-sections -fdata-sections -ffat-lto-objects -g -Wall -pipe
#
# Notes:
#   * Software floating point (VFP_SELECT=softfloat on NS) => no -mfloat-abi /
#     -mfpu flags, matching the MTB NS build.
#   * The non-secure core needs NO -mcmse (that is a secure-project-only flag).
#   * Any change to these flags OR to spdm_lib_config_psc3.h requires rebuilding
#     the .a archives.
#
#################################################################################
# \copyright
# (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
# Technologies AG.  SPDX-License-Identifier: Apache-2.0
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#################################################################################

set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR arm)

# Do not try to link a full executable when probing the compiler (bare-metal).
set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

# ------------------------------------------------------------------------------
# Locate the arm-none-eabi toolchain.
#
# The MTB Make PREBUILD step passes the ModusToolbox GCC "bin" directory via
# -DARM_TOOLCHAIN_DIR=<path>. If not provided, fall back to the tools on PATH.
# ------------------------------------------------------------------------------
if(DEFINED ARM_TOOLCHAIN_DIR)
    set(_tc_prefix "${ARM_TOOLCHAIN_DIR}/")
else()
    set(_tc_prefix "")
endif()

if(CMAKE_HOST_WIN32)
    set(_tc_ext ".exe")
else()
    set(_tc_ext "")
endif()

set(CMAKE_C_COMPILER   "${_tc_prefix}arm-none-eabi-gcc${_tc_ext}")
set(CMAKE_CXX_COMPILER "${_tc_prefix}arm-none-eabi-g++${_tc_ext}")
set(CMAKE_ASM_COMPILER "${_tc_prefix}arm-none-eabi-gcc${_tc_ext}")
set(CMAKE_AR           "${_tc_prefix}arm-none-eabi-ar${_tc_ext}")
set(CMAKE_RANLIB       "${_tc_prefix}arm-none-eabi-ranlib${_tc_ext}")
set(CMAKE_OBJCOPY      "${_tc_prefix}arm-none-eabi-objcopy${_tc_ext}")
set(CMAKE_OBJDUMP      "${_tc_prefix}arm-none-eabi-objdump${_tc_ext}")

# ------------------------------------------------------------------------------
# CPU / ABI flags -- mirror the MTB non-secure GCC_ARM build exactly.
# ------------------------------------------------------------------------------
set(PSC3_NS_CORE_FLAGS
    "-mcpu=cortex-m33 --specs=nano.specs -mthumb")

set(PSC3_NS_COMMON_FLAGS
    "-ffunction-sections -fdata-sections -ffat-lto-objects -g -Wall -pipe")

set(CMAKE_C_FLAGS_INIT   "${PSC3_NS_CORE_FLAGS} ${PSC3_NS_COMMON_FLAGS}")
set(CMAKE_CXX_FLAGS_INIT "${PSC3_NS_CORE_FLAGS} ${PSC3_NS_COMMON_FLAGS} -fno-rtti -fno-exceptions")
set(CMAKE_ASM_FLAGS_INIT "${PSC3_NS_CORE_FLAGS}")

# Search for programs in the build host directories; libraries/headers only in
# the target toolchain sysroot.
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
set(CMAKE_FIND_ROOT_PATH_MODE_LIBRARY ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_INCLUDE ONLY)
set(CMAKE_FIND_ROOT_PATH_MODE_PACKAGE ONLY)
