/*****************************************************************************
 * File Name        : spdm_responder.c
 *
 * Description      : Non-secure libspdm Responder context owner. See
 *                    spdm_responder.h for the role.
 *
 *                    This module holds the single libspdm responder context and
 *                    all of its backing storage statically (no dynamic
 *                    allocation on this part). At init it:
 *                      1. initializes the context,
 *                      2. registers the DFU/I2C carrier device-I/O and buffer
 *                         callbacks (spdm_transport_dfu.c),
 *                      3. registers the MCTP transport layer
 *                         (libspdm_transport_mctp_lib, the 1-byte message-type
 *                         framing),
 *                      4. sets the scratch buffer,
 *                      5. sets the supported capabilities and the negotiated
 *                         algorithm suite (ECDSA/ECDHE P-256, SHA-256,
 *                         AES-256-GCM), and
 *                      6. loads the provisioned SPDM certificate chain from the
 *                         secure PAS (served verbatim; never parsed).
 *
 *                    The router calls spdm_responder_dispatch() once per DFU
 *                    SPDM transaction; libspdm then pulls the staged request and
 *                    pushes the response through the carrier callbacks.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "library/spdm_common_lib.h"
#include "library/spdm_responder_lib.h"
#include "library/spdm_transport_mctp_lib.h"
#include "industry_standard/spdm.h"

#include "profile.h"  /* SPDM_HAVE_* capability flags for the selected profile */

/* Internal headers provide LIBSPDM_CONTEXT_SIZE_ALL, the compile-time size of a
 * fully-featured context (SPDM context + one secured-message context). It is
 * the documented way to size a statically allocated context; the macro expands
 * to reference LIBSPDM_SECURED_MESSAGE_CONTEXT_SIZE, so both internal headers
 * are required at the point of use. */
#include "internal/libspdm_common_lib.h"
#include "internal/libspdm_secured_message_lib.h"

#include "spdm_responder.h"
#include "spdm_transport_dfu.h"
#include "nsc_cert.h"
#include "log/log.h"

/******************************************************************************
 * Macros
 *****************************************************************************/

/* PAS slot holding the provisioned SPDM certificate chain (written by the
 * provisioning application). Served to the host as SPDM certificate slot 0. */
#define SPDM_RESPONDER_PAS_CERT_SLOT    (1U)
#define SPDM_RESPONDER_SPDM_CERT_SLOT   (0U)

/* Responder capability flags: identity attestation (CERT + CHAL), signed
 * measurements (MEAS_CAP_SIG), plus a secure session (KEY_EX + ENCRYPT + MAC)
 * with chunking for the small I2C MTU. */
#define SPDM_RESPONDER_CAP_FLAGS ( \
    SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_CERT_CAP | \
    SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_CHAL_CAP | \
    SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_MEAS_CAP_SIG | \
    SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_ENCRYPT_CAP | \
    SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_MAC_CAP | \
    SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_KEY_EX_CAP | \
    SPDM_GET_CAPABILITIES_RESPONSE_FLAGS_CHUNK_CAP)

/* Compile-time upper bound on the libspdm scratch buffer, mirroring
 * libspdm_get_scratch_buffer_capacity() for our configuration. With CHUNK_CAP
 * enabled the scratch is five worst-case regions, each sized to the transport
 * unit or MAX_SPDM_MSG_SIZE (see docs). A runtime check in spdm_responder_init()
 * verifies the actual requirement fits this bound. */
#define SPDM_RESPONDER_TRANSPORT_UNIT ( \
    LIBSPDM_MAX_SPDM_MSG_SIZE + \
    LIBSPDM_TRANSPORT_HEADER_SIZE + \
    LIBSPDM_TRANSPORT_TAIL_SIZE)

#if LIBSPDM_ENABLE_CAPABILITY_CHUNK_CAP
#define SPDM_RESPONDER_SCRATCH_SIZE ( \
    SPDM_RESPONDER_TRANSPORT_UNIT +         /* secure message         */ \
    LIBSPDM_MAX_SPDM_MSG_SIZE +             /* chunk reassembly        */ \
    SPDM_RESPONDER_TRANSPORT_UNIT +         /* sender/receiver staging */ \
    SPDM_RESPONDER_TRANSPORT_UNIT +         /* large sender/receiver   */ \
    LIBSPDM_MAX_SPDM_MSG_SIZE +             /* last SPDM request       */ \
    (LIBSPDM_RESPOND_IF_READY_SUPPORT ? LIBSPDM_MAX_SPDM_MSG_SIZE : 0))
#else
#define SPDM_RESPONDER_SCRATCH_SIZE ( \
    SPDM_RESPONDER_TRANSPORT_UNIT +         /* sender/receiver staging */ \
    LIBSPDM_MAX_SPDM_MSG_SIZE +             /* last SPDM request       */ \
    (LIBSPDM_RESPOND_IF_READY_SUPPORT ? LIBSPDM_MAX_SPDM_MSG_SIZE : 0))
#endif

/******************************************************************************
 * Module State
 *****************************************************************************/

/* The libspdm responder context and its backing buffers. Aligned to a word so
 * libspdm's internal structures are naturally aligned. */
static uint64_t s_context[(LIBSPDM_CONTEXT_SIZE_ALL + sizeof(uint64_t) - 1U) /
                          sizeof(uint64_t)];
static uint8_t  s_scratch[SPDM_RESPONDER_SCRATCH_SIZE];
static uint8_t  s_cert_chain[LIBSPDM_MAX_CERT_CHAIN_SIZE];

static bool s_initialized;

/******************************************************************************
 * Local Functions
 *****************************************************************************/

/* Thin libspdm_set_data() wrappers for the fixed-width local settings. The
 * device is little-endian, matching libspdm's little-endian buffer reads, so
 * the value's address is a valid source buffer. */
static bool set_data_u8(void *ctx, libspdm_data_type_t type, uint8_t value)
{
    libspdm_data_parameter_t parameter;

    (void)memset(&parameter, 0, sizeof(parameter));
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;
    return (libspdm_set_data(ctx, type, &parameter, &value, sizeof(value)) ==
            LIBSPDM_STATUS_SUCCESS);
}

static bool set_data_u16(void *ctx, libspdm_data_type_t type, uint16_t value)
{
    libspdm_data_parameter_t parameter;

    (void)memset(&parameter, 0, sizeof(parameter));
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;
    return (libspdm_set_data(ctx, type, &parameter, &value, sizeof(value)) ==
            LIBSPDM_STATUS_SUCCESS);
}

static bool set_data_u32(void *ctx, libspdm_data_type_t type, uint32_t value)
{
    libspdm_data_parameter_t parameter;

    (void)memset(&parameter, 0, sizeof(parameter));
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;
    return (libspdm_set_data(ctx, type, &parameter, &value, sizeof(value)) ==
            LIBSPDM_STATUS_SUCCESS);
}

/* Configure the supported capabilities and the negotiated algorithm suite. */
static bool spdm_responder_set_capabilities(void *ctx)
{
    bool ok = true;

    ok = ok && set_data_u8(ctx, LIBSPDM_DATA_CAPABILITY_CT_EXPONENT, 0U);
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_CAPABILITY_FLAGS,
                            (uint32_t)SPDM_RESPONDER_CAP_FLAGS);

    /* In SPDM 1.3 the DIGESTS response reports a SupportedSlotMask (param1)
     * separate from the ProvisionedSlotMask (param2), and every provisioned
     * slot must also be marked supported. libspdm defaults this mask to 0, so
     * advertise the served slot explicitly; otherwise requesters reject the
     * DIGESTS response (SupportedSlotMask & ProvisionedSlotMask must equal the
     * ProvisionedSlotMask). */
    ok = ok && set_data_u8(ctx, LIBSPDM_DATA_LOCAL_SUPPORTED_SLOT_MASK,
                           (uint8_t)(1U << SPDM_RESPONDER_SPDM_CERT_SLOT));

    /* The local DataTransferSize and max SPDM message size are derived by
     * libspdm from the registered buffer sizes and transport layer, so they
     * are not set here. */

    /* Signed measurements are enabled (MEAS_CAP_SIG above), so the measurement
     * specification and measurement hash algorithm must be advertised. These
     * may only be set with MEAS_CAP on -- libspdm asserts that MEAS_CAP and a
     * non-zero measurement spec/hash are set together. Measurement blocks are
     * hashed with SHA-256, matching the base hash. */
    ok = ok && set_data_u8(ctx, LIBSPDM_DATA_MEASUREMENT_SPEC,
                           SPDM_MEASUREMENT_SPECIFICATION_DMTF);

    /* Advertise exactly what the selected profile enables: one signature
     * primitive, the pinned base/measurement hash, and every advertised
     * key-exchange and AEAD method. Each field is derived from the profile's
     * SPDM_HAVE_* flags / hash selectors (profile.h). */

    /* Post-quantum asym/KEM only appear from SPDM 1.4; pin the advertised
     * version to 1.4 when the profile offers them so the pqc_asym / kem tables
     * are emitted in NEGOTIATE_ALGORITHMS. Otherwise the libspdm default version
     * list (1.0 through 1.4) stands, so the connection negotiates the highest
     * version the requester also supports (up to 1.4). */
#if SPDM_HAVE_MLDSA87 || SPDM_HAVE_MLKEM1024
    ok = ok && set_data_u16(ctx, LIBSPDM_DATA_SPDM_VERSION,
                            (uint16_t)(SPDM_MESSAGE_VERSION_14 <<
                                       SPDM_VERSION_NUMBER_SHIFT_BIT));
#endif

    /* Base (transcript / key-schedule) hash -- pinned single. */
#if SPDM_BASE_HASH == SPDM_HASH_SHA512
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_BASE_HASH_ALGO,
                            SPDM_ALGORITHMS_BASE_HASH_ALGO_TPM_ALG_SHA_512);
#elif SPDM_BASE_HASH == SPDM_HASH_SHA384
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_BASE_HASH_ALGO,
                            SPDM_ALGORITHMS_BASE_HASH_ALGO_TPM_ALG_SHA_384);
#elif SPDM_BASE_HASH == SPDM_HASH_SHA256
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_BASE_HASH_ALGO,
                            SPDM_ALGORITHMS_BASE_HASH_ALGO_TPM_ALG_SHA_256);
#else
#error "spdm_responder_set_capabilities: unhandled SPDM_BASE_HASH"
#endif

    /* Measurement-block hash -- pinned single (defaults to the base hash). */
#if SPDM_MEAS_HASH == SPDM_HASH_SHA512
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_MEASUREMENT_HASH_ALGO,
                            SPDM_ALGORITHMS_MEASUREMENT_HASH_ALGO_TPM_ALG_SHA_512);
#elif SPDM_MEAS_HASH == SPDM_HASH_SHA384
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_MEASUREMENT_HASH_ALGO,
                            SPDM_ALGORITHMS_MEASUREMENT_HASH_ALGO_TPM_ALG_SHA_384);
#elif SPDM_MEAS_HASH == SPDM_HASH_SHA256
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_MEASUREMENT_HASH_ALGO,
                            SPDM_ALGORITHMS_MEASUREMENT_HASH_ALGO_TPM_ALG_SHA_256);
#else
#error "spdm_responder_set_capabilities: unhandled SPDM_MEAS_HASH"
#endif

    /* Signature primitive -- exactly one: ECDSA via base_asym, ML-DSA via pqc_asym. */
#if SPDM_HAVE_ECDSA_P256
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_BASE_ASYM_ALGO,
                            SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P256);
#elif SPDM_HAVE_ECDSA_P384
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_BASE_ASYM_ALGO,
                            SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P384);
#elif SPDM_HAVE_ECDSA_P521
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_BASE_ASYM_ALGO,
                            SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P521);
#endif
#if SPDM_HAVE_MLDSA87
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_PQC_ASYM_ALGO,
                            SPDM_ALGORITHMS_PQC_ASYM_ALGO_ML_DSA_87);
#endif

    /* Key exchange -- advertised set: ECDHE via dhe_named_group, ML-KEM via kem_alg. */
#if SPDM_HAVE_ECDHE_P256
    ok = ok && set_data_u16(ctx, LIBSPDM_DATA_DHE_NAME_GROUP,
                            SPDM_ALGORITHMS_DHE_NAMED_GROUP_SECP_256_R1);
#elif SPDM_HAVE_ECDHE_P384
    ok = ok && set_data_u16(ctx, LIBSPDM_DATA_DHE_NAME_GROUP,
                            SPDM_ALGORITHMS_DHE_NAMED_GROUP_SECP_384_R1);
#elif SPDM_HAVE_ECDHE_P521
    ok = ok && set_data_u16(ctx, LIBSPDM_DATA_DHE_NAME_GROUP,
                            SPDM_ALGORITHMS_DHE_NAMED_GROUP_SECP_521_R1);
#endif
#if SPDM_HAVE_MLKEM1024
    ok = ok && set_data_u32(ctx, LIBSPDM_DATA_KEM_ALG,
                            SPDM_ALGORITHMS_KEM_ALG_ML_KEM_1024);
#endif

    /* AEAD -- advertised set. */
#if SPDM_HAVE_AES256_GCM
    ok = ok && set_data_u16(ctx, LIBSPDM_DATA_AEAD_CIPHER_SUITE,
                            SPDM_ALGORITHMS_AEAD_CIPHER_SUITE_AES_256_GCM);
#endif
    ok = ok && set_data_u16(ctx, LIBSPDM_DATA_KEY_SCHEDULE,
                            SPDM_ALGORITHMS_KEY_SCHEDULE_SPDM);
    ok = ok && set_data_u8(ctx, LIBSPDM_DATA_OTHER_PARAMS_SUPPORT,
                           SPDM_ALGORITHMS_OPAQUE_DATA_FORMAT_1);
    return ok;
}

/* Application-message handler for an established secure session.
 *
 * libspdm invokes this (the registered "get response" fallback) for any message
 * its built-in SPDM request handlers do not process -- in particular the
 * application data a requester sends over a secure session, which arrives with
 * is_app_message == true (the requester uses libspdm_send_receive_data() with
 * is_app_message = true). By the time this runs libspdm has already decrypted
 * the SPDM Secured Message and stripped the transport/MCTP framing, so:
 *
 *   - the plaintext application payload is in `request` (request_size bytes),
 *   - `session_id` identifies the secure session, and
 *   - the reply is written to `response`, with *response_size holding the buffer
 *     capacity on input and the produced length on output; libspdm then
 *     encrypts and frames the reply back to the requester.
 *
 * For now this simply echoes the received payload back unchanged. */
static libspdm_return_t spdm_responder_process_app_message(
    void *spdm_context, const uint32_t *session_id, bool is_app_message,
    size_t request_size, const void *request,
    size_t *response_size, void *response)
{
    (void)spdm_context;

    /* This fallback only handles application data over a secure session. An
     * SPDM request reaching here means libspdm found no built-in handler for
     * it, which this responder does not support. */
    if (!is_app_message || (session_id == NULL)) {
        return LIBSPDM_STATUS_UNSUPPORTED_CAP;
    }

    if ((request == NULL) || (response == NULL) || (response_size == NULL)) {
        return LIBSPDM_STATUS_INVALID_PARAMETER;
    }

    if (request_size > *response_size) {
        return LIBSPDM_STATUS_BUFFER_TOO_SMALL;
    }

    LOG_INFO("SPDM app message: echoing %u B (session 0x%08X)",
             (unsigned int)request_size, (unsigned int)*session_id);

    (void)memcpy(response, request, request_size);
    *response_size = request_size;

    return LIBSPDM_STATUS_SUCCESS;
}

/* Read the provisioned SPDM certificate chain from the secure PAS and hand it
 * to libspdm to serve verbatim for GET_CERTIFICATE / GET_DIGESTS. */
static bool spdm_responder_load_cert_chain(void *ctx)
{
    libspdm_data_parameter_t parameter;
    size_t cert_chain_size = 0U;
    nsc_cert_status_t st;

    st = nsc_read_cert_chain(SPDM_RESPONDER_PAS_CERT_SLOT, s_cert_chain,
                             sizeof(s_cert_chain), &cert_chain_size);
    if (st != NSC_CERT_SUCCESS) {
        LOG_ERR("SPDM responder: cert chain read failed (%d)", (int)st);
        return false;
    }

    (void)memset(&parameter, 0, sizeof(parameter));
    parameter.location = LIBSPDM_DATA_LOCATION_LOCAL;
    parameter.additional_data[0] = (uint8_t)SPDM_RESPONDER_SPDM_CERT_SLOT;

    if (libspdm_set_data(ctx, LIBSPDM_DATA_LOCAL_PUBLIC_CERT_CHAIN, &parameter,
                         s_cert_chain, cert_chain_size) != LIBSPDM_STATUS_SUCCESS) {
        LOG_ERR("SPDM responder: set cert chain failed");
        return false;
    }

    LOG_INFO("SPDM responder: cert chain loaded (%u B)",
             (unsigned int)cert_chain_size);
    return true;
}

/******************************************************************************
 * Public Functions
 *****************************************************************************/

bool spdm_responder_init(void)
{
    void *ctx = s_context;
    size_t scratch_needed;

    if (s_initialized) {
        return true;
    }

    if (libspdm_get_context_size() > sizeof(s_context)) {
        LOG_ERR("SPDM responder: context buffer too small (%u < %u)",
                (unsigned int)sizeof(s_context),
                (unsigned int)libspdm_get_context_size());
        return false;
    }

    if (libspdm_init_context(ctx) != LIBSPDM_STATUS_SUCCESS) {
        LOG_ERR("SPDM responder: init_context failed");
        return false;
    }

    libspdm_register_device_io_func(ctx,
                                    spdm_transport_dfu_send_message,
                                    spdm_transport_dfu_receive_message);

    libspdm_register_transport_layer_func(ctx,
                                          LIBSPDM_MAX_SPDM_MSG_SIZE,
                                          LIBSPDM_TRANSPORT_HEADER_SIZE,
                                          LIBSPDM_TRANSPORT_TAIL_SIZE,
                                          libspdm_transport_mctp_encode_message,
                                          libspdm_transport_mctp_decode_message);

    libspdm_register_device_buffer_func(ctx,
                                        LIBSPDM_SENDER_BUFFER_SIZE,
                                        LIBSPDM_RECEIVER_BUFFER_SIZE,
                                        spdm_transport_dfu_acquire_sender_buffer,
                                        spdm_transport_dfu_release_sender_buffer,
                                        spdm_transport_dfu_acquire_receiver_buffer,
                                        spdm_transport_dfu_release_receiver_buffer);

    scratch_needed = libspdm_get_sizeof_required_scratch_buffer(ctx);
    if (scratch_needed > sizeof(s_scratch)) {
        LOG_ERR("SPDM responder: scratch buffer too small (%u < %u)",
                (unsigned int)sizeof(s_scratch), (unsigned int)scratch_needed);
        return false;
    }
    libspdm_set_scratch_buffer(ctx, s_scratch, sizeof(s_scratch));

    if (!spdm_responder_set_capabilities(ctx)) {
        LOG_ERR("SPDM responder: capability/algorithm setup failed");
        return false;
    }

    /* Register the application-message handler. libspdm calls it for messages
     * its built-in SPDM handlers do not process, which includes application
     * data received over a secure session (is_app_message == true). */
    libspdm_register_get_response_func(ctx, spdm_responder_process_app_message);

    if (!spdm_responder_load_cert_chain(ctx)) {
        return false;
    }

    s_initialized = true;
    LOG_INFO("SPDM responder context ready");
    return true;
}

libspdm_return_t spdm_responder_dispatch(void)
{
    if (!s_initialized) {
        return LIBSPDM_STATUS_INVALID_STATE_LOCAL;
    }
    return libspdm_responder_dispatch_message(s_context);
}

/* [] END OF FILE */
