/**
 *  Copyright Notice:
 *  Portions Copyright 2021-2025 DMTF. All rights reserved.
 *  Derived from libspdm include/library/spdm_lib_config.h (tag 4.0.0-rc).
 *  License: BSD 3-Clause License. For full text see:
 *  https://github.com/DMTF/libspdm/blob/main/LICENSE.md
 *
 *  Device customization: (c) 2026, Infineon Technologies AG. Configuration
 *  values only; no DMTF source logic is reproduced here.
 **/

/*
 * PSOC(TM) Control C3 libspdm Responder configuration.
 *
 * Target functionality:
 *   1. Attestation      : GET_VERSION -> GET_CAPABILITIES ->
 *                         NEGOTIATE_ALGORITHMS -> GET_DIGESTS ->
 *                         GET_CERTIFICATE -> CHALLENGE/CHALLENGE_AUTH.
 *   2. Secure session   : ECDHE (KEY_EXCHANGE / FINISH) session key
 *                         establishment + AES-256-GCM encrypted application
 *                         records over the I2C transport.
 *
 * Design intent: enable ONLY what the two use cases above need, matching the
 * on-device crypto already provisioned (ECDSA/ECDHE P-256, SHA-256, AES-GCM)
 * so libspdm reuses the existing ifx-mbedtls / PSA primitives, and shrink all
 * count/size macros to fit the 64 KB-SRAM / 256 KB-flash TrustZone budget.
 *
 * HOW TO USE: pass to the libspdm build as the integrator config, e.g. CMake
 *   -DLIBSPDM_CONFIG=<path>/spdm_lib_config_psc3.h
 * (or -include it ahead of the stock header). Every macro is guarded with
 * #ifndef in upstream, but here we DEFINE first so this file must be seen
 * before include/library/spdm_lib_config.h.
 */

#ifndef SPDM_LIB_CONFIG_PSC3_H
#define SPDM_LIB_CONFIG_PSC3_H

/* SPDM_HAVE_* capability flags for the selected profile (profiles/<name>); every
 * suite-specific value below is derived from them. */
#include "profile.h"

/*==========================================================================
 * 1. Capabilities / messages (code-space gates)
 *========================================================================*/

/* ---- SPDM 1.0 (attestation core) ---- */
#define LIBSPDM_ENABLE_CAPABILITY_CERT_CAP              1  /* GET_DIGESTS/CERTIFICATE */
#define LIBSPDM_ENABLE_CAPABILITY_CHAL_CAP              1  /* CHALLENGE/CHALLENGE_AUTH */
#define LIBSPDM_ENABLE_CAPABILITY_MEAS_CAP              1  /* signed GET_MEASUREMENTS (MEAS_CAP_SIG) + measurement_summary_hash in CHALLENGE_AUTH/KEY_EXCHANGE_RSP */
#define LIBSPDM_ENABLE_VENDOR_DEFINED_MESSAGES          0  /* no vendor messages */

/* ---- SPDM 1.1 (secure session) ---- */
#define LIBSPDM_ENABLE_CAPABILITY_KEY_EX_CAP            1  /* ECDHE KEY_EXCHANGE/FINISH */
#define LIBSPDM_ENABLE_CAPABILITY_PSK_CAP               SPDM_HAVE_PSK  /* PSK off in every profile */
#define LIBSPDM_ENABLE_CAPABILITY_HBEAT_CAP             0  /* no heartbeat */
#define LIBSPDM_ENABLE_CAPABILITY_MUT_AUTH_CAP          0  /* responder is not mutually authenticated */
#define LIBSPDM_ENABLE_CAPABILITY_ENCAP_CAP             0  /* no encapsulated requests (no mutual auth / GET_* from responder) */

/* ---- SPDM 1.2 ---- */
#define LIBSPDM_ENABLE_CAPABILITY_CSR_CAP               0  /* CSR handled by provisioning app, not SPDM */
#define LIBSPDM_ENABLE_CAPABILITY_SET_CERT_CAP          0  /* cert set by provisioning app, not SPDM */
#define LIBSPDM_ENABLE_CAPABILITY_CHUNK_CAP             1  /* REQUIRED: large msgs over small I2C MTU */

/* ---- SPDM 1.3 (all off) ---- */
#define LIBSPDM_ENABLE_CAPABILITY_MEL_CAP               0
#define LIBSPDM_ENABLE_CAPABILITY_EVENT_CAP             0
#define LIBSPDM_ENABLE_CAPABILITY_GET_KEY_PAIR_INFO_CAP 0
#define LIBSPDM_ENABLE_CAPABILITY_SET_KEY_PAIR_INFO_CAP 0
#define LIBSPDM_ENABLE_CAPABILITY_ENDPOINT_INFO_CAP     0
#define LIBSPDM_ENABLE_CAPABILITY_CSR_CAP_EX            0

/* ---- Requester-only "send" paths: device is a pure Responder ---- */
#define LIBSPDM_SEND_GET_CERTIFICATE_SUPPORT            0
#define LIBSPDM_SEND_CHALLENGE_SUPPORT                  0
#define LIBSPDM_SEND_GET_ENDPOINT_INFO_SUPPORT          0
#define LIBSPDM_EVENT_RECIPIENT_SUPPORT                 0

/* Slow on-device signing runs synchronously under the DFU/I2C poll loop, so
 * we do not use the ResponseNotReady/RESPOND_IF_READY handshake. Set to 1 if
 * a signature ever exceeds the host's per-transaction timeout. */
#define LIBSPDM_RESPOND_IF_READY_SUPPORT                0

/* FIPS mode off (no certified boundary on this part). */
#define LIBSPDM_FIPS_MODE                               0

/* Debug: keep asserts+prints during bring-up; drop all debug strings from
 * flash in the Release build once stable.
 * Instead of libspdm's own default (which leaves this ON unless _DEBUG/NDEBUG
 * say otherwise) we tie it explicitly to the build type so it follows CONFIG
 * automatically:
 *   Debug   build (no NDEBUG) -> 1  (asserts + debug strings kept)
 *   Release build (NDEBUG)    -> 0  (all libspdm debug strings stripped from
 *                                    NS flash)
 * An external -DLIBSPDM_DEBUG_ENABLE=<x> still wins (outer #ifndef guard). */
#ifndef LIBSPDM_DEBUG_ENABLE
#ifdef NDEBUG
#define LIBSPDM_DEBUG_ENABLE                            0
#else
#define LIBSPDM_DEBUG_ENABLE                            1
#endif
#endif

/* Message logging: off to save SRAM (enable temporarily for wire debugging). */
#define LIBSPDM_ENABLE_MSG_LOG                          0

/* Keep the context self-check available; cheap and catches misconfig. */
#define LIBSPDM_CHECK_SPDM_CONTEXT                      1

/*==========================================================================
 * 2. Counts and sizes (SRAM is the binding constraint on this part)
 *========================================================================*/

/* Single Requester (host) over one I2C link -> one session is enough.
 * (Default 4 -> 1 is the single biggest SRAM saving.) */
#define LIBSPDM_MAX_SESSION_COUNT                       1

/* One trust anchor (the provisioning CA). Default 10 -> 1. */
#define LIBSPDM_MAX_ROOT_CERT_SUPPORT                   1

/* VERSION entries we will tolerate/emit. Must be >= SECURED_SPDM_MAX_VERSION_COUNT
 * (4): the shared version negotiator bounds the secured-message list by this too,
 * so 3 rejects KEY_EXCHANGE. */
#define LIBSPDM_MAX_VERSION_COUNT                       4

/* Device cert chain buffer (NS s_cert_chain, filled verbatim from the PAS
 * cert slot). EC suite: ECC P-256 chain <= 4 KB. PQC suite: ML-DSA-87 root +
 * ML-DSA-87 leaf, each ~7.6 KB (2592 B public key + 4627 B ML-DSA-87
 * signature), plus the 4 B chain header and 48 B SHA-384 RootHash ~= 15.3 KB,
 * so 0x4000 leaves ~1 KB margin. Fits the 68 KB NS partition (S RAM held at
 * 58 KB, AES tables moved to flash). */
#if SPDM_HAVE_MLDSA87
#define LIBSPDM_MAX_CERT_CHAIN_SIZE                     0x4000  /* 16 KB */
#else
#define LIBSPDM_MAX_CERT_CHAIN_SIZE                     0x1000  /* 4 KB */
#endif

/* Per GET_CERTIFICATE portion. Smaller = less scratch; chunking covers the
 * rest. 1024 -> 512. */
#define LIBSPDM_MAX_CERT_CHAIN_BLOCK_LEN               512

/* Bounds one measurement record and (in our HAL) the summary-hash working
 * buffers. The hard-coded DMTF block set totals ~117 B, so 0x100 gives >2x
 * headroom while halving the transient stack cost inside
 * libspdm_generate_measurement_summary_hash. */
#define LIBSPDM_MAX_MEASUREMENT_RECORD_SIZE            0x100

/* Running transcript hash (no full-transcript buffering) = least SRAM. */
#define LIBSPDM_RECORD_TRANSCRIPT_DATA_SUPPORT          0

/*==========================================================================
 * 3. Transport buffer sizing (integrator macros)
 *
 * These bound the libspdm sender/receiver working buffers. With CHUNK_CAP=1
 * the per-message transport unit (DATA_TRANSFER_SIZE) can stay small to match
 * the I2C/DFU packet, while MAX_SPDM_MSG_SIZE holds the largest single
 * assembled message (KEY_EXCHANGE_RSP ~1.2 KB is the driver here).
 *
 * Tune DATA_TRANSFER_SIZE to the NS DFU I2C buffer (currently 135 B incl. the
 * 7-byte DFU overhead -> 128 B usable). The usable DFU payload carries the
 * whole transport message, so DATA_TRANSFER_SIZE must be the usable size minus
 * the transport header/tail (128 - 1 - 0 = 127); SENDER/RECEIVER buffers then
 * equal DATA_TRANSFER_SIZE + transport header/tail = 128, the DFU payload.
 *========================================================================*/

/* Transport binding = MCTP-message-aware, tunneled over the DFU/I2C carrier
 * (Option 2, see design doc §5.6). spdm_transport_mctp_lib prepends a single
 * MCTP message-type byte (0x05 SPDM / 0x06 secured); the DFU opcode + length
 * framing is added below by the NS router, and the 4-byte MCTP packet header /
 * SMBus / PEC of full MCTP are NOT used. Hence header = 1, tail = 0. */
#define LIBSPDM_TRANSPORT_HEADER_SIZE                   1
#define LIBSPDM_TRANSPORT_TAIL_SIZE                     0

/* Largest single SPDM message buffered end-to-end (after de-chunking).
 *
 * This value dominates NS SRAM: with CHUNK_CAP the libspdm scratch buffer is
 * carved into five worst-case regions (secure-message, chunk-reassembly,
 * sender/receiver staging x2, last request), so s_scratch = 5*MSG_SIZE + 3.
 *
 * EC suite: P-256 messages are small (KEY_EXCHANGE_RSP a few
 * hundred bytes; GET_CERTIFICATE portions capped by MAX_CERT_CHAIN_BLOCK_LEN),
 * so 0x800 bounds scratch to ~10 KB.
 *
 * PQC suite: the worst-case de-chunked message is
 * KEY_EXCHANGE_RSP = ML-KEM-1024 ciphertext (1568) + ML-DSA-87 signature
 * (4627) + summary hash (48) + verify HMAC (48) + headers ~= 6.4 KB. 0x1C00
 * (7 KB) covers it with headroom and bounds scratch to ~35 KB, which fits the
 * 54 KB NS partition alongside s_cert_chain and the context. Validate against
 * the linker map when tuning. */
#if SPDM_HAVE_MLDSA87 || SPDM_HAVE_MLKEM1024
#define LIBSPDM_MAX_SPDM_MSG_SIZE                       0x1C00  /* 7168 B */
#else
#define LIBSPDM_MAX_SPDM_MSG_SIZE                       0x800   /* 2048 B */
#endif

/* Per-transport-message SPDM payload the link carries without SPDM chunking.
 * The framed transport message is DATA_TRANSFER_SIZE + TRANSPORT_HEADER_SIZE
 * (127 + 1 = 128) and must fit the usable DFU/I2C payload (128 B); the DFU/I2C
 * carrier cannot move more than 128 B of payload per transaction. */
#define LIBSPDM_DATA_TRANSFER_SIZE                      127

/* Working buffers = one transport unit + framing. */
#define LIBSPDM_SENDER_BUFFER_SIZE   (LIBSPDM_DATA_TRANSFER_SIZE + \
                                      LIBSPDM_TRANSPORT_HEADER_SIZE + \
                                      LIBSPDM_TRANSPORT_TAIL_SIZE)
#define LIBSPDM_RECEIVER_BUFFER_SIZE (LIBSPDM_DATA_TRANSFER_SIZE + \
                                      LIBSPDM_TRANSPORT_HEADER_SIZE + \
                                      LIBSPDM_TRANSPORT_TAIL_SIZE)

/*==========================================================================
 * 4. Cryptography selection
 *
 * The libspdm primitive gates are derived from the selected profile's
 * SPDM_HAVE_* flags (profiles/<name>/profile.h, included above):
 *   EC suite  : ECDSA P-256 / ECDHE P-256 / SHA-256 / AES-256-GCM (SPDM up to 1.4).
 *   PQC suite : ML-DSA-87 / ML-KEM-1024 / SHA-384 / AES-256-GCM (CNSA 2.0, 1.4).
 * AES-256-GCM is shared. profile.h is on the include path for both the app
 * objects and the .a archives (libspdm_psc3.cmake), so the archives build
 * exactly the suite the app advertises.
 *========================================================================*/

/* ---- Signature / key-exchange / hash algorithms off in both suites ---- */
#define LIBSPDM_RSA_SSA_2048_SUPPORT                    0
#define LIBSPDM_RSA_SSA_3072_SUPPORT                    0
#define LIBSPDM_RSA_SSA_4096_SUPPORT                    0
#define LIBSPDM_RSA_PSS_2048_SUPPORT                    0
#define LIBSPDM_RSA_PSS_3072_SUPPORT                    0
#define LIBSPDM_RSA_PSS_4096_SUPPORT                    0
#define LIBSPDM_SM2_DSA_P256_SUPPORT                    0
#define LIBSPDM_EDDSA_ED25519_SUPPORT                   0
#define LIBSPDM_EDDSA_ED448_SUPPORT                     0
#define LIBSPDM_FFDHE_2048_SUPPORT                      0
#define LIBSPDM_FFDHE_3072_SUPPORT                      0
#define LIBSPDM_FFDHE_4096_SUPPORT                      0
#define LIBSPDM_SM2_KEY_EXCHANGE_P256_SUPPORT           0
#define LIBSPDM_SHA3_256_SUPPORT                        0
#define LIBSPDM_SHA3_384_SUPPORT                        0
#define LIBSPDM_SHA3_512_SUPPORT                        0
#define LIBSPDM_SM3_256_SUPPORT                         0

/* ---- AEAD: AES-256-GCM only (both suites) ---- */
#define LIBSPDM_AEAD_AES_128_GCM_SUPPORT                0
#define LIBSPDM_AEAD_AES_256_GCM_SUPPORT                1
#define LIBSPDM_AEAD_CHACHA20_POLY1305_SUPPORT          0
#define LIBSPDM_AEAD_SM4_128_GCM_SUPPORT                0

/* ---- Post-quantum leaves off in both suites ----
 * CNSA 2.0 pins ML-DSA-87 + ML-KEM-1024 (set in the suite block below); the
 * smaller ML-DSA/ML-KEM parameter sets and all of SLH-DSA stay off. */
#define LIBSPDM_ML_DSA_44_SUPPORT                       0
#define LIBSPDM_ML_DSA_65_SUPPORT                       0
#define LIBSPDM_SLH_DSA_SHA2_128S_SUPPORT               0
#define LIBSPDM_SLH_DSA_SHAKE_128S_SUPPORT              0
#define LIBSPDM_SLH_DSA_SHA2_128F_SUPPORT               0
#define LIBSPDM_SLH_DSA_SHAKE_128F_SUPPORT              0
#define LIBSPDM_SLH_DSA_SHA2_192S_SUPPORT               0
#define LIBSPDM_SLH_DSA_SHAKE_192S_SUPPORT              0
#define LIBSPDM_SLH_DSA_SHA2_192F_SUPPORT               0
#define LIBSPDM_SLH_DSA_SHAKE_192F_SUPPORT              0
#define LIBSPDM_SLH_DSA_SHA2_256S_SUPPORT               0
#define LIBSPDM_SLH_DSA_SHAKE_256S_SUPPORT              0
#define LIBSPDM_SLH_DSA_SHA2_256F_SUPPORT               0
#define LIBSPDM_SLH_DSA_SHAKE_256F_SUPPORT              0
#define LIBSPDM_ML_KEM_512_SUPPORT                      0
#define LIBSPDM_ML_KEM_768_SUPPORT                      0

/* ---- Suite-specific primitives (each gate mirrors its profile flag) ---- */
#define LIBSPDM_ECDSA_P256_SUPPORT                      SPDM_HAVE_ECDSA_P256
#define LIBSPDM_ECDSA_P384_SUPPORT                      SPDM_HAVE_ECDSA_P384
#define LIBSPDM_ECDSA_P521_SUPPORT                      SPDM_HAVE_ECDSA_P521
#define LIBSPDM_ECDHE_P256_SUPPORT                      SPDM_HAVE_ECDHE_P256
#define LIBSPDM_ECDHE_P384_SUPPORT                      SPDM_HAVE_ECDHE_P384
#define LIBSPDM_ECDHE_P521_SUPPORT                      SPDM_HAVE_ECDHE_P521
#define LIBSPDM_SHA256_SUPPORT                          SPDM_HAVE_SHA256
#define LIBSPDM_SHA384_SUPPORT                          SPDM_HAVE_SHA384
#define LIBSPDM_SHA512_SUPPORT                          SPDM_HAVE_SHA512
#define LIBSPDM_ML_DSA_87_SUPPORT                       SPDM_HAVE_MLDSA87
#define LIBSPDM_ML_KEM_1024_SUPPORT                     SPDM_HAVE_MLKEM1024

/* Off: this Responder never parses X.509. The host provisioner assembles a
 * fully-formatted SPDM cert chain that the device serves verbatim for
 * GET_CERTIFICATE and hashes (SHA-256 and/or SHA-384) for GET_DIGESTS;
 * it signs with the device key by slot, not by a key parsed from the leaf cert.
 * With MUT_AUTH_CAP=0 the Responder verifies nothing, so no libspdm_x509_* /
 * libspdm_*_verify code is referenced. */
#define LIBSPDM_CERT_PARSE_SUPPORT                      0

/* PQC build shim: libspdm_crypt_pqc_asym.c calls
 * libspdm_mldsa_get_public_key_from_x509() guarded only by LIBSPDM_ML_DSA_SUPPORT,
 * but hal/library/cryptlib/cryptlib_cert.h declares it only when
 * LIBSPDM_CERT_PARSE_SUPPORT is also set (an upstream call-site/guard mismatch).
 * We keep CERT_PARSE off (serve the chain verbatim, never parse X.509), so
 * declare the getter here to satisfy that translation unit; the NS stub
 * (cryptlib/mldsa.c) returns false because the path is never taken. */
#if SPDM_HAVE_MLDSA87 && !LIBSPDM_CERT_PARSE_SUPPORT
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
extern bool libspdm_mldsa_get_public_key_from_x509(const uint8_t *cert,
                                                   size_t cert_size,
                                                   void **context);
#endif

/* Pull in the upstream defaults for everything not overridden above. */
#include "library/spdm_lib_config.h"

#endif /* SPDM_LIB_CONFIG_PSC3_H */
