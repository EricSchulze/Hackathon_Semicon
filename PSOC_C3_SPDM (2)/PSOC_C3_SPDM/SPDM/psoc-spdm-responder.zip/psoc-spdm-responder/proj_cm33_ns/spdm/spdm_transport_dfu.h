/*****************************************************************************
 * File Name        : spdm_transport_dfu.h
 *
 * Description      : Non-secure DFU/I2C carrier bridge for the SPDM responder.
 *                    libspdm owns the message loop (it *pulls* a request via a
 *                    receive callback and *pushes* the reply via a send
 *                    callback), while the ModusToolbox DFU middleware owns the
 *                    transport loop and *pushes* each custom command into a
 *                    handler that must return the response synchronously.
 *
 *                    This module bridges that push/pull mismatch with a single
 *                    in-flight transport message: the DFU SPDM opcode handler
 *                    stages the inbound MCTP-framed request here, one libspdm
 *                    responder dispatch consumes it through the device-I/O
 *                    callbacks below (moving bytes to/from the staging buffers),
 *                    and the produced response is copied back into the DFU
 *                    reply. MCTP framing (a single message-type byte) is added
 *                    by the prebuilt libspdm_transport_mctp_lib.
 *
 *                    Stage 5 wires the carrier + device-I/O callbacks. The
 *                    libspdm responder context that registers and drives these
 *                    callbacks is added in Stage 6.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef SPDM_TRANSPORT_DFU_H
#define SPDM_TRANSPORT_DFU_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/* Pulls in libspdm_return_t and the LIBSPDM_SENDER/RECEIVER_BUFFER_SIZE macros
 * from spdm_lib_config_psc3.h (via the LIBSPDM_CONFIG define). */
#include "library/spdm_common_lib.h"

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Macros
 *****************************************************************************/

/* Largest transport message carried in one DFU SPDM transaction: one
 * MCTP-framed SPDM transport unit (LIBSPDM_DATA_TRANSFER_SIZE + the MCTP
 * message-type byte). Larger SPDM messages are split across transactions by
 * SPDM CHUNK_CAP, so the staging buffers only ever hold one transport unit. */
#define SPDM_DFU_TRANSPORT_MSG_SIZE     (LIBSPDM_RECEIVER_BUFFER_SIZE)

/******************************************************************************
 * Router-facing staging API (single in-flight transport message)
 *****************************************************************************/

/**
 * @brief Reset the carrier bridge, dropping any half-staged request/response.
 *
 * Called at responder session (re)arm so a new transaction starts clean.
 */
void spdm_transport_dfu_reset(void);

/**
 * @brief Stage an inbound MCTP-framed SPDM request from the DFU SPDM opcode.
 *
 * @param data  Pointer to the received transport message bytes.
 * @param len   Number of bytes in @p data.
 *
 * @return true if the request was staged; false if @p len is zero or exceeds
 *         SPDM_DFU_TRANSPORT_MSG_SIZE.
 */
bool spdm_transport_dfu_stage_request(const uint8_t *data, size_t len);

/**
 * @brief Copy the staged SPDM response into the DFU reply buffer.
 *
 * The response is produced by spdm_transport_dfu_send_message() during the
 * libspdm responder dispatch (Stage 6).
 *
 * @param out      Destination buffer (the DFU packet buffer).
 * @param out_cap  Capacity of @p out in bytes.
 * @param out_len  On success, receives the number of bytes written.
 *
 * @return true if a response was pending and fit in @p out; false otherwise.
 */
bool spdm_transport_dfu_take_response(uint8_t *out, size_t out_cap, size_t *out_len);

/**
 * @brief Query whether a response has been produced and not yet taken.
 */
bool spdm_transport_dfu_response_pending(void);

/******************************************************************************
 * libspdm device-I/O + buffer callbacks
 *
 * These match the libspdm_device_*_func typedefs in spdm_common_lib.h. Stage 6
 * registers them on the responder context via libspdm_register_device_io_func()
 * and libspdm_register_device_buffer_func(). They are defined here in Stage 5
 * (compiled, but not yet registered) so the carrier is complete and testable.
 *****************************************************************************/

libspdm_return_t spdm_transport_dfu_send_message(void *spdm_context, size_t message_size,
                                                 const void *message, uint64_t timeout);

libspdm_return_t spdm_transport_dfu_receive_message(void *spdm_context, size_t *message_size,
                                                    void **message, uint64_t timeout);

libspdm_return_t spdm_transport_dfu_acquire_sender_buffer(void *spdm_context, void **msg_buf_ptr);

void spdm_transport_dfu_release_sender_buffer(void *spdm_context, const void *msg_buf_ptr);

libspdm_return_t spdm_transport_dfu_acquire_receiver_buffer(void *spdm_context, void **msg_buf_ptr);

void spdm_transport_dfu_release_receiver_buffer(void *spdm_context, const void *msg_buf_ptr);

#if defined(__cplusplus)
}
#endif

#endif /* SPDM_TRANSPORT_DFU_H */

/* [] END OF FILE */
