/*****************************************************************************
 * File Name        : device_secret.c
 *
 * Description      : Non-secure libspdm responder device-secret HAL glue for
 *                    the SPDM Responder. Implements the responder asym-sign
 *                    hooks of hal/library/responder/asymsignlib.h by forwarding
 *                    the signing request to the secure world through the
 *                    device-identity sign veneer (shared/nsc_sign.h).
 *
 *                    The device identity key lives AES-GCM-wrapped in PAS
 *                    slot 0 and is only unwrapped, used and destroyed inside the
 *                    SPE; this glue never sees the private key, only the
 *                    resulting signature.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "hal/library/responder/asymsignlib.h"
#include "hal/library/responder/keyexlib.h"
#include "industry_standard/spdm.h"
#include "library/spdm_crypt_lib.h"

#include "profile.h"  /* SPDM_HAVE_* capability flags for the selected profile */

#include "nsc_sign.h"

/*
 * Since SPDM 1.2, signatures are not computed over the bare transcript hash.
 * The signer must build a 100-byte "signing context" (four repetitions of the
 * versioned prefix followed by a zero-padded, op-code-specific context string),
 * concatenate the transcript hash, hash that combined buffer and sign the
 * result. This mirrors libspdm_create_signing_context() / libspdm_asym_sign_hash()
 * so that the requester's verification (which applies the same context) matches.
 */
#define SPDM_SIGN_CTX_SIZE      SPDM_VERSION_1_2_SIGNING_CONTEXT_SIZE
#define SPDM_SIGN_PREFIX_SIZE   SPDM_VERSION_1_2_SIGNING_PREFIX_CONTEXT_SIZE

/* Return the op-code-specific SPDM signing-context string and its length.
 * Returns false if the op-code is not one this responder signs. */
static bool spdm_op_sign_context(uint8_t op_code,
                                 const char **op_ctx, size_t *op_ctx_size)
{
    switch (op_code) {
    case SPDM_CHALLENGE_AUTH:
        *op_ctx = SPDM_CHALLENGE_AUTH_SIGN_CONTEXT;
        *op_ctx_size = SPDM_CHALLENGE_AUTH_SIGN_CONTEXT_SIZE;
        break;
    case SPDM_KEY_EXCHANGE_RSP:
        *op_ctx = SPDM_KEY_EXCHANGE_RESPONSE_SIGN_CONTEXT;
        *op_ctx_size = SPDM_KEY_EXCHANGE_RESPONSE_SIGN_CONTEXT_SIZE;
        break;
    case SPDM_MEASUREMENTS:
        *op_ctx = SPDM_MEASUREMENTS_SIGN_CONTEXT;
        *op_ctx_size = SPDM_MEASUREMENTS_SIGN_CONTEXT_SIZE;
        break;
    default:
        return false;
    }
    return true;
}

/* Build the SPDM 1.2+ responder signing context for the given op-code.
 * Returns false if the op-code is not one this responder signs. */
static bool spdm_build_signing_context(spdm_version_number_t spdm_version,
                                       uint8_t op_code,
                                       uint8_t out[SPDM_SIGN_CTX_SIZE])
{
    const char *op_ctx;
    size_t op_ctx_size;
    size_t zero_pad;
    uint8_t *p = out;
    size_t i;

    if (!spdm_op_sign_context(op_code, &op_ctx, &op_ctx_size)) {
        return false;
    }

    /* Four repetitions of the versioned prefix "dmtf-spdm-v1.x.*". */
    for (i = 0U; i < 4U; i++) {
        (void)memcpy(p, SPDM_VERSION_1_2_SIGNING_PREFIX_CONTEXT,
                     SPDM_SIGN_PREFIX_SIZE);
        p[11] = (uint8_t)('0' + ((spdm_version >> 12) & 0xFU)); /* major */
        p[13] = (uint8_t)('0' + ((spdm_version >> 8) & 0xFU));  /* minor */
        p[15] = (uint8_t)'*';
        p += SPDM_SIGN_PREFIX_SIZE;
    }

    /* Remaining 36 bytes: zero pad then the op-code context string. */
    zero_pad = 36U - op_ctx_size;
    (void)memset(p, 0, zero_pad);
    (void)memcpy(p + zero_pad, op_ctx, op_ctx_size);
    return true;
}

/******************************************************************************
 * CHALLENGE_AUTH opaque data (asymsignlib.h)
 *****************************************************************************/

#if LIBSPDM_ENABLE_CAPABILITY_CHAL_CAP
bool libspdm_challenge_opaque_data(
    void *spdm_context,
    spdm_version_number_t spdm_version,
    uint8_t slot_id,
    size_t request_context_size,
    const void *request_context,
    void *opaque_data,
    size_t *opaque_data_size)
{
    (void)spdm_context;
    (void)spdm_version;
    (void)slot_id;
    (void)request_context_size;
    (void)request_context;
    (void)opaque_data;

    if (opaque_data_size == NULL) {
        return false;
    }
    /* This responder carries no vendor opaque data in CHALLENGE_AUTH. */
    *opaque_data_size = 0U;
    return true;
}
#endif /* LIBSPDM_ENABLE_CAPABILITY_CHAL_CAP */

/******************************************************************************
 * KEY_EXCHANGE_RSP / FINISH_RSP opaque data (keyexlib.h)
 *****************************************************************************/

#if LIBSPDM_ENABLE_CAPABILITY_KEY_EX_CAP
/* This responder emits no vendor opaque data in KEY_EXCHANGE_RSP. Returning
 * false makes libspdm generate the default secured-message version-selection
 * opaque data, which is what session establishment requires. */
bool libspdm_key_exchange_rsp_opaque_data(
    void *spdm_context,
    spdm_version_number_t spdm_version,
    uint8_t measurement_hash_type,
    uint8_t slot_id,
    uint8_t session_policy,
    const void *req_opaque_data,
    size_t req_opaque_data_size,
    void *opaque_data,
    size_t *opaque_data_size)
{
    (void)spdm_context;
    (void)spdm_version;
    (void)measurement_hash_type;
    (void)slot_id;
    (void)session_policy;
    (void)req_opaque_data;
    (void)req_opaque_data_size;
    (void)opaque_data;
    (void)opaque_data_size;
    return false;
}

/* FINISH_RSP carries no vendor opaque data. libspdm only invokes this for
 * SPDM 1.4+ with a non-NONE opaque data format; emit an empty field. */
bool libspdm_finish_rsp_opaque_data(
    void *spdm_context,
    uint32_t session_id,
    spdm_version_number_t spdm_version,
    uint8_t req_slot_id,
    const void *req_opaque_data,
    size_t req_opaque_data_size,
    void *opaque_data,
    size_t *opaque_data_size)
{
    (void)spdm_context;
    (void)session_id;
    (void)spdm_version;
    (void)req_slot_id;
    (void)req_opaque_data;
    (void)req_opaque_data_size;
    (void)opaque_data;

    if (opaque_data_size == NULL) {
        return false;
    }
    *opaque_data_size = 0U;
    return true;
}
#endif /* LIBSPDM_ENABLE_CAPABILITY_KEY_EX_CAP */

/******************************************************************************
 * Responder message signing (asymsignlib.h)
 *****************************************************************************/

bool libspdm_responder_data_sign(
    void *spdm_context,
    spdm_version_number_t spdm_version,
    uint8_t key_pair_id, uint8_t op_code,
    uint32_t base_asym_algo, uint32_t pqc_asym_algo,
    uint32_t base_hash_algo, bool is_data_hash,
    const uint8_t *message, size_t message_size,
    uint8_t *signature, size_t *sig_size)
{
    nsc_sign_params_t p;
    size_t out_len = 0U;
    /* signing context (100) followed by the transcript hash. */
    uint8_t ctx_with_hash[SPDM_SIGN_CTX_SIZE + LIBSPDM_MAX_HASH_SIZE];
    uint8_t transcript_hash[LIBSPDM_MAX_HASH_SIZE];
    const uint8_t *m1m2_hash;
    size_t hash_size;

    (void)spdm_context;
    (void)key_pair_id;

    if ((message == NULL) || (signature == NULL) || (sig_size == NULL)) {
        return false;
    }
#if SPDM_HAVE_MLDSA87
    /* ML-DSA-87 profile: the device signs with ML-DSA-87 only; reject any
     * non-PQC asym request and require the ML-DSA-87 PQC algorithm. */
    if (base_asym_algo != 0U) {
        return false;
    }
    if (pqc_asym_algo != SPDM_ALGORITHMS_PQC_ASYM_ALGO_ML_DSA_87) {
        return false;
    }
    if (*sig_size < NSC_SIGN_MLDSA87_SIG_SIZE) {
        return false;
    }
#elif SPDM_HAVE_ECDSA
    /* ECDSA profile: ECDSA over the profile's NIST curve; reject any PQC request. */
    if (pqc_asym_algo != 0U) {
        return false;
    }
#if SPDM_HAVE_ECDSA_P256
    if (base_asym_algo !=
        SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P256) {
        return false;
    }
#elif SPDM_HAVE_ECDSA_P384
    if (base_asym_algo !=
        SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P384) {
        return false;
    }
#elif SPDM_HAVE_ECDSA_P521
    if (base_asym_algo !=
        SPDM_ALGORITHMS_BASE_ASYM_ALGO_TPM_ALG_ECDSA_ECC_NIST_P521) {
        return false;
    }
#endif
    if (*sig_size < NSC_SIGN_ECDSA_SIG_SIZE) {
        return false;
    }
#else
#error "No device-identity signing algorithm selected for this profile"
#endif

    hash_size = libspdm_get_hash_size(base_hash_algo);
    if ((hash_size == 0U) || (hash_size > LIBSPDM_MAX_HASH_SIZE)) {
        return false;
    }

    /* Obtain the transcript (m1/m2) hash. With
     * LIBSPDM_RECORD_TRANSCRIPT_DATA_SUPPORT == 0 libspdm passes the hash
     * directly (is_data_hash == true); otherwise it passes the raw transcript
     * which must be hashed here first. */
    if (is_data_hash) {
        if (message_size != hash_size) {
            return false;
        }
        m1m2_hash = message;
    } else {
        if (!libspdm_hash_all(base_hash_algo, message, message_size,
                              transcript_hash)) {
            return false;
        }
        m1m2_hash = transcript_hash;
    }

    if ((spdm_version >> SPDM_VERSION_NUMBER_SHIFT_BIT) >
        SPDM_MESSAGE_VERSION_11) {
        /* SPDM 1.2+: the signature covers the 100-byte signing context followed
         * by the transcript hash. Build the combined buffer. */
        if (!spdm_build_signing_context(spdm_version, op_code, ctx_with_hash)) {
            return false;
        }
        (void)memcpy(&ctx_with_hash[SPDM_SIGN_CTX_SIZE], m1m2_hash, hash_size);

        p.message      = ctx_with_hash;
        p.message_size = SPDM_SIGN_CTX_SIZE + hash_size;
#if SPDM_HAVE_MLDSA87
        /* ML-DSA-87 signs the combined buffer directly (no external hash), with
         * the op-code signing-context string as the FIPS-204 context so a
         * libspdm requester's verification matches. */
        {
            const char *op_ctx;
            size_t op_ctx_size;
            if (!spdm_op_sign_context(op_code, &op_ctx, &op_ctx_size)) {
                return false;
            }
            p.is_data_hash = false; /* unused by the ML-DSA signer */
            p.context      = (const uint8_t *)op_ctx;
            p.context_size = op_ctx_size;
        }
#elif SPDM_HAVE_ECDSA
        p.is_data_hash = false; /* raw buffer: SPE applies SHA then signs */
        p.context      = NULL;
        p.context_size = 0U;
#endif
    } else {
        /* SPDM 1.0/1.1 (ECDSA path only): sign the transcript hash directly. */
        p.is_data_hash = true;
        p.message      = m1m2_hash;
        p.message_size = hash_size;
        p.context      = NULL;
        p.context_size = 0U;
    }

    p.signature      = signature;
    p.signature_cap  = *sig_size;
    p.signature_size = &out_len;

    if (nsc_device_sign(&p) != NSC_SIGN_SUCCESS) {
        return false;
    }
    *sig_size = out_len;
    return true;
}

/* [] END OF FILE */
