################################################################################
# \file detect_platform.mk
#
# \brief
# Sets PLATFORM to PSC3M8 when TARGET matches a PSC3M8 kit. Included by
# common.mk via wildcard so adding a new PSC3M8 board only requires extending
# the TARGET list below. PLATFORM selects the per-device deps folder
# (platforms/$(PLATFORM)/deps) used by 'make getlibs'.
################################################################################

ifeq ($(filter $(TARGET), KIT_PSC3M8_EVK APP_KIT_PSC3M8_EVK),$(TARGET))
    PLATFORM ?= PSC3M8
    # SPDM profiles this device can run.
    SPDM_PROFILES_SUPPORTED ?= P1 P2 P3 P4
    # Has the SRAM/flash footprint to host the wolfCrypt PQC backend (gates
    # wolfSSL inclusion in proj_cm33_s/Makefile).
    PLATFORM_SUPPORTS_WOLFCRYPT ?= 1
endif
