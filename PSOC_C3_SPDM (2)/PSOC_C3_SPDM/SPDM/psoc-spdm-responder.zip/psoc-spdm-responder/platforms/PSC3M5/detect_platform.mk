################################################################################
# \file detect_platform.mk
#
# \brief
# Sets PLATFORM to PSC3M5 when TARGET matches a PSC3M5 kit. Included by
# common.mk via wildcard so adding a new PSC3M5 board only requires extending
# the TARGET list below. PLATFORM selects the per-device deps folder
# (platforms/$(PLATFORM)/deps) used by 'make getlibs'.
################################################################################

ifeq ($(filter $(TARGET), KIT_PSC3M5_EVK APP_KIT_PSC3M5_EVK),$(TARGET))
    PLATFORM ?= PSC3M5
    # SPDM profiles this device can run. The classic profiles (P1-P3) stay on
    # the PSA / mbedTLS backend; the wolfCrypt-backed PQC profile (P4) needs
    # more SRAM/flash than this device has.
    SPDM_PROFILES_SUPPORTED ?= P1 P2 P3
    # Cannot host the wolfCrypt PQC backend (insufficient SRAM/flash footprint).
    PLATFORM_SUPPORTS_WOLFCRYPT ?= 0
    # PSC3M5 pins the v2.X CryptoLite accelerator (platforms/PSC3M5/deps), which
    # lacks the SHA-384/512 and P-521 handling the default v3.X config assumes,
    # so override that default with the device's own SHA-256-only config (wired
    # as a compiler -D in proj_cm33_s/Makefile). What it changes is documented in
    # the config header and docs/implementation.md (Crypto backend).
    PLATFORM_CRYPTOLITE_USER_CONFIG ?= spdm_cryptolite_config.h
endif
