/*****************************************************************************
 * File Name        : spdm_cryptolite_config.h
 *
 * Description      : MXCRYPTOLITE PSA transparent-driver user config, selected
 *                    via IFX_PSA_CRYPTOLITE_USER_CONFIG_FILE (see
 *                    proj_cm33_s/Makefile) on devices whose accelerator cannot
 *                    handle every curve the SPDM cipher suite may request --
 *                    PSC3M5, cy-mbedtls-acceleration v2.X. It replaces ONLY the
 *                    driver's auto-derivation (the #else branch of the stock
 *                    ifx_cryptolite_config.h); the vendor's shared validation
 *                    and feature aggregation still run after it.
 *
 *                    Why it exists: the stock auto-derivation force-enables
 *                    IFX_PSA_CRYPTOLITE_ECDSA_VERIFY whenever an EC public key
 *                    is requested -- its "mbedtls 3.6 compat" block has no curve
 *                    guard, and a sibling block mis-parses `A || B && curve` --
 *                    so a P-521 key trips the stock header's hard #error
 *                    "IFX_PSA_CRYPTOLITE_ECC_SECP_R1_xxx curve not defined for
 *                    ECDSA functionality" (the accelerator covers NIST SECP_R1
 *                    only up to P-384; see docs/implementation.md, Crypto
 *                    backend).
 *
 *                    This file reproduces the stock derivation faithfully but
 *                    (a) omits the P-521 curve arm and (b) gates ECDSA/ECDH on a
 *                    CryptoLite-supported curve actually being present. The net
 *                    effect is identical to the stock config for P-256 / P-384
 *                    profiles (hardware accelerated), while a P-521 profile
 *                    defines no CryptoLite EC macro and the PSA core routes
 *                    P-521 ECDSA/ECDHE to the mbedTLS software path. SHA / HMAC /
 *                    CMAC / AES acceleration is retained on every profile. It is
 *                    profile-agnostic: the device selects it, not the profile.
 *                    The v3.X parts (PSC3M6 / M8) use the default
 *                    config/spdm_cryptolite_config_v3.h instead, which keeps the
 *                    SHA-384/512 hardware this v2.X accelerator does not have.
 *
 * Related Document : docs/implementation.md
 *****************************************************************************/

#ifndef SPDM_CRYPTOLITE_CONFIG_SPDM_H
#define SPDM_CRYPTOLITE_CONFIG_SPDM_H

#include "mbedtls/build_info.h"
#include "psa/crypto_driver_common.h"

/* ---- Non-EC primitives: mirror the vendor auto-derivation ----------------
 * Each enable follows the same PSA_WANT_* capability the stock
 * ifx_cryptolite_config.h keys off, so SHA / MAC / key-derivation remain
 * hardware accelerated exactly as on the P-256 / P-384 profiles. */

#if defined(PSA_WANT_KEY_TYPE_DERIVE)
#define IFX_PSA_CRYPTOLITE_KEY_DERIVATION
#endif

#if defined(PSA_WANT_ALG_HMAC)
#define IFX_PSA_CRYPTOLITE_HMAC
#endif

#if defined(PSA_WANT_ALG_CMAC)
#define IFX_PSA_CRYPTOLITE_CMAC
#endif

#if defined(PSA_WANT_ALG_SHA_256)
#define IFX_PSA_CRYPTOLITE_SHA
#define IFX_PSA_CRYPTOLITE_SHA_256
#endif

/* AES block-cipher modes (none is enabled by the SPDM profiles, which use
 * AES-GCM via the full MXCRYPTO block, but mirror the vendor derivation so the
 * shared CIPHER/AEAD aggregators behave identically). */
#if defined(PSA_WANT_ALG_ECB_NO_PADDING)
#define IFX_PSA_CRYPTOLITE_ECB_NO_PADDING
#endif

#if defined(PSA_WANT_ALG_CBC_NO_PADDING)
#define IFX_PSA_CRYPTOLITE_CBC_NO_PADDING
#endif

#if defined(PSA_WANT_ALG_CFB)
#define IFX_PSA_CRYPTOLITE_CFB
#endif

#if defined(PSA_WANT_ALG_CTR)
#define IFX_PSA_CRYPTOLITE_CTR
#endif

#if defined(PSA_WANT_ALG_CCM)
#define IFX_PSA_CRYPTOLITE_CCM
#endif

/* ---- Elliptic curve: per supported curve, up to CryptoLite's P-384 ceiling
 * Mirror the stock per-curve derivation but WITHOUT the P-521 arm: the
 * accelerator has no P-521 engine and the stock header hard-#errors if
 * IFX_PSA_CRYPTOLITE_ECC_SECP_R1_521 is ever defined. A P-521 configuration
 * therefore defines no CryptoLite curve macro and the PSA core routes P-521 EC
 * to software; P-256 / P-384 stay hardware accelerated exactly as stock. */
#if defined(PSA_WANT_ECC_SECP_R1_192)
#define IFX_PSA_CRYPTOLITE_ECC_SECP_R1_192
#endif
#if defined(PSA_WANT_ECC_SECP_R1_224)
#define IFX_PSA_CRYPTOLITE_ECC_SECP_R1_224
#endif
#if defined(PSA_WANT_ECC_SECP_R1_256)
#define IFX_PSA_CRYPTOLITE_ECC_SECP_R1_256
#endif
#if defined(PSA_WANT_ECC_SECP_R1_384)
#define IFX_PSA_CRYPTOLITE_ECC_SECP_R1_384
#endif

/* ECDH: unchanged from the stock derivation (already curve-guarded there). */
#if defined(PSA_WANT_ALG_ECDH) \
 && (defined(PSA_WANT_KEY_TYPE_ECC_KEY_PAIR) || defined(PSA_WANT_KEY_TYPE_ECC_KEY_PAIR_BASIC)) \
 && (defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_192) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_224) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_256) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_384))
#define IFX_PSA_CRYPTOLITE_ECDH
#endif

/* EC public-key export: unchanged from the stock derivation (curve-guarded). */
#if defined(PSA_WANT_KEY_TYPE_ECC_PUBLIC_KEY) \
 && (defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_192) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_224) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_256) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_384))
#define IFX_PSA_CRYPTOLITE_ECC_PUBLIC_KEY_EXPORT
#define IFX_PSA_CRYPTOLITE_PUBLIC_KEY_EXPORT
#endif

/* ECDSA -- the fix. Gate BOTH sign and verify on a CryptoLite-supported curve
 * (the stock header does not, which is what trips the P-521 #error). A P-521
 * configuration thus leaves ECDSA entirely on the mbedTLS software path, while
 * P-256 / P-384 keep the same hardware ECDSA sign/verify as stock. */
#if defined(PSA_WANT_ALG_ECDSA) \
 && (defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_192) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_224) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_256) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_384))
#if defined(PSA_WANT_KEY_TYPE_ECC_KEY_PAIR_BASIC)
#define IFX_PSA_CRYPTOLITE_ECDSA_SIGN
#endif
#if defined(PSA_WANT_KEY_TYPE_ECC_PUBLIC_KEY) || defined(PSA_WANT_KEY_TYPE_ECC_KEY_PAIR)
#define IFX_PSA_CRYPTOLITE_ECDSA_VERIFY
#define IFX_PSA_CRYPTOLITE_ECDSA_VERIFY_USE_PK
#endif
#endif

/* EC key generation: unchanged from the stock derivation (curve-guarded). */
#if (defined(PSA_WANT_KEY_TYPE_ECC_KEY_PAIR) || defined(PSA_WANT_KEY_TYPE_ECC_KEY_PAIR_GENERATE)) \
 && (defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_192) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_224) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_256) \
  || defined(IFX_PSA_CRYPTOLITE_ECC_SECP_R1_384))
#define IFX_PSA_CRYPTOLITE_KEY_GENERATION
#endif

#endif /* SPDM_CRYPTOLITE_CONFIG_SPDM_H */

/* [] END OF FILE */
