#! /bin/bash

edgeprotecttools -t psoc_c3 provision-device -p ns_policy/policy_oem_provisioning.json
