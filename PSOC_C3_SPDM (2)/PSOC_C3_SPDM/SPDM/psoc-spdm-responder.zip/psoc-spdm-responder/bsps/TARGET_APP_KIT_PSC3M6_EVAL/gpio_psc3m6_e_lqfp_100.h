/***************************************************************************//**
* PSC3M6 device GPIO header for E-LQFP-100 package
*
********************************************************************************
* \copyright
* (c) 2016-2026, Infineon Technologies AG or an affiliate of
* Infineon Technologies AG.
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*******************************************************************************/

#ifndef _GPIO_PSC3M6_E_LQFP_100_H_
#define _GPIO_PSC3M6_E_LQFP_100_H_

/* Package type */
enum
{
    CY_GPIO_PACKAGE_QFN,
    CY_GPIO_PACKAGE_BGA,
    CY_GPIO_PACKAGE_CSP,
    CY_GPIO_PACKAGE_WLCSP,
    CY_GPIO_PACKAGE_LQFP,
    CY_GPIO_PACKAGE_TQFP,
    CY_GPIO_PACKAGE_SMT,
    CY_GPIO_PACKAGE_VQFN,
};

#define CY_GPIO_PACKAGE_TYPE            CY_GPIO_PACKAGE_LQFP
#define CY_GPIO_PIN_COUNT               100u

/* AMUXBUS Segments */
enum
{
    AMUXBUS_CHIP,
    AMUXBUS_FLASH,
    AMUXBUS_LPCOMP,
    AMUXBUS_SRSS,
    AMUXBUS_SVGS,
    AMUXBUS_TEST,
    AMUXBUS_USB,
};

/* AMUX Splitter Controls */
typedef enum
{
    AMUX_SPLIT_CTL_0                = 0x0000u,  /* Left = AMUXBUS_CHIP; Right = AMUXBUS_TEST */
    AMUX_SPLIT_CTL_1                = 0x0001u,  /* Left = AMUXBUS_SRSS; Right = AMUXBUS_CHIP */
    AMUX_SPLIT_CTL_2                = 0x0002u,  /* Left = AMUXBUS_LPCOMP; Right = AMUXBUS_CHIP */
    AMUX_SPLIT_CTL_3                = 0x0003u,  /* Left = AMUXBUS_FLASH; Right = AMUXBUS_CHIP */
    AMUX_SPLIT_CTL_4                = 0x0004u,  /* Left = AMUXBUS_SVGS; Right = AMUXBUS_CHIP */
    AMUX_SPLIT_CTL_5                = 0x0005u   /* Left = AMUXBUS_USB; Right = AMUXBUS_CHIP */
} cy_en_amux_split_t;

/* Port List */
/* PORT 0 (GPIO) */
#define P0_0_PORT                       GPIO_PRT0
#define P0_0_PIN                        0u
#define P0_0_NUM                        0u
#define P0_1_PORT                       GPIO_PRT0
#define P0_1_PIN                        1u
#define P0_1_NUM                        1u

/* PORT 1 (GPIO) */
#define P1_0_PORT                       GPIO_PRT1
#define P1_0_PIN                        0u
#define P1_0_NUM                        0u
#define P1_1_PORT                       GPIO_PRT1
#define P1_1_PIN                        1u
#define P1_1_NUM                        1u
#define P1_2_PORT                       GPIO_PRT1
#define P1_2_PIN                        2u
#define P1_2_NUM                        2u
#define P1_3_PORT                       GPIO_PRT1
#define P1_3_PIN                        3u
#define P1_3_NUM                        3u

/* PORT 2 (GPIO) */
#define P2_0_PORT                       GPIO_PRT2
#define P2_0_PIN                        0u
#define P2_0_NUM                        0u
#define P2_1_PORT                       GPIO_PRT2
#define P2_1_PIN                        1u
#define P2_1_NUM                        1u
#define P2_2_PORT                       GPIO_PRT2
#define P2_2_PIN                        2u
#define P2_2_NUM                        2u
#define P2_3_PORT                       GPIO_PRT2
#define P2_3_PIN                        3u
#define P2_3_NUM                        3u

/* PORT 3 (GPIO) */
#define P3_0_PORT                       GPIO_PRT3
#define P3_0_PIN                        0u
#define P3_0_NUM                        0u
#define P3_1_PORT                       GPIO_PRT3
#define P3_1_PIN                        1u
#define P3_1_NUM                        1u
#define P3_2_PORT                       GPIO_PRT3
#define P3_2_PIN                        2u
#define P3_2_NUM                        2u
#define P3_3_PORT                       GPIO_PRT3
#define P3_3_PIN                        3u
#define P3_3_NUM                        3u

/* PORT 4 (GPIO) */
#define P4_0_PORT                       GPIO_PRT4
#define P4_0_PIN                        0u
#define P4_0_NUM                        0u
#define P4_1_PORT                       GPIO_PRT4
#define P4_1_PIN                        1u
#define P4_1_NUM                        1u
#define P4_2_PORT                       GPIO_PRT4
#define P4_2_PIN                        2u
#define P4_2_NUM                        2u
#define P4_3_PORT                       GPIO_PRT4
#define P4_3_PIN                        3u
#define P4_3_NUM                        3u
#define P4_4_PORT                       GPIO_PRT4
#define P4_4_PIN                        4u
#define P4_4_NUM                        4u
#define P4_5_PORT                       GPIO_PRT4
#define P4_5_PIN                        5u
#define P4_5_NUM                        5u
#define P4_6_PORT                       GPIO_PRT4
#define P4_6_PIN                        6u
#define P4_6_NUM                        6u
#define P4_7_PORT                       GPIO_PRT4
#define P4_7_PIN                        7u
#define P4_7_NUM                        7u

/* PORT 5 (GPIO) */
#define P5_0_PORT                       GPIO_PRT5
#define P5_0_PIN                        0u
#define P5_0_NUM                        0u
#define P5_1_PORT                       GPIO_PRT5
#define P5_1_PIN                        1u
#define P5_1_NUM                        1u
#define P5_2_PORT                       GPIO_PRT5
#define P5_2_PIN                        2u
#define P5_2_NUM                        2u
#define P5_3_PORT                       GPIO_PRT5
#define P5_3_PIN                        3u
#define P5_3_NUM                        3u

/* PORT 6 (GPIO_OVT) */
#define P6_0_PORT                       GPIO_PRT6
#define P6_0_PIN                        0u
#define P6_0_NUM                        0u
#define P6_1_PORT                       GPIO_PRT6
#define P6_1_PIN                        1u
#define P6_1_NUM                        1u
#define P6_2_PORT                       GPIO_PRT6
#define P6_2_PIN                        2u
#define P6_2_NUM                        2u
#define P6_3_PORT                       GPIO_PRT6
#define P6_3_PIN                        3u
#define P6_3_NUM                        3u

/* PORT 7 (GPIO) */
#define P7_0_PORT                       GPIO_PRT7
#define P7_0_PIN                        0u
#define P7_0_NUM                        0u
#define P7_1_PORT                       GPIO_PRT7
#define P7_1_PIN                        1u
#define P7_1_NUM                        1u
#define P7_2_PORT                       GPIO_PRT7
#define P7_2_PIN                        2u
#define P7_2_NUM                        2u
#define P7_3_PORT                       GPIO_PRT7
#define P7_3_PIN                        3u
#define P7_3_NUM                        3u
#define P7_4_PORT                       GPIO_PRT7
#define P7_4_PIN                        4u
#define P7_4_NUM                        4u
#define P7_5_PORT                       GPIO_PRT7
#define P7_5_PIN                        5u
#define P7_5_NUM                        5u
#define P7_6_PORT                       GPIO_PRT7
#define P7_6_PIN                        6u
#define P7_6_NUM                        6u
#define P7_7_PORT                       GPIO_PRT7
#define P7_7_PIN                        7u
#define P7_7_NUM                        7u

/* PORT 8 (GPIO) */
#define P8_0_PORT                       GPIO_PRT8
#define P8_0_PIN                        0u
#define P8_0_NUM                        0u
#define P8_1_PORT                       GPIO_PRT8
#define P8_1_PIN                        1u
#define P8_1_NUM                        1u
#define P8_2_PORT                       GPIO_PRT8
#define P8_2_PIN                        2u
#define P8_2_NUM                        2u
#define P8_3_PORT                       GPIO_PRT8
#define P8_3_PIN                        3u
#define P8_3_NUM                        3u
#define P8_4_PORT                       GPIO_PRT8
#define P8_4_PIN                        4u
#define P8_4_NUM                        4u
#define P8_5_PORT                       GPIO_PRT8
#define P8_5_PIN                        5u
#define P8_5_NUM                        5u
#define P8_6_PORT                       GPIO_PRT8
#define P8_6_PIN                        6u
#define P8_6_NUM                        6u
#define P8_7_PORT                       GPIO_PRT8
#define P8_7_PIN                        7u
#define P8_7_NUM                        7u

/* PORT 9 (GPIO) */
#define P9_0_PORT                       GPIO_PRT9
#define P9_0_PIN                        0u
#define P9_0_NUM                        0u
#define P9_1_PORT                       GPIO_PRT9
#define P9_1_PIN                        1u
#define P9_1_NUM                        1u
#define P9_2_PORT                       GPIO_PRT9
#define P9_2_PIN                        2u
#define P9_2_NUM                        2u
#define P9_3_PORT                       GPIO_PRT9
#define P9_3_PIN                        3u
#define P9_3_NUM                        3u
#define P9_4_PORT                       GPIO_PRT9
#define P9_4_PIN                        4u
#define P9_4_NUM                        4u
#define P9_5_PORT                       GPIO_PRT9
#define P9_5_PIN                        5u
#define P9_5_NUM                        5u
#define P9_6_PORT                       GPIO_PRT9
#define P9_6_PIN                        6u
#define P9_6_NUM                        6u
#define P9_7_PORT                       GPIO_PRT9
#define P9_7_PIN                        7u
#define P9_7_NUM                        7u

/* PORT 10 (GPIO) */
#define P10_0_PORT                      GPIO_PRT10
#define P10_0_PIN                       0u
#define P10_0_NUM                       0u
#define P10_1_PORT                      GPIO_PRT10
#define P10_1_PIN                       1u
#define P10_1_NUM                       1u
#define P10_2_PORT                      GPIO_PRT10
#define P10_2_PIN                       2u
#define P10_2_NUM                       2u

/* PORT 11 (AUX) */
#define USBDM_PORT                      GPIO_PRT11
#define USBDM_PIN                       0u
#define USBDM_NUM                       0u
#define P11_0_PORT                      GPIO_PRT11
#define P11_0_PIN                       0u
#define P11_0_NUM                       0u
#define USBDP_PORT                      GPIO_PRT11
#define USBDP_PIN                       1u
#define USBDP_NUM                       1u
#define P11_1_PORT                      GPIO_PRT11
#define P11_1_PIN                       1u
#define P11_1_NUM                       1u

/* PORT 12 (GPIO) */
#define P12_0_PORT                      GPIO_PRT12
#define P12_0_PIN                       0u
#define P12_0_NUM                       0u
#define P12_1_PORT                      GPIO_PRT12
#define P12_1_PIN                       1u
#define P12_1_NUM                       1u
#define P12_2_PORT                      GPIO_PRT12
#define P12_2_PIN                       2u
#define P12_2_NUM                       2u
#define P12_3_PORT                      GPIO_PRT12
#define P12_3_PIN                       3u
#define P12_3_NUM                       3u
#define P12_4_PORT                      GPIO_PRT12
#define P12_4_PIN                       4u
#define P12_4_NUM                       4u
#define P12_5_PORT                      GPIO_PRT12
#define P12_5_PIN                       5u
#define P12_5_NUM                       5u
#define P12_6_PORT                      GPIO_PRT12
#define P12_6_PIN                       6u
#define P12_6_NUM                       6u
#define P12_7_PORT                      GPIO_PRT12
#define P12_7_PIN                       7u
#define P12_7_NUM                       7u

/* PORT 13 (GPIO) */
#define P13_0_PORT                      GPIO_PRT13
#define P13_0_PIN                       0u
#define P13_0_NUM                       0u
#define P13_1_PORT                      GPIO_PRT13
#define P13_1_PIN                       1u
#define P13_1_NUM                       1u
#define P13_2_PORT                      GPIO_PRT13
#define P13_2_PIN                       2u
#define P13_2_NUM                       2u

/* Analog Connections */
#define IOSS_ADFT0_NET0_PORT            9u
#define IOSS_ADFT0_NET0_PIN             2u
#define IOSS_ADFT1_NET0_PORT            9u
#define IOSS_ADFT1_NET0_PIN             3u
#define LPCOMP_INN_COMP0_PORT           8u
#define LPCOMP_INN_COMP0_PIN            1u
#define LPCOMP_INN_COMP1_PORT           8u
#define LPCOMP_INN_COMP1_PIN            3u
#define LPCOMP_INP_COMP0_PORT           8u
#define LPCOMP_INP_COMP0_PIN            0u
#define LPCOMP_INP_COMP1_PORT           8u
#define LPCOMP_INP_COMP1_PIN            2u
#define PASS_GPIO_A_AIO_ESD0_PORT       7u
#define PASS_GPIO_A_AIO_ESD0_PIN        4u
#define PASS_GPIO_A_AIO_ESD1_PORT       7u
#define PASS_GPIO_A_AIO_ESD1_PIN        5u
#define PASS_GPIO_A_AIO_ESD2_PORT       7u
#define PASS_GPIO_A_AIO_ESD2_PIN        6u
#define PASS_GPIO_A_AIO_ESD3_PORT       7u
#define PASS_GPIO_A_AIO_ESD3_PIN        7u
#define PASS_GPIO_A_AIO_NOESD0_PORT     7u
#define PASS_GPIO_A_AIO_NOESD0_PIN      4u
#define PASS_GPIO_A_AIO_NOESD1_PORT     7u
#define PASS_GPIO_A_AIO_NOESD1_PIN      6u
#define PASS_GPIO_B_AIO_ESD0_PORT       8u
#define PASS_GPIO_B_AIO_ESD0_PIN        0u
#define PASS_GPIO_B_AIO_ESD1_PORT       8u
#define PASS_GPIO_B_AIO_ESD1_PIN        2u
#define PASS_GPIO_B_AIO_ESD2_PORT       8u
#define PASS_GPIO_B_AIO_ESD2_PIN        4u
#define PASS_GPIO_B_AIO_ESD3_PORT       8u
#define PASS_GPIO_B_AIO_ESD3_PIN        5u
#define PASS_GPIO_B_AIO_NOESD0_PORT     8u
#define PASS_GPIO_B_AIO_NOESD0_PIN      3u
#define PASS_GPIO_B_AIO_NOESD1_PORT     8u
#define PASS_GPIO_B_AIO_NOESD1_PIN      4u
#define SRSS_ECO_IN_PORT                1u
#define SRSS_ECO_IN_PIN                 0u
#define SRSS_ECO_OUT_PORT               1u
#define SRSS_ECO_OUT_PIN                1u
#define SRSS_VEXT_REF_REG_PORT          9u
#define SRSS_VEXT_REF_REG_PIN           5u
#define SRSS_WCO_IN_PORT                0u
#define SRSS_WCO_IN_PIN                 1u
#define SRSS_WCO_OUT_PORT               0u
#define SRSS_WCO_OUT_PIN                0u
#define SVGS_SVGS_TEST_VCCD_FEED_PORT   9u
#define SVGS_SVGS_TEST_VCCD_FEED_PIN    7u

/* HSIOM Connections */
typedef enum
{
    /* Generic HSIOM connections */
    HSIOM_SEL_GPIO                  =  0,       /* GPIO controls 'out' */
    HSIOM_SEL_GPIO_DSI              =  1,       /* GPIO controls 'out', DSI controls 'output enable' */
    HSIOM_SEL_DSI_DSI               =  2,       /* DSI controls 'out' and 'output enable' */
    HSIOM_SEL_DSI_GPIO              =  3,       /* DSI controls 'out', GPIO controls 'output enable' */
    HSIOM_SEL_AMUXA                 =  4,       /* Analog mux bus A */
    HSIOM_SEL_AMUXB                 =  5,       /* Analog mux bus B */
    HSIOM_SEL_AMUXA_DSI             =  6,       /* Analog mux bus A, DSI control */
    HSIOM_SEL_AMUXB_DSI             =  7,       /* Analog mux bus B, DSI control */
    HSIOM_SEL_ACT_0                 =  8,       /* Active functionality 0 */
    HSIOM_SEL_ACT_1                 =  9,       /* Active functionality 1 */
    HSIOM_SEL_ACT_2                 = 10,       /* Active functionality 2 */
    HSIOM_SEL_ACT_3                 = 11,       /* Active functionality 3 */
    HSIOM_SEL_DS_0                  = 12,       /* DeepSleep functionality 0 */
    HSIOM_SEL_DS_1                  = 13,       /* DeepSleep functionality 1 */
    HSIOM_SEL_DS_2                  = 14,       /* DeepSleep functionality 2 */
    HSIOM_SEL_DS_3                  = 15,       /* DeepSleep functionality 3 */
    HSIOM_SEL_ACT_4                 = 16,       /* Active functionality 4 */
    HSIOM_SEL_ACT_5                 = 17,       /* Active functionality 5 */
    HSIOM_SEL_ACT_6                 = 18,       /* Active functionality 6 */
    HSIOM_SEL_ACT_7                 = 19,       /* Active functionality 7 */
    HSIOM_SEL_ACT_8                 = 20,       /* Active functionality 8 */
    HSIOM_SEL_ACT_9                 = 21,       /* Active functionality 9 */
    HSIOM_SEL_ACT_10                = 22,       /* Active functionality 10 */
    HSIOM_SEL_ACT_11                = 23,       /* Active functionality 11 */
    HSIOM_SEL_ACT_12                = 24,       /* Active functionality 12 */
    HSIOM_SEL_ACT_13                = 25,       /* Active functionality 13 */
    HSIOM_SEL_ACT_14                = 26,       /* Active functionality 14 */
    HSIOM_SEL_ACT_15                = 27,       /* Active functionality 15 */
    HSIOM_SEL_DS_4                  = 28,       /* DeepSleep functionality 4 */
    HSIOM_SEL_DS_5                  = 29,       /* DeepSleep functionality 5 */
    HSIOM_SEL_DS_6                  = 30,       /* DeepSleep functionality 6 */
    HSIOM_SEL_DS_7                  = 31,       /* DeepSleep functionality 7 */

    /* P0.0 */
    P0_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P0_0_SCB1_SPI_SELECT4           = 18,       /* Digital Active - scb[1].spi_select4:0 */
    P0_0_SRSS_EXT_CLK               = 20,       /* Digital Active - srss.ext_clk:0 */
    P0_0_SRSS_DDFT_CLK_DIRECT       = 24,       /* Digital Active - srss.ddft_clk_direct */
    P0_0_PERI_TR_IO_OUTPUT75        = 25,       /* Digital Active - peri.tr_io_output[75]:0 */
    P0_0_PERI_TR_IO_INPUT7          = 26,       /* Digital Active - peri.tr_io_input[7]:0 */
    P0_0_PERI_TR_IO_OUTPUT7         = 27,       /* Digital Active - peri.tr_io_output[7]:0 */
    P0_0_IOSS_DDFT_PIN1             = 31,       /* Digital Deep Sleep - ioss.ddft_pin[1]:0 */

    /* P0.1 */
    P0_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P0_1_SCB1_SPI_SELECT5           = 18,       /* Digital Active - scb[1].spi_select5:0 */
    P0_1_PERI_TR_IO_OUTPUT76        = 25,       /* Digital Active - peri.tr_io_output[76]:0 */
    P0_1_PERI_TR_IO_INPUT8          = 26,       /* Digital Active - peri.tr_io_input[8]:0 */
    P0_1_PERI_TR_IO_OUTPUT8         = 27,       /* Digital Active - peri.tr_io_output[8]:0 */

    /* P1.0 */
    P1_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P1_0_PERI_TR_IO_OUTPUT144       =  9,       /* Digital Active - peri.tr_io_output[144]:1 */
    P1_0_PERI_TR_IO_OUTPUT153       = 10,       /* Digital Active - peri.tr_io_output[153]:1 */
    P1_0_SCB1_UART_CTS              = 16,       /* Digital Active - scb[1].uart_cts:0 */
    P1_0_SCB1_SPI_SELECT0           = 18,       /* Digital Active - scb[1].spi_select0:0 */
    P1_0_SCB1_I2C_SCL_DO            = 19,       /* Digital Active - scb[1].i2c_scl_do:0 */
    P1_0_PERI_TR_IO_OUTPUT80        = 25,       /* Digital Active - peri.tr_io_output[80]:0 */
    P1_0_PERI_TR_IO_INPUT12         = 26,       /* Digital Active - peri.tr_io_input[12]:0 */
    P1_0_PERI_TR_IO_OUTPUT12        = 27,       /* Digital Active - peri.tr_io_output[12]:0 */

    /* P1.1 */
    P1_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P1_1_PERI_TR_IO_OUTPUT145       =  9,       /* Digital Active - peri.tr_io_output[145]:1 */
    P1_1_PERI_TR_IO_OUTPUT154       = 10,       /* Digital Active - peri.tr_io_output[154]:1 */
    P1_1_SCB1_UART_RTS              = 16,       /* Digital Active - scb[1].uart_rts:0 */
    P1_1_SCB1_SPI_CLK               = 18,       /* Digital Active - scb[1].spi_clk:0 */
    P1_1_SCB1_I2C_SDA_DO            = 19,       /* Digital Active - scb[1].i2c_sda_do:0 */
    P1_1_PERI_TR_IO_OUTPUT81        = 25,       /* Digital Active - peri.tr_io_output[81]:0 */
    P1_1_PERI_TR_IO_INPUT13         = 26,       /* Digital Active - peri.tr_io_input[13]:0 */
    P1_1_PERI_TR_IO_OUTPUT13        = 27,       /* Digital Active - peri.tr_io_output[13]:0 */

    /* P1.2 */
    P1_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P1_2_PERI_TR_IO_OUTPUT146       =  9,       /* Digital Active - peri.tr_io_output[146]:1 */
    P1_2_PERI_TR_IO_OUTPUT155       = 10,       /* Digital Active - peri.tr_io_output[155]:1 */
    P1_2_SCB1_UART_RX               = 16,       /* Digital Active - scb[1].uart_rx:0 */
    P1_2_SCB1_SPI_MOSI              = 18,       /* Digital Active - scb[1].spi_mosi:0 */
    P1_2_SCB1_I2C_SDA               = 19,       /* Digital Active - scb[1].i2c_sda:0 */
    P1_2_PERI_TR_IO_OUTPUT82        = 25,       /* Digital Active - peri.tr_io_output[82]:0 */
    P1_2_PERI_TR_IO_INPUT14         = 26,       /* Digital Active - peri.tr_io_input[14]:0 */
    P1_2_PERI_TR_IO_OUTPUT14        = 27,       /* Digital Active - peri.tr_io_output[14]:0 */
    P1_2_DEBUG600_CLK_SWJ_SWCLK_TCLK = 29,      /* Digital Deep Sleep - debug600.clk_swj_swclk_tclk */

    /* P1.3 */
    P1_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P1_3_PERI_TR_IO_OUTPUT147       =  9,       /* Digital Active - peri.tr_io_output[147]:1 */
    P1_3_PERI_TR_IO_OUTPUT156       = 10,       /* Digital Active - peri.tr_io_output[156]:1 */
    P1_3_SCB1_UART_TX               = 16,       /* Digital Active - scb[1].uart_tx:0 */
    P1_3_SCB1_SPI_MISO              = 18,       /* Digital Active - scb[1].spi_miso:0 */
    P1_3_SCB1_I2C_SCL               = 19,       /* Digital Active - scb[1].i2c_scl:0 */
    P1_3_PERI_TR_IO_OUTPUT83        = 25,       /* Digital Active - peri.tr_io_output[83]:0 */
    P1_3_PERI_TR_IO_INPUT15         = 26,       /* Digital Active - peri.tr_io_input[15]:0 */
    P1_3_PERI_TR_IO_OUTPUT15        = 27,       /* Digital Active - peri.tr_io_output[15]:0 */
    P1_3_DEBUG600_SWJ_SWDIO_TMS     = 29,       /* Digital Deep Sleep - debug600.swj_swdio_tms */

    /* P2.0 */
    P2_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P2_0_PERI_TR_IO_OUTPUT144       =  9,       /* Digital Active - peri.tr_io_output[144]:0 */
    P2_0_TCPWM0_LINE518             = 10,       /* Digital Active - tcpwm[0].line[518]:1 */
    P2_0_SCB1_UART_CTS              = 16,       /* Digital Active - scb[1].uart_cts:1 */
    P2_0_SCB1_SPI_SELECT0           = 18,       /* Digital Active - scb[1].spi_select0:1 */
    P2_0_SCB1_I2C_SCL_DO            = 19,       /* Digital Active - scb[1].i2c_scl_do:1 */
    P2_0_PERI_TR_IO_OUTPUT84        = 25,       /* Digital Active - peri.tr_io_output[84]:0 */
    P2_0_PERI_TR_IO_INPUT16         = 26,       /* Digital Active - peri.tr_io_input[16]:0 */
    P2_0_PERI_TR_IO_OUTPUT16        = 27,       /* Digital Active - peri.tr_io_output[16]:0 */
    P2_0_DEBUG600_SWJ_SWDOE_TDI     = 29,       /* Digital Deep Sleep - debug600.swj_swdoe_tdi */
    P2_0_IOSS_DDFT_PIN0             = 31,       /* Digital Deep Sleep - ioss.ddft_pin[0]:0 */

    /* P2.1 */
    P2_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P2_1_PERI_TR_IO_OUTPUT145       =  9,       /* Digital Active - peri.tr_io_output[145]:0 */
    P2_1_TCPWM0_LINE_COMPL518       = 10,       /* Digital Active - tcpwm[0].line_compl[518]:1 */
    P2_1_SRSS_CAL_WAVE              = 12,       /* Digital Deep Sleep - srss.cal_wave */
    P2_1_SCB1_UART_RTS              = 16,       /* Digital Active - scb[1].uart_rts:1 */
    P2_1_SCB1_SPI_CLK               = 18,       /* Digital Active - scb[1].spi_clk:1 */
    P2_1_SCB1_I2C_SCL               = 19,       /* Digital Active - scb[1].i2c_scl:1 */
    P2_1_PERI_TR_IO_OUTPUT85        = 25,       /* Digital Active - peri.tr_io_output[85]:0 */
    P2_1_PERI_TR_IO_INPUT17         = 26,       /* Digital Active - peri.tr_io_input[17]:0 */
    P2_1_PERI_TR_IO_OUTPUT17        = 27,       /* Digital Active - peri.tr_io_output[17]:0 */
    P2_1_DEBUG600_SWJ_SWO_TDO       = 29,       /* Digital Deep Sleep - debug600.swj_swo_tdo */

    /* P2.2 */
    P2_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P2_2_PERI_TR_IO_OUTPUT146       =  9,       /* Digital Active - peri.tr_io_output[146]:0 */
    P2_2_TCPWM0_LINE519             = 10,       /* Digital Active - tcpwm[0].line[519]:1 */
    P2_2_SCB1_UART_RX               = 16,       /* Digital Active - scb[1].uart_rx:1 */
    P2_2_SCB1_SPI_MOSI              = 18,       /* Digital Active - scb[1].spi_mosi:1 */
    P2_2_SCB1_I2C_SDA               = 19,       /* Digital Active - scb[1].i2c_sda:1 */
    P2_2_SRSS_EXT_CLK               = 20,       /* Digital Active - srss.ext_clk:1 */
    P2_2_PERI_TR_IO_OUTPUT86        = 25,       /* Digital Active - peri.tr_io_output[86]:0 */
    P2_2_PERI_TR_IO_INPUT18         = 26,       /* Digital Active - peri.tr_io_input[18]:0 */
    P2_2_PERI_TR_IO_OUTPUT18        = 27,       /* Digital Active - peri.tr_io_output[18]:0 */

    /* P2.3 */
    P2_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P2_3_PERI_TR_IO_OUTPUT147       =  9,       /* Digital Active - peri.tr_io_output[147]:0 */
    P2_3_TCPWM0_LINE_COMPL519       = 10,       /* Digital Active - tcpwm[0].line_compl[519]:1 */
    P2_3_SCB1_UART_TX               = 16,       /* Digital Active - scb[1].uart_tx:1 */
    P2_3_SCB1_SPI_MISO              = 18,       /* Digital Active - scb[1].spi_miso:1 */
    P2_3_SCB1_I2C_SDA_DO            = 19,       /* Digital Active - scb[1].i2c_sda_do:1 */
    P2_3_PERI_TR_IO_OUTPUT87        = 25,       /* Digital Active - peri.tr_io_output[87]:0 */
    P2_3_PERI_TR_IO_INPUT19         = 26,       /* Digital Active - peri.tr_io_input[19]:0 */
    P2_3_PERI_TR_IO_OUTPUT19        = 27,       /* Digital Active - peri.tr_io_output[19]:0 */

    /* P3.0 */
    P3_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P3_0_TCPWM0_LINE4               =  8,       /* Digital Active - tcpwm[0].line[4]:0 */
    P3_0_PERI_TR_IO_OUTPUT148       =  9,       /* Digital Active - peri.tr_io_output[148]:0 */
    P3_0_PERI_TR_IO_OUTPUT157       = 10,       /* Digital Active - peri.tr_io_output[157]:1 */
    P3_0_SCB4_UART_CTS              = 16,       /* Digital Active - scb[4].uart_cts:0 */
    P3_0_SCB4_SPI_MOSI              = 18,       /* Digital Active - scb[4].spi_mosi:0 */
    P3_0_SCB4_I2C_SDA_DO            = 19,       /* Digital Active - scb[4].i2c_sda_do:0 */
    P3_0_PERI_TR_IO_OUTPUT88        = 25,       /* Digital Active - peri.tr_io_output[88]:0 */
    P3_0_PERI_TR_IO_INPUT20         = 26,       /* Digital Active - peri.tr_io_input[20]:0 */
    P3_0_PERI_TR_IO_OUTPUT20        = 27,       /* Digital Active - peri.tr_io_output[20]:0 */

    /* P3.1 */
    P3_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P3_1_TCPWM0_LINE_COMPL4         =  8,       /* Digital Active - tcpwm[0].line_compl[4]:0 */
    P3_1_PERI_TR_IO_OUTPUT149       =  9,       /* Digital Active - peri.tr_io_output[149]:0 */
    P3_1_PERI_TR_IO_OUTPUT158       = 10,       /* Digital Active - peri.tr_io_output[158]:1 */
    P3_1_SCB4_UART_RTS              = 16,       /* Digital Active - scb[4].uart_rts:0 */
    P3_1_SCB4_SPI_MISO              = 18,       /* Digital Active - scb[4].spi_miso:0 */
    P3_1_SCB4_I2C_SDA               = 19,       /* Digital Active - scb[4].i2c_sda:0 */
    P3_1_PERI_TR_IO_OUTPUT89        = 25,       /* Digital Active - peri.tr_io_output[89]:0 */
    P3_1_PERI_TR_IO_INPUT21         = 26,       /* Digital Active - peri.tr_io_input[21]:0 */
    P3_1_PERI_TR_IO_OUTPUT21        = 27,       /* Digital Active - peri.tr_io_output[21]:0 */

    /* P3.2 */
    P3_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P3_2_TCPWM0_LINE5               =  8,       /* Digital Active - tcpwm[0].line[5]:0 */
    P3_2_PERI_TR_IO_OUTPUT150       =  9,       /* Digital Active - peri.tr_io_output[150]:0 */
    P3_2_PERI_TR_IO_OUTPUT159       = 10,       /* Digital Active - peri.tr_io_output[159]:1 */
    P3_2_SCB4_UART_RX               = 16,       /* Digital Active - scb[4].uart_rx:0 */
    P3_2_SCB4_SPI_CLK               = 18,       /* Digital Active - scb[4].spi_clk:0 */
    P3_2_SCB4_I2C_SCL               = 19,       /* Digital Active - scb[4].i2c_scl:0 */
    P3_2_PERI_TR_IO_OUTPUT90        = 25,       /* Digital Active - peri.tr_io_output[90]:0 */
    P3_2_PERI_TR_IO_INPUT22         = 26,       /* Digital Active - peri.tr_io_input[22]:0 */
    P3_2_PERI_TR_IO_OUTPUT22        = 27,       /* Digital Active - peri.tr_io_output[22]:0 */

    /* P3.3 */
    P3_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P3_3_TCPWM0_LINE_COMPL5         =  8,       /* Digital Active - tcpwm[0].line_compl[5]:0 */
    P3_3_PERI_TR_IO_OUTPUT151       =  9,       /* Digital Active - peri.tr_io_output[151]:0 */
    P3_3_SCB4_UART_TX               = 16,       /* Digital Active - scb[4].uart_tx:0 */
    P3_3_SCB4_SPI_SELECT0           = 18,       /* Digital Active - scb[4].spi_select0:0 */
    P3_3_SCB4_I2C_SCL_DO            = 19,       /* Digital Active - scb[4].i2c_scl_do:0 */
    P3_3_PERI_TR_IO_OUTPUT91        = 25,       /* Digital Active - peri.tr_io_output[91]:0 */
    P3_3_PERI_TR_IO_INPUT23         = 26,       /* Digital Active - peri.tr_io_input[23]:0 */
    P3_3_PERI_TR_IO_OUTPUT23        = 27,       /* Digital Active - peri.tr_io_output[23]:0 */

    /* P4.0 */
    P4_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P4_0_PERI_TR_IO_OUTPUT136       =  8,       /* Digital Active - peri.tr_io_output[136]:0 */
    P4_0_TCPWM0_LINE260             =  9,       /* Digital Active - tcpwm[0].line[260]:0 */
    P4_0_TCPWM0_LINE0               = 10,       /* Digital Active - tcpwm[0].line[0]:0 */
    P4_0_SCB4_UART_CTS              = 16,       /* Digital Active - scb[4].uart_cts:1 */
    P4_0_SCB4_SPI_MOSI              = 18,       /* Digital Active - scb[4].spi_mosi:1 */
    P4_0_SCB4_I2C_SDA_DO            = 19,       /* Digital Active - scb[4].i2c_sda_do:1 */
    P4_0_PERI_TR_IO_OUTPUT92        = 25,       /* Digital Active - peri.tr_io_output[92]:0 */
    P4_0_PERI_TR_IO_INPUT24         = 26,       /* Digital Active - peri.tr_io_input[24]:0 */
    P4_0_PERI_TR_IO_OUTPUT24        = 27,       /* Digital Active - peri.tr_io_output[24]:0 */

    /* P4.1 */
    P4_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P4_1_PERI_TR_IO_OUTPUT137       =  8,       /* Digital Active - peri.tr_io_output[137]:0 */
    P4_1_TCPWM0_LINE_COMPL260       =  9,       /* Digital Active - tcpwm[0].line_compl[260]:0 */
    P4_1_TCPWM0_LINE_COMPL0         = 10,       /* Digital Active - tcpwm[0].line_compl[0]:0 */
    P4_1_SCB4_UART_RTS              = 16,       /* Digital Active - scb[4].uart_rts:1 */
    P4_1_SCB4_SPI_MISO              = 18,       /* Digital Active - scb[4].spi_miso:1 */
    P4_1_SCB4_I2C_SDA               = 19,       /* Digital Active - scb[4].i2c_sda:1 */
    P4_1_PERI_TR_IO_OUTPUT93        = 25,       /* Digital Active - peri.tr_io_output[93]:0 */
    P4_1_PERI_TR_IO_INPUT25         = 26,       /* Digital Active - peri.tr_io_input[25]:0 */
    P4_1_PERI_TR_IO_OUTPUT25        = 27,       /* Digital Active - peri.tr_io_output[25]:0 */

    /* P4.2 */
    P4_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P4_2_PERI_TR_IO_OUTPUT138       =  8,       /* Digital Active - peri.tr_io_output[138]:0 */
    P4_2_TCPWM0_LINE261             =  9,       /* Digital Active - tcpwm[0].line[261]:0 */
    P4_2_TCPWM0_LINE1               = 10,       /* Digital Active - tcpwm[0].line[1]:0 */
    P4_2_SCB4_UART_RX               = 16,       /* Digital Active - scb[4].uart_rx:1 */
    P4_2_SCB4_SPI_CLK               = 18,       /* Digital Active - scb[4].spi_clk:1 */
    P4_2_SCB4_I2C_SCL               = 19,       /* Digital Active - scb[4].i2c_scl:1 */
    P4_2_PERI_TR_IO_OUTPUT94        = 25,       /* Digital Active - peri.tr_io_output[94]:0 */
    P4_2_PERI_TR_IO_INPUT26         = 26,       /* Digital Active - peri.tr_io_input[26]:0 */
    P4_2_PERI_TR_IO_OUTPUT26        = 27,       /* Digital Active - peri.tr_io_output[26]:0 */

    /* P4.3 */
    P4_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P4_3_PERI_TR_IO_OUTPUT139       =  8,       /* Digital Active - peri.tr_io_output[139]:0 */
    P4_3_TCPWM0_LINE_COMPL261       =  9,       /* Digital Active - tcpwm[0].line_compl[261]:0 */
    P4_3_TCPWM0_LINE_COMPL1         = 10,       /* Digital Active - tcpwm[0].line_compl[1]:0 */
    P4_3_SCB4_UART_TX               = 16,       /* Digital Active - scb[4].uart_tx:1 */
    P4_3_SCB4_SPI_SELECT0           = 18,       /* Digital Active - scb[4].spi_select0:1 */
    P4_3_SCB4_I2C_SCL_DO            = 19,       /* Digital Active - scb[4].i2c_scl_do:1 */
    P4_3_PERI_TR_IO_OUTPUT95        = 25,       /* Digital Active - peri.tr_io_output[95]:0 */
    P4_3_PERI_TR_IO_INPUT27         = 26,       /* Digital Active - peri.tr_io_input[27]:0 */
    P4_3_PERI_TR_IO_OUTPUT27        = 27,       /* Digital Active - peri.tr_io_output[27]:0 */

    /* P4.4 */
    P4_4_GPIO                       =  0,       /* GPIO controls 'out' */
    P4_4_PERI_TR_IO_OUTPUT140       =  8,       /* Digital Active - peri.tr_io_output[140]:0 */
    P4_4_TCPWM0_LINE262             =  9,       /* Digital Active - tcpwm[0].line[262]:0 */
    P4_4_TCPWM0_LINE2               = 10,       /* Digital Active - tcpwm[0].line[2]:0 */
    P4_4_SCB4_SPI_SELECT1           = 18,       /* Digital Active - scb[4].spi_select1:0 */
    P4_4_PERI_TR_IO_OUTPUT98        = 25,       /* Digital Active - peri.tr_io_output[98]:0 */
    P4_4_PERI_TR_IO_INPUT30         = 26,       /* Digital Active - peri.tr_io_input[30]:0 */
    P4_4_PERI_TR_IO_OUTPUT30        = 27,       /* Digital Active - peri.tr_io_output[30]:0 */

    /* P4.5 */
    P4_5_GPIO                       =  0,       /* GPIO controls 'out' */
    P4_5_PERI_TR_IO_OUTPUT141       =  8,       /* Digital Active - peri.tr_io_output[141]:0 */
    P4_5_TCPWM0_LINE_COMPL262       =  9,       /* Digital Active - tcpwm[0].line_compl[262]:0 */
    P4_5_TCPWM0_LINE_COMPL2         = 10,       /* Digital Active - tcpwm[0].line_compl[2]:0 */
    P4_5_SCB4_SPI_SELECT2           = 18,       /* Digital Active - scb[4].spi_select2:0 */
    P4_5_PERI_TR_IO_OUTPUT99        = 25,       /* Digital Active - peri.tr_io_output[99]:0 */
    P4_5_PERI_TR_IO_INPUT31         = 26,       /* Digital Active - peri.tr_io_input[31]:0 */
    P4_5_PERI_TR_IO_OUTPUT31        = 27,       /* Digital Active - peri.tr_io_output[31]:0 */

    /* P4.6 */
    P4_6_GPIO                       =  0,       /* GPIO controls 'out' */
    P4_6_PERI_TR_IO_OUTPUT142       =  8,       /* Digital Active - peri.tr_io_output[142]:0 */
    P4_6_TCPWM0_LINE263             =  9,       /* Digital Active - tcpwm[0].line[263]:0 */
    P4_6_TCPWM0_LINE3               = 10,       /* Digital Active - tcpwm[0].line[3]:0 */
    P4_6_SCB4_SPI_SELECT3           = 18,       /* Digital Active - scb[4].spi_select3:0 */
    P4_6_PERI_TR_IO_OUTPUT100       = 25,       /* Digital Active - peri.tr_io_output[100]:0 */
    P4_6_PERI_TR_IO_INPUT32         = 26,       /* Digital Active - peri.tr_io_input[32]:0 */
    P4_6_PERI_TR_IO_OUTPUT32        = 27,       /* Digital Active - peri.tr_io_output[32]:0 */

    /* P4.7 */
    P4_7_GPIO                       =  0,       /* GPIO controls 'out' */
    P4_7_PERI_TR_IO_OUTPUT143       =  8,       /* Digital Active - peri.tr_io_output[143]:0 */
    P4_7_TCPWM0_LINE_COMPL263       =  9,       /* Digital Active - tcpwm[0].line_compl[263]:0 */
    P4_7_TCPWM0_LINE_COMPL3         = 10,       /* Digital Active - tcpwm[0].line_compl[3]:0 */
    P4_7_PERI_TR_IO_OUTPUT101       = 25,       /* Digital Active - peri.tr_io_output[101]:0 */
    P4_7_PERI_TR_IO_INPUT33         = 26,       /* Digital Active - peri.tr_io_input[33]:0 */
    P4_7_PERI_TR_IO_OUTPUT33        = 27,       /* Digital Active - peri.tr_io_output[33]:0 */

    /* P5.0 */
    P5_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P5_0_TCPWM0_LINE6               =  8,       /* Digital Active - tcpwm[0].line[6]:0 */
    P5_0_PERI_TR_IO_OUTPUT148       =  9,       /* Digital Active - peri.tr_io_output[148]:1 */
    P5_0_SCB3_UART_CTS              = 16,       /* Digital Active - scb[3].uart_cts:0 */
    P5_0_SCB3_SPI_MOSI              = 18,       /* Digital Active - scb[3].spi_mosi:0 */
    P5_0_SCB3_I2C_SDA               = 19,       /* Digital Active - scb[3].i2c_sda:0 */
    P5_0_I3C0_I3C_SDA               = 22,       /* Digital Active - i3c[0].i3c_sda:1 */
    P5_0_PERI_TR_IO_OUTPUT102       = 25,       /* Digital Active - peri.tr_io_output[102]:0 */
    P5_0_PERI_TR_IO_INPUT34         = 26,       /* Digital Active - peri.tr_io_input[34]:0 */
    P5_0_PERI_TR_IO_OUTPUT34        = 27,       /* Digital Active - peri.tr_io_output[34]:0 */

    /* P5.1 */
    P5_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P5_1_TCPWM0_LINE_COMPL6         =  8,       /* Digital Active - tcpwm[0].line_compl[6]:0 */
    P5_1_PERI_TR_IO_OUTPUT149       =  9,       /* Digital Active - peri.tr_io_output[149]:1 */
    P5_1_SCB3_UART_RTS              = 16,       /* Digital Active - scb[3].uart_rts:0 */
    P5_1_SCB3_SPI_MISO              = 18,       /* Digital Active - scb[3].spi_miso:0 */
    P5_1_SCB3_I2C_SCL               = 19,       /* Digital Active - scb[3].i2c_scl:0 */
    P5_1_I3C0_I3C_SCL               = 22,       /* Digital Active - i3c[0].i3c_scl:1 */
    P5_1_PERI_TR_IO_OUTPUT103       = 25,       /* Digital Active - peri.tr_io_output[103]:0 */
    P5_1_PERI_TR_IO_INPUT35         = 26,       /* Digital Active - peri.tr_io_input[35]:0 */
    P5_1_PERI_TR_IO_OUTPUT35        = 27,       /* Digital Active - peri.tr_io_output[35]:0 */

    /* P5.2 */
    P5_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P5_2_TCPWM0_LINE7               =  8,       /* Digital Active - tcpwm[0].line[7]:0 */
    P5_2_PERI_TR_IO_OUTPUT150       =  9,       /* Digital Active - peri.tr_io_output[150]:1 */
    P5_2_CANFD0_TTCAN_RX1           = 11,       /* Digital Active - canfd[0].ttcan_rx[1]:0 */
    P5_2_SCB3_UART_RX               = 16,       /* Digital Active - scb[3].uart_rx:0 */
    P5_2_SCB3_SPI_CLK               = 18,       /* Digital Active - scb[3].spi_clk:0 */
    P5_2_SCB3_I2C_SDA               = 19,       /* Digital Active - scb[3].i2c_sda:2 */
    P5_2_SCB3_I2C_SDA_DO            = 20,       /* Digital Active - scb[3].i2c_sda_do:0 */
    P5_2_I3C0_I3C_SDA_PULLUP_EN     = 22,       /* Digital Active - i3c[0].i3c_sda_pullup_en:0 */
    P5_2_PERI_TR_IO_OUTPUT104       = 25,       /* Digital Active - peri.tr_io_output[104]:0 */
    P5_2_PERI_TR_IO_INPUT36         = 26,       /* Digital Active - peri.tr_io_input[36]:0 */
    P5_2_PERI_TR_IO_OUTPUT36        = 27,       /* Digital Active - peri.tr_io_output[36]:0 */

    /* P5.3 */
    P5_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P5_3_TCPWM0_LINE_COMPL7         =  8,       /* Digital Active - tcpwm[0].line_compl[7]:0 */
    P5_3_PERI_TR_IO_OUTPUT151       =  9,       /* Digital Active - peri.tr_io_output[151]:1 */
    P5_3_CANFD0_TTCAN_TX1           = 11,       /* Digital Active - canfd[0].ttcan_tx[1]:0 */
    P5_3_SCB3_UART_TX               = 16,       /* Digital Active - scb[3].uart_tx:0 */
    P5_3_SCB3_SPI_SELECT0           = 18,       /* Digital Active - scb[3].spi_select0:0 */
    P5_3_SCB3_I2C_SCL               = 19,       /* Digital Active - scb[3].i2c_scl:2 */
    P5_3_SCB3_I2C_SCL_DO            = 20,       /* Digital Active - scb[3].i2c_scl_do:0 */
    P5_3_I3C0_I3C_SCL_PULLUP_EN     = 22,       /* Digital Active - i3c[0].i3c_scl_pullup_en:0 */
    P5_3_PERI_TR_IO_OUTPUT105       = 25,       /* Digital Active - peri.tr_io_output[105]:0 */
    P5_3_PERI_TR_IO_INPUT37         = 26,       /* Digital Active - peri.tr_io_input[37]:0 */
    P5_3_PERI_TR_IO_OUTPUT37        = 27,       /* Digital Active - peri.tr_io_output[37]:0 */

    /* P6.0 */
    P6_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P6_0_TCPWM0_LINE260             =  9,       /* Digital Active - tcpwm[0].line[260]:1 */
    P6_0_PERI_TR_IO_OUTPUT152       = 10,       /* Digital Active - peri.tr_io_output[152]:0 */
    P6_0_SCB3_UART_CTS              = 16,       /* Digital Active - scb[3].uart_cts:1 */
    P6_0_SCB3_SPI_MOSI              = 18,       /* Digital Active - scb[3].spi_mosi:1 */
    P6_0_SCB3_I2C_SDA               = 19,       /* Digital Active - scb[3].i2c_sda:1 */
    P6_0_I3C0_I3C_SDA               = 22,       /* Digital Active - i3c[0].i3c_sda:0 */
    P6_0_PERI_TR_IO_OUTPUT106       = 25,       /* Digital Active - peri.tr_io_output[106]:0 */
    P6_0_PERI_TR_IO_INPUT38         = 26,       /* Digital Active - peri.tr_io_input[38]:0 */
    P6_0_PERI_TR_IO_OUTPUT38        = 27,       /* Digital Active - peri.tr_io_output[38]:0 */

    /* P6.1 */
    P6_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P6_1_TCPWM0_LINE_COMPL260       =  9,       /* Digital Active - tcpwm[0].line_compl[260]:1 */
    P6_1_PERI_TR_IO_OUTPUT153       = 10,       /* Digital Active - peri.tr_io_output[153]:0 */
    P6_1_SCB3_UART_RTS              = 16,       /* Digital Active - scb[3].uart_rts:1 */
    P6_1_SCB3_SPI_MISO              = 18,       /* Digital Active - scb[3].spi_miso:1 */
    P6_1_SCB3_I2C_SCL               = 19,       /* Digital Active - scb[3].i2c_scl:1 */
    P6_1_I3C0_I3C_SCL               = 22,       /* Digital Active - i3c[0].i3c_scl:0 */
    P6_1_PERI_TR_IO_OUTPUT107       = 25,       /* Digital Active - peri.tr_io_output[107]:0 */
    P6_1_PERI_TR_IO_INPUT39         = 26,       /* Digital Active - peri.tr_io_input[39]:0 */
    P6_1_PERI_TR_IO_OUTPUT39        = 27,       /* Digital Active - peri.tr_io_output[39]:0 */

    /* P6.2 */
    P6_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P6_2_TCPWM0_LINE261             =  9,       /* Digital Active - tcpwm[0].line[261]:1 */
    P6_2_PERI_TR_IO_OUTPUT154       = 10,       /* Digital Active - peri.tr_io_output[154]:0 */
    P6_2_CANFD0_TTCAN_RX1           = 11,       /* Digital Active - canfd[0].ttcan_rx[1]:1 */
    P6_2_SCB3_UART_RX               = 16,       /* Digital Active - scb[3].uart_rx:1 */
    P6_2_SCB3_SPI_CLK               = 18,       /* Digital Active - scb[3].spi_clk:1 */
    P6_2_SCB3_I2C_SDA               = 19,       /* Digital Active - scb[3].i2c_sda:3 */
    P6_2_SCB3_I2C_SDA_DO            = 20,       /* Digital Active - scb[3].i2c_sda_do:1 */
    P6_2_I3C0_I3C_SDA_PULLUP_EN     = 22,       /* Digital Active - i3c[0].i3c_sda_pullup_en:1 */
    P6_2_PERI_TR_IO_OUTPUT108       = 25,       /* Digital Active - peri.tr_io_output[108]:0 */
    P6_2_PERI_TR_IO_INPUT40         = 26,       /* Digital Active - peri.tr_io_input[40]:0 */
    P6_2_PERI_TR_IO_OUTPUT40        = 27,       /* Digital Active - peri.tr_io_output[40]:0 */

    /* P6.3 */
    P6_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P6_3_TCPWM0_LINE_COMPL261       =  9,       /* Digital Active - tcpwm[0].line_compl[261]:1 */
    P6_3_PERI_TR_IO_OUTPUT155       = 10,       /* Digital Active - peri.tr_io_output[155]:0 */
    P6_3_CANFD0_TTCAN_TX1           = 11,       /* Digital Active - canfd[0].ttcan_tx[1]:1 */
    P6_3_SCB3_UART_TX               = 16,       /* Digital Active - scb[3].uart_tx:1 */
    P6_3_SCB3_SPI_SELECT0           = 18,       /* Digital Active - scb[3].spi_select0:1 */
    P6_3_SCB3_I2C_SCL               = 19,       /* Digital Active - scb[3].i2c_scl:3 */
    P6_3_SCB3_I2C_SCL_DO            = 20,       /* Digital Active - scb[3].i2c_scl_do:1 */
    P6_3_CPUSS_FAULT0               = 21,       /* Digital Active - cpuss.fault[0]:1 */
    P6_3_I3C0_I3C_SCL_PULLUP_EN     = 22,       /* Digital Active - i3c[0].i3c_scl_pullup_en:1 */
    P6_3_PERI_TR_IO_OUTPUT109       = 25,       /* Digital Active - peri.tr_io_output[109]:0 */
    P6_3_PERI_TR_IO_INPUT41         = 26,       /* Digital Active - peri.tr_io_input[41]:0 */
    P6_3_PERI_TR_IO_OUTPUT41        = 27,       /* Digital Active - peri.tr_io_output[41]:0 */

    /* P7.0 */
    P7_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P7_0_PERI_TR_IO_OUTPUT136       =  8,       /* Digital Active - peri.tr_io_output[136]:1 */
    P7_0_TCPWM0_LINE262             =  9,       /* Digital Active - tcpwm[0].line[262]:1 */
    P7_0_PERI_TR_IO_OUTPUT156       = 10,       /* Digital Active - peri.tr_io_output[156]:0 */
    P7_0_SCB2_UART_CTS              = 16,       /* Digital Active - scb[2].uart_cts:0 */
    P7_0_SCB2_SPI_CLK               = 17,       /* Digital Active - scb[2].spi_clk:0 */
    P7_0_SCB2_I2C_SCL               = 19,       /* Digital Active - scb[2].i2c_scl:0 */
    P7_0_DEBUG600_TRACE_DATA0       = 21,       /* Digital Active - debug600.trace_data[0]:0 */
    P7_0_I3C0_I3C_SDA_PULLUP_EN     = 22,       /* Digital Active - i3c[0].i3c_sda_pullup_en:2 */
    P7_0_PASS_MCPASS_DOUT0          = 24,       /* Digital Active - pass.mcpass_dout[0]:0 */
    P7_0_PERI_TR_IO_OUTPUT116       = 25,       /* Digital Active - peri.tr_io_output[116]:0 */
    P7_0_PERI_TR_IO_INPUT48         = 26,       /* Digital Active - peri.tr_io_input[48]:0 */
    P7_0_PERI_TR_IO_OUTPUT48        = 27,       /* Digital Active - peri.tr_io_output[48]:0 */

    /* P7.1 */
    P7_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P7_1_PERI_TR_IO_OUTPUT137       =  8,       /* Digital Active - peri.tr_io_output[137]:1 */
    P7_1_TCPWM0_LINE_COMPL262       =  9,       /* Digital Active - tcpwm[0].line_compl[262]:1 */
    P7_1_PERI_TR_IO_OUTPUT157       = 10,       /* Digital Active - peri.tr_io_output[157]:0 */
    P7_1_SCB2_UART_TX               = 16,       /* Digital Active - scb[2].uart_tx:0 */
    P7_1_SCB2_SPI_MOSI              = 17,       /* Digital Active - scb[2].spi_mosi:0 */
    P7_1_SCB2_I2C_SDA               = 19,       /* Digital Active - scb[2].i2c_sda:0 */
    P7_1_DEBUG600_TRACE_DATA1       = 21,       /* Digital Active - debug600.trace_data[1]:0 */
    P7_1_I3C0_I3C_SCL_PULLUP_EN     = 22,       /* Digital Active - i3c[0].i3c_scl_pullup_en:2 */
    P7_1_PASS_MCPASS_DOUT1          = 24,       /* Digital Active - pass.mcpass_dout[1]:0 */
    P7_1_PERI_TR_IO_OUTPUT117       = 25,       /* Digital Active - peri.tr_io_output[117]:0 */
    P7_1_PERI_TR_IO_INPUT49         = 26,       /* Digital Active - peri.tr_io_input[49]:0 */
    P7_1_PERI_TR_IO_OUTPUT49        = 27,       /* Digital Active - peri.tr_io_output[49]:0 */

    /* P7.2 */
    P7_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P7_2_PERI_TR_IO_OUTPUT138       =  8,       /* Digital Active - peri.tr_io_output[138]:1 */
    P7_2_TCPWM0_LINE263             =  9,       /* Digital Active - tcpwm[0].line[263]:1 */
    P7_2_PERI_TR_IO_OUTPUT158       = 10,       /* Digital Active - peri.tr_io_output[158]:0 */
    P7_2_SCB2_UART_RX               = 16,       /* Digital Active - scb[2].uart_rx:0 */
    P7_2_SCB2_SPI_MISO              = 17,       /* Digital Active - scb[2].spi_miso:0 */
    P7_2_SCB2_I2C_SDA_DO            = 19,       /* Digital Active - scb[2].i2c_sda_do:0 */
    P7_2_DEBUG600_TRACE_DATA2       = 21,       /* Digital Active - debug600.trace_data[2]:0 */
    P7_2_PASS_MCPASS_DOUT2          = 24,       /* Digital Active - pass.mcpass_dout[2]:0 */
    P7_2_PERI_TR_IO_OUTPUT118       = 25,       /* Digital Active - peri.tr_io_output[118]:0 */
    P7_2_PERI_TR_IO_INPUT50         = 26,       /* Digital Active - peri.tr_io_input[50]:0 */
    P7_2_PERI_TR_IO_OUTPUT50        = 27,       /* Digital Active - peri.tr_io_output[50]:0 */

    /* P7.3 */
    P7_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P7_3_PERI_TR_IO_OUTPUT139       =  8,       /* Digital Active - peri.tr_io_output[139]:1 */
    P7_3_TCPWM0_LINE_COMPL263       =  9,       /* Digital Active - tcpwm[0].line_compl[263]:1 */
    P7_3_PERI_TR_IO_OUTPUT159       = 10,       /* Digital Active - peri.tr_io_output[159]:0 */
    P7_3_SCB2_UART_RTS              = 16,       /* Digital Active - scb[2].uart_rts:0 */
    P7_3_SCB2_SPI_SELECT0           = 17,       /* Digital Active - scb[2].spi_select0:0 */
    P7_3_SCB2_I2C_SCL_DO            = 19,       /* Digital Active - scb[2].i2c_scl_do:0 */
    P7_3_DEBUG600_TRACE_DATA3       = 21,       /* Digital Active - debug600.trace_data[3]:0 */
    P7_3_PASS_MCPASS_DOUT3          = 24,       /* Digital Active - pass.mcpass_dout[3]:0 */
    P7_3_PERI_TR_IO_OUTPUT119       = 25,       /* Digital Active - peri.tr_io_output[119]:0 */
    P7_3_PERI_TR_IO_INPUT51         = 26,       /* Digital Active - peri.tr_io_input[51]:0 */
    P7_3_PERI_TR_IO_OUTPUT51        = 27,       /* Digital Active - peri.tr_io_output[51]:0 */

    /* P7.4 */
    P7_4_GPIO                       =  0,       /* GPIO controls 'out' */
    P7_4_PERI_TR_IO_OUTPUT140       =  8,       /* Digital Active - peri.tr_io_output[140]:1 */
    P7_4_SCB2_SPI_SELECT1           = 17,       /* Digital Active - scb[2].spi_select1:0 */
    P7_4_DEBUG600_TRACE_CLOCK       = 21,       /* Digital Active - debug600.trace_clock:0 */
    P7_4_PASS_MCPASS_DCLK           = 24,       /* Digital Active - pass.mcpass_dclk:0 */
    P7_4_PERI_TR_IO_OUTPUT120       = 25,       /* Digital Active - peri.tr_io_output[120]:0 */
    P7_4_PERI_TR_IO_INPUT52         = 26,       /* Digital Active - peri.tr_io_input[52]:0 */
    P7_4_PERI_TR_IO_OUTPUT52        = 27,       /* Digital Active - peri.tr_io_output[52]:0 */

    /* P7.5 */
    P7_5_GPIO                       =  0,       /* GPIO controls 'out' */
    P7_5_PERI_TR_IO_OUTPUT141       =  8,       /* Digital Active - peri.tr_io_output[141]:1 */
    P7_5_SCB2_SPI_SELECT2           = 17,       /* Digital Active - scb[2].spi_select2:0 */
    P7_5_PERI_TR_IO_OUTPUT121       = 25,       /* Digital Active - peri.tr_io_output[121]:0 */
    P7_5_PERI_TR_IO_INPUT53         = 26,       /* Digital Active - peri.tr_io_input[53]:0 */
    P7_5_PERI_TR_IO_OUTPUT53        = 27,       /* Digital Active - peri.tr_io_output[53]:0 */

    /* P7.6 */
    P7_6_GPIO                       =  0,       /* GPIO controls 'out' */
    P7_6_PERI_TR_IO_OUTPUT142       =  8,       /* Digital Active - peri.tr_io_output[142]:1 */
    P7_6_SCB2_SPI_SELECT3           = 17,       /* Digital Active - scb[2].spi_select3:0 */
    P7_6_PERI_TR_IO_OUTPUT122       = 25,       /* Digital Active - peri.tr_io_output[122]:0 */
    P7_6_PERI_TR_IO_INPUT54         = 26,       /* Digital Active - peri.tr_io_input[54]:0 */
    P7_6_PERI_TR_IO_OUTPUT54        = 27,       /* Digital Active - peri.tr_io_output[54]:0 */

    /* P7.7 */
    P7_7_GPIO                       =  0,       /* GPIO controls 'out' */
    P7_7_PERI_TR_IO_OUTPUT143       =  8,       /* Digital Active - peri.tr_io_output[143]:1 */
    P7_7_PERI_TR_IO_OUTPUT123       = 25,       /* Digital Active - peri.tr_io_output[123]:0 */
    P7_7_PERI_TR_IO_INPUT55         = 26,       /* Digital Active - peri.tr_io_input[55]:0 */
    P7_7_PERI_TR_IO_OUTPUT55        = 27,       /* Digital Active - peri.tr_io_output[55]:0 */

    /* P8.0 */
    P8_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P8_0_PERI_TR_IO_OUTPUT148       =  9,       /* Digital Active - peri.tr_io_output[148]:2 */
    P8_0_TCPWM0_LINE516             = 10,       /* Digital Active - tcpwm[0].line[516]:0 */
    P8_0_SCB5_UART_CTS              = 16,       /* Digital Active - scb[5].uart_cts:0 */
    P8_0_SCB5_SPI_SELECT0           = 17,       /* Digital Active - scb[5].spi_select0:0 */
    P8_0_SCB5_I2C_SCL_DO            = 19,       /* Digital Active - scb[5].i2c_scl_do:0 */
    P8_0_DEBUG600_TRACE_DATA0       = 21,       /* Digital Active - debug600.trace_data[0]:1 */
    P8_0_PASS_MCPASS_DOUT0          = 24,       /* Digital Active - pass.mcpass_dout[0]:1 */
    P8_0_PERI_TR_IO_OUTPUT124       = 25,       /* Digital Active - peri.tr_io_output[124]:0 */
    P8_0_PERI_TR_IO_INPUT56         = 26,       /* Digital Active - peri.tr_io_input[56]:0 */
    P8_0_PERI_TR_IO_OUTPUT56        = 27,       /* Digital Active - peri.tr_io_output[56]:0 */
    P8_0_DEBUG600_RST_SWJ_TRSTN     = 29,       /* Digital Deep Sleep - debug600.rst_swj_trstn */

    /* P8.1 */
    P8_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P8_1_PERI_TR_IO_OUTPUT149       =  9,       /* Digital Active - peri.tr_io_output[149]:2 */
    P8_1_TCPWM0_LINE_COMPL516       = 10,       /* Digital Active - tcpwm[0].line_compl[516]:0 */
    P8_1_SCB5_UART_RX               = 16,       /* Digital Active - scb[5].uart_rx:0 */
    P8_1_SCB5_SPI_MOSI              = 17,       /* Digital Active - scb[5].spi_mosi:0 */
    P8_1_SCB5_I2C_SCL               = 19,       /* Digital Active - scb[5].i2c_scl:0 */
    P8_1_DEBUG600_TRACE_DATA1       = 21,       /* Digital Active - debug600.trace_data[1]:1 */
    P8_1_PASS_MCPASS_DOUT1          = 24,       /* Digital Active - pass.mcpass_dout[1]:1 */
    P8_1_PERI_TR_IO_OUTPUT125       = 25,       /* Digital Active - peri.tr_io_output[125]:0 */
    P8_1_PERI_TR_IO_INPUT57         = 26,       /* Digital Active - peri.tr_io_input[57]:0 */
    P8_1_PERI_TR_IO_OUTPUT57        = 27,       /* Digital Active - peri.tr_io_output[57]:0 */

    /* P8.2 */
    P8_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P8_2_PERI_TR_IO_OUTPUT150       =  9,       /* Digital Active - peri.tr_io_output[150]:2 */
    P8_2_TCPWM0_LINE517             = 10,       /* Digital Active - tcpwm[0].line[517]:0 */
    P8_2_CANFD0_TTCAN_RX0           = 11,       /* Digital Active - canfd[0].ttcan_rx[0]:0 */
    P8_2_SCB5_UART_RTS              = 16,       /* Digital Active - scb[5].uart_rts:0 */
    P8_2_SCB5_SPI_MISO              = 17,       /* Digital Active - scb[5].spi_miso:0 */
    P8_2_SCB5_I2C_SDA_DO            = 19,       /* Digital Active - scb[5].i2c_sda_do:0 */
    P8_2_DEBUG600_TRACE_DATA2       = 21,       /* Digital Active - debug600.trace_data[2]:1 */
    P8_2_PASS_MCPASS_DOUT2          = 24,       /* Digital Active - pass.mcpass_dout[2]:1 */
    P8_2_PERI_TR_IO_OUTPUT126       = 25,       /* Digital Active - peri.tr_io_output[126]:0 */
    P8_2_PERI_TR_IO_INPUT58         = 26,       /* Digital Active - peri.tr_io_input[58]:0 */
    P8_2_PERI_TR_IO_OUTPUT58        = 27,       /* Digital Active - peri.tr_io_output[58]:0 */
    P8_2_IOSS_DDFT_PIN1             = 31,       /* Digital Deep Sleep - ioss.ddft_pin[1]:1 */

    /* P8.3 */
    P8_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P8_3_PERI_TR_IO_OUTPUT151       =  9,       /* Digital Active - peri.tr_io_output[151]:2 */
    P8_3_TCPWM0_LINE_COMPL517       = 10,       /* Digital Active - tcpwm[0].line_compl[517]:0 */
    P8_3_CANFD0_TTCAN_TX0           = 11,       /* Digital Active - canfd[0].ttcan_tx[0]:0 */
    P8_3_SCB5_UART_TX               = 16,       /* Digital Active - scb[5].uart_tx:0 */
    P8_3_SCB5_SPI_CLK               = 17,       /* Digital Active - scb[5].spi_clk:0 */
    P8_3_SCB5_I2C_SDA               = 19,       /* Digital Active - scb[5].i2c_sda:0 */
    P8_3_DEBUG600_TRACE_DATA3       = 21,       /* Digital Active - debug600.trace_data[3]:1 */
    P8_3_PASS_MCPASS_DOUT3          = 24,       /* Digital Active - pass.mcpass_dout[3]:1 */
    P8_3_PERI_TR_IO_OUTPUT127       = 25,       /* Digital Active - peri.tr_io_output[127]:0 */
    P8_3_PERI_TR_IO_INPUT59         = 26,       /* Digital Active - peri.tr_io_input[59]:0 */
    P8_3_PERI_TR_IO_OUTPUT59        = 27,       /* Digital Active - peri.tr_io_output[59]:0 */
    P8_3_IOSS_DDFT_PIN0             = 31,       /* Digital Deep Sleep - ioss.ddft_pin[0]:1 */

    /* P8.4 */
    P8_4_GPIO                       =  0,       /* GPIO controls 'out' */
    P8_4_SCB5_SPI_SELECT1           = 17,       /* Digital Active - scb[5].spi_select1:0 */
    P8_4_PERI_TR_IO_OUTPUT128       = 25,       /* Digital Active - peri.tr_io_output[128]:0 */
    P8_4_PERI_TR_IO_INPUT60         = 26,       /* Digital Active - peri.tr_io_input[60]:0 */
    P8_4_PERI_TR_IO_OUTPUT60        = 27,       /* Digital Active - peri.tr_io_output[60]:0 */

    /* P8.5 */
    P8_5_GPIO                       =  0,       /* GPIO controls 'out' */
    P8_5_SCB5_SPI_SELECT2           = 17,       /* Digital Active - scb[5].spi_select2:0 */
    P8_5_PERI_TR_IO_OUTPUT129       = 25,       /* Digital Active - peri.tr_io_output[129]:0 */
    P8_5_PERI_TR_IO_INPUT61         = 26,       /* Digital Active - peri.tr_io_input[61]:0 */
    P8_5_PERI_TR_IO_OUTPUT61        = 27,       /* Digital Active - peri.tr_io_output[61]:0 */

    /* P8.6 */
    P8_6_GPIO                       =  0,       /* GPIO controls 'out' */
    P8_6_SCB5_SPI_SELECT3           = 17,       /* Digital Active - scb[5].spi_select3:0 */
    P8_6_PERI_TR_IO_OUTPUT130       = 25,       /* Digital Active - peri.tr_io_output[130]:0 */
    P8_6_PERI_TR_IO_INPUT62         = 26,       /* Digital Active - peri.tr_io_input[62]:0 */
    P8_6_PERI_TR_IO_OUTPUT62        = 27,       /* Digital Active - peri.tr_io_output[62]:0 */

    /* P8.7 */
    P8_7_GPIO                       =  0,       /* GPIO controls 'out' */
    P8_7_SCB5_SPI_SELECT4           = 17,       /* Digital Active - scb[5].spi_select4:0 */
    P8_7_PERI_TR_IO_OUTPUT131       = 25,       /* Digital Active - peri.tr_io_output[131]:0 */
    P8_7_PERI_TR_IO_INPUT63         = 26,       /* Digital Active - peri.tr_io_input[63]:0 */
    P8_7_PERI_TR_IO_OUTPUT63        = 27,       /* Digital Active - peri.tr_io_output[63]:0 */

    /* P9.0 */
    P9_0_GPIO                       =  0,       /* GPIO controls 'out' */
    P9_0_TCPWM0_LINE512             =  8,       /* Digital Active - tcpwm[0].line[512]:0 */
    P9_0_TCPWM0_LINE518             = 10,       /* Digital Active - tcpwm[0].line[518]:0 */
    P9_0_SCB0_SPI_CLK               = 13,       /* Digital Deep Sleep - scb[0].spi_clk:0 */
    P9_0_SCB0_UART_CTS              = 14,       /* Digital Deep Sleep - scb[0].uart_cts:0 */
    P9_0_SCB0_I2C_SCL               = 15,       /* Digital Deep Sleep - scb[0].i2c_scl:0 */
    P9_0_SCB5_SPI_SELECT5           = 17,       /* Digital Active - scb[5].spi_select5:0 */
    P9_0_PERI_TR_IO_OUTPUT132       = 25,       /* Digital Active - peri.tr_io_output[132]:0 */
    P9_0_PERI_TR_IO_INPUT64         = 26,       /* Digital Active - peri.tr_io_input[64]:0 */
    P9_0_PERI_TR_IO_OUTPUT64        = 27,       /* Digital Active - peri.tr_io_output[64]:0 */

    /* P9.1 */
    P9_1_GPIO                       =  0,       /* GPIO controls 'out' */
    P9_1_TCPWM0_LINE_COMPL512       =  8,       /* Digital Active - tcpwm[0].line_compl[512]:0 */
    P9_1_TCPWM0_LINE_COMPL518       = 10,       /* Digital Active - tcpwm[0].line_compl[518]:0 */
    P9_1_SCB0_SPI_SELECT0           = 13,       /* Digital Deep Sleep - scb[0].spi_select0:0 */
    P9_1_SCB0_UART_RTS              = 14,       /* Digital Deep Sleep - scb[0].uart_rts:0 */
    P9_1_SCB0_I2C_SCL_DO            = 15,       /* Digital Deep Sleep - scb[0].i2c_scl_do:0 */
    P9_1_PERI_TR_IO_OUTPUT68        = 25,       /* Digital Active - peri.tr_io_output[68]:0 */
    P9_1_PERI_TR_IO_INPUT0          = 26,       /* Digital Active - peri.tr_io_input[0]:0 */
    P9_1_PERI_TR_IO_OUTPUT0         = 27,       /* Digital Active - peri.tr_io_output[0]:0 */

    /* P9.2 */
    P9_2_GPIO                       =  0,       /* GPIO controls 'out' */
    P9_2_TCPWM0_LINE513             =  8,       /* Digital Active - tcpwm[0].line[513]:0 */
    P9_2_TCPWM0_LINE519             = 10,       /* Digital Active - tcpwm[0].line[519]:0 */
    P9_2_CANFD0_TTCAN_RX0           = 11,       /* Digital Active - canfd[0].ttcan_rx[0]:1 */
    P9_2_SCB0_SPI_MOSI              = 13,       /* Digital Deep Sleep - scb[0].spi_mosi:0 */
    P9_2_SCB0_UART_RX               = 14,       /* Digital Deep Sleep - scb[0].uart_rx:0 */
    P9_2_SCB0_I2C_SDA               = 15,       /* Digital Deep Sleep - scb[0].i2c_sda:0 */
    P9_2_DEBUG600_TRACE_CLOCK       = 21,       /* Digital Active - debug600.trace_clock:1 */
    P9_2_PASS_MCPASS_DCLK           = 24,       /* Digital Active - pass.mcpass_dclk:1 */
    P9_2_PERI_TR_IO_OUTPUT69        = 25,       /* Digital Active - peri.tr_io_output[69]:0 */
    P9_2_PERI_TR_IO_INPUT1          = 26,       /* Digital Active - peri.tr_io_input[1]:0 */
    P9_2_PERI_TR_IO_OUTPUT1         = 27,       /* Digital Active - peri.tr_io_output[1]:0 */

    /* P9.3 */
    P9_3_GPIO                       =  0,       /* GPIO controls 'out' */
    P9_3_TCPWM0_LINE_COMPL513       =  8,       /* Digital Active - tcpwm[0].line_compl[513]:0 */
    P9_3_TCPWM0_LINE_COMPL519       = 10,       /* Digital Active - tcpwm[0].line_compl[519]:0 */
    P9_3_CANFD0_TTCAN_TX0           = 11,       /* Digital Active - canfd[0].ttcan_tx[0]:1 */
    P9_3_SCB0_SPI_MISO              = 13,       /* Digital Deep Sleep - scb[0].spi_miso:0 */
    P9_3_SCB0_UART_TX               = 14,       /* Digital Deep Sleep - scb[0].uart_tx:0 */
    P9_3_SCB0_I2C_SDA_DO            = 15,       /* Digital Deep Sleep - scb[0].i2c_sda_do:0 */
    P9_3_CPUSS_CLK_FM_PUMP          = 20,       /* Digital Active - cpuss.clk_fm_pump */
    P9_3_CPUSS_FAULT0               = 21,       /* Digital Active - cpuss.fault[0]:0 */
    P9_3_PERI_TR_IO_OUTPUT70        = 25,       /* Digital Active - peri.tr_io_output[70]:0 */
    P9_3_PERI_TR_IO_INPUT2          = 26,       /* Digital Active - peri.tr_io_input[2]:0 */
    P9_3_PERI_TR_IO_OUTPUT2         = 27,       /* Digital Active - peri.tr_io_output[2]:0 */

    /* P9.4 */
    P9_4_GPIO                       =  0,       /* GPIO controls 'out' */
    P9_4_TCPWM0_LINE514             =  8,       /* Digital Active - tcpwm[0].line[514]:0 */
    P9_4_TCPWM0_LINE516             = 10,       /* Digital Active - tcpwm[0].line[516]:1 */
    P9_4_SCB0_SPI_SELECT1           = 13,       /* Digital Deep Sleep - scb[0].spi_select1:0 */
    P9_4_PERI_TR_IO_OUTPUT71        = 25,       /* Digital Active - peri.tr_io_output[71]:0 */
    P9_4_PERI_TR_IO_INPUT3          = 26,       /* Digital Active - peri.tr_io_input[3]:0 */
    P9_4_PERI_TR_IO_OUTPUT3         = 27,       /* Digital Active - peri.tr_io_output[3]:0 */

    /* P9.5 */
    P9_5_GPIO                       =  0,       /* GPIO controls 'out' */
    P9_5_TCPWM0_LINE_COMPL514       =  8,       /* Digital Active - tcpwm[0].line_compl[514]:0 */
    P9_5_TCPWM0_LINE_COMPL516       = 10,       /* Digital Active - tcpwm[0].line_compl[516]:1 */
    P9_5_SCB0_SPI_SELECT2           = 13,       /* Digital Deep Sleep - scb[0].spi_select2:0 */
    P9_5_PERI_TR_IO_OUTPUT72        = 25,       /* Digital Active - peri.tr_io_output[72]:0 */
    P9_5_PERI_TR_IO_INPUT4          = 26,       /* Digital Active - peri.tr_io_input[4]:0 */
    P9_5_PERI_TR_IO_OUTPUT4         = 27,       /* Digital Active - peri.tr_io_output[4]:0 */

    /* P9.6 */
    P9_6_GPIO                       =  0,       /* GPIO controls 'out' */
    P9_6_TCPWM0_LINE515             =  8,       /* Digital Active - tcpwm[0].line[515]:0 */
    P9_6_TCPWM0_LINE517             = 10,       /* Digital Active - tcpwm[0].line[517]:1 */
    P9_6_SCB0_SPI_SELECT3           = 13,       /* Digital Deep Sleep - scb[0].spi_select3:0 */
    P9_6_PERI_TR_IO_OUTPUT73        = 25,       /* Digital Active - peri.tr_io_output[73]:0 */
    P9_6_PERI_TR_IO_INPUT5          = 26,       /* Digital Active - peri.tr_io_input[5]:0 */
    P9_6_PERI_TR_IO_OUTPUT5         = 27,       /* Digital Active - peri.tr_io_output[5]:0 */

    /* P9.7 */
    P9_7_GPIO                       =  0,       /* GPIO controls 'out' */
    P9_7_TCPWM0_LINE_COMPL515       =  8,       /* Digital Active - tcpwm[0].line_compl[515]:0 */
    P9_7_TCPWM0_LINE_COMPL517       = 10,       /* Digital Active - tcpwm[0].line_compl[517]:1 */
    P9_7_SCB1_SPI_SELECT6           = 18,       /* Digital Active - scb[1].spi_select6:0 */
    P9_7_PERI_TR_IO_OUTPUT74        = 25,       /* Digital Active - peri.tr_io_output[74]:0 */
    P9_7_PERI_TR_IO_INPUT6          = 26,       /* Digital Active - peri.tr_io_input[6]:0 */
    P9_7_PERI_TR_IO_OUTPUT6         = 27,       /* Digital Active - peri.tr_io_output[6]:0 */

    /* P10.0 */
    P10_0_GPIO                      =  0,       /* GPIO controls 'out' */
    P10_0_SCB1_SPI_SELECT1          = 18,       /* Digital Active - scb[1].spi_select1:0 */
    P10_0_PERI_TR_IO_OUTPUT77       = 25,       /* Digital Active - peri.tr_io_output[77]:0 */
    P10_0_PERI_TR_IO_INPUT9         = 26,       /* Digital Active - peri.tr_io_input[9]:0 */
    P10_0_PERI_TR_IO_OUTPUT9        = 27,       /* Digital Active - peri.tr_io_output[9]:0 */

    /* P10.1 */
    P10_1_GPIO                      =  0,       /* GPIO controls 'out' */
    P10_1_SCB1_SPI_SELECT2          = 18,       /* Digital Active - scb[1].spi_select2:0 */
    P10_1_PERI_TR_IO_OUTPUT78       = 25,       /* Digital Active - peri.tr_io_output[78]:0 */
    P10_1_PERI_TR_IO_INPUT10        = 26,       /* Digital Active - peri.tr_io_input[10]:0 */
    P10_1_PERI_TR_IO_OUTPUT10       = 27,       /* Digital Active - peri.tr_io_output[10]:0 */

    /* P10.2 */
    P10_2_GPIO                      =  0,       /* GPIO controls 'out' */
    P10_2_PERI_TR_IO_OUTPUT152      = 10,       /* Digital Active - peri.tr_io_output[152]:1 */
    P10_2_SCB1_SPI_SELECT3          = 18,       /* Digital Active - scb[1].spi_select3:0 */
    P10_2_PERI_TR_IO_OUTPUT79       = 25,       /* Digital Active - peri.tr_io_output[79]:0 */
    P10_2_PERI_TR_IO_INPUT11        = 26,       /* Digital Active - peri.tr_io_input[11]:0 */
    P10_2_PERI_TR_IO_OUTPUT11       = 27,       /* Digital Active - peri.tr_io_output[11]:0 */

    /* USBDM */
    USBDM_GPIO                      =  0,       /* GPIO controls 'out' */

    /* USBDP */
    USBDP_GPIO                      =  0,       /* GPIO controls 'out' */

    /* P12.0 */
    P12_0_GPIO                      =  0,       /* GPIO controls 'out' */
    P12_0_TCPWM0_LINE256            =  9,       /* Digital Active - tcpwm[0].line[256]:0 */
    P12_0_SCB1_SPI_SELECT7          = 18,       /* Digital Active - scb[1].spi_select7:0 */
    P12_0_PERI_TR_IO_OUTPUT96       = 25,       /* Digital Active - peri.tr_io_output[96]:0 */
    P12_0_PERI_TR_IO_INPUT28        = 26,       /* Digital Active - peri.tr_io_input[28]:0 */
    P12_0_PERI_TR_IO_OUTPUT28       = 27,       /* Digital Active - peri.tr_io_output[28]:0 */

    /* P12.1 */
    P12_1_GPIO                      =  0,       /* GPIO controls 'out' */
    P12_1_TCPWM0_LINE_COMPL256      =  9,       /* Digital Active - tcpwm[0].line_compl[256]:0 */
    P12_1_SCB3_SPI_SELECT7          = 18,       /* Digital Active - scb[3].spi_select7:0 */
    P12_1_PERI_TR_IO_OUTPUT97       = 25,       /* Digital Active - peri.tr_io_output[97]:0 */
    P12_1_PERI_TR_IO_INPUT29        = 26,       /* Digital Active - peri.tr_io_input[29]:0 */
    P12_1_PERI_TR_IO_OUTPUT29       = 27,       /* Digital Active - peri.tr_io_output[29]:0 */

    /* P12.2 */
    P12_2_GPIO                      =  0,       /* GPIO controls 'out' */
    P12_2_TCPWM0_LINE257            =  9,       /* Digital Active - tcpwm[0].line[257]:0 */
    P12_2_SCB3_SPI_SELECT1          = 18,       /* Digital Active - scb[3].spi_select1:0 */
    P12_2_USB_DDFT_GPIO_O0          = 24,       /* Digital Active - usb.ddft_gpio_o[0] */
    P12_2_PERI_TR_IO_OUTPUT110      = 25,       /* Digital Active - peri.tr_io_output[110]:0 */
    P12_2_PERI_TR_IO_INPUT42        = 26,       /* Digital Active - peri.tr_io_input[42]:0 */
    P12_2_PERI_TR_IO_OUTPUT42       = 27,       /* Digital Active - peri.tr_io_output[42]:0 */

    /* P12.3 */
    P12_3_GPIO                      =  0,       /* GPIO controls 'out' */
    P12_3_TCPWM0_LINE_COMPL257      =  9,       /* Digital Active - tcpwm[0].line_compl[257]:0 */
    P12_3_SCB3_SPI_SELECT2          = 18,       /* Digital Active - scb[3].spi_select2:0 */
    P12_3_USB_DDFT_GPIO_O1          = 24,       /* Digital Active - usb.ddft_gpio_o[1] */
    P12_3_PERI_TR_IO_OUTPUT111      = 25,       /* Digital Active - peri.tr_io_output[111]:0 */
    P12_3_PERI_TR_IO_INPUT43        = 26,       /* Digital Active - peri.tr_io_input[43]:0 */
    P12_3_PERI_TR_IO_OUTPUT43       = 27,       /* Digital Active - peri.tr_io_output[43]:0 */

    /* P12.4 */
    P12_4_GPIO                      =  0,       /* GPIO controls 'out' */
    P12_4_TCPWM0_LINE258            =  9,       /* Digital Active - tcpwm[0].line[258]:0 */
    P12_4_SCB3_SPI_SELECT3          = 18,       /* Digital Active - scb[3].spi_select3:0 */
    P12_4_USB_DDFT_GPIO_O2          = 24,       /* Digital Active - usb.ddft_gpio_o[2] */
    P12_4_PERI_TR_IO_OUTPUT112      = 25,       /* Digital Active - peri.tr_io_output[112]:0 */
    P12_4_PERI_TR_IO_INPUT44        = 26,       /* Digital Active - peri.tr_io_input[44]:0 */
    P12_4_PERI_TR_IO_OUTPUT44       = 27,       /* Digital Active - peri.tr_io_output[44]:0 */

    /* P12.5 */
    P12_5_GPIO                      =  0,       /* GPIO controls 'out' */
    P12_5_TCPWM0_LINE_COMPL258      =  9,       /* Digital Active - tcpwm[0].line_compl[258]:0 */
    P12_5_SCB3_SPI_SELECT4          = 18,       /* Digital Active - scb[3].spi_select4:0 */
    P12_5_USB_DDFT_GPIO_O3          = 24,       /* Digital Active - usb.ddft_gpio_o[3] */
    P12_5_PERI_TR_IO_OUTPUT113      = 25,       /* Digital Active - peri.tr_io_output[113]:0 */
    P12_5_PERI_TR_IO_INPUT45        = 26,       /* Digital Active - peri.tr_io_input[45]:0 */
    P12_5_PERI_TR_IO_OUTPUT45       = 27,       /* Digital Active - peri.tr_io_output[45]:0 */

    /* P12.6 */
    P12_6_GPIO                      =  0,       /* GPIO controls 'out' */
    P12_6_TCPWM0_LINE259            =  9,       /* Digital Active - tcpwm[0].line[259]:0 */
    P12_6_SCB3_SPI_SELECT5          = 18,       /* Digital Active - scb[3].spi_select5:0 */
    P12_6_USB_DDFT_GPIO_O4          = 24,       /* Digital Active - usb.ddft_gpio_o[4] */
    P12_6_PERI_TR_IO_OUTPUT114      = 25,       /* Digital Active - peri.tr_io_output[114]:0 */
    P12_6_PERI_TR_IO_INPUT46        = 26,       /* Digital Active - peri.tr_io_input[46]:0 */
    P12_6_PERI_TR_IO_OUTPUT46       = 27,       /* Digital Active - peri.tr_io_output[46]:0 */

    /* P12.7 */
    P12_7_GPIO                      =  0,       /* GPIO controls 'out' */
    P12_7_TCPWM0_LINE_COMPL259      =  9,       /* Digital Active - tcpwm[0].line_compl[259]:0 */
    P12_7_SCB3_SPI_SELECT6          = 18,       /* Digital Active - scb[3].spi_select6:0 */
    P12_7_USB_DDFT_GPIO_O5          = 24,       /* Digital Active - usb.ddft_gpio_o[5] */
    P12_7_PERI_TR_IO_OUTPUT115      = 25,       /* Digital Active - peri.tr_io_output[115]:0 */
    P12_7_PERI_TR_IO_INPUT47        = 26,       /* Digital Active - peri.tr_io_input[47]:0 */
    P12_7_PERI_TR_IO_OUTPUT47       = 27,       /* Digital Active - peri.tr_io_output[47]:0 */

    /* P13.0 */
    P13_0_GPIO                      =  0,       /* GPIO controls 'out' */
    P13_0_SCB5_SPI_SELECT6          = 17,       /* Digital Active - scb[5].spi_select6:0 */
    P13_0_PERI_TR_IO_OUTPUT133      = 25,       /* Digital Active - peri.tr_io_output[133]:0 */
    P13_0_PERI_TR_IO_INPUT65        = 26,       /* Digital Active - peri.tr_io_input[65]:0 */
    P13_0_PERI_TR_IO_OUTPUT65       = 27,       /* Digital Active - peri.tr_io_output[65]:0 */

    /* P13.1 */
    P13_1_GPIO                      =  0,       /* GPIO controls 'out' */
    P13_1_SCB5_SPI_SELECT7          = 17,       /* Digital Active - scb[5].spi_select7:0 */
    P13_1_PERI_TR_IO_OUTPUT134      = 25,       /* Digital Active - peri.tr_io_output[134]:0 */
    P13_1_PERI_TR_IO_INPUT66        = 26,       /* Digital Active - peri.tr_io_input[66]:0 */
    P13_1_PERI_TR_IO_OUTPUT66       = 27,       /* Digital Active - peri.tr_io_output[66]:0 */

    /* P13.2 */
    P13_2_GPIO                      =  0,       /* GPIO controls 'out' */
    P13_2_PERI_TR_IO_OUTPUT135      = 25,       /* Digital Active - peri.tr_io_output[135]:0 */
    P13_2_PERI_TR_IO_INPUT67        = 26,       /* Digital Active - peri.tr_io_input[67]:0 */
    P13_2_PERI_TR_IO_OUTPUT67       = 27        /* Digital Active - peri.tr_io_output[67]:0 */
} en_hsiom_sel_t;

#endif /* _GPIO_PSC3M6_E_LQFP_100_H_ */


/* [] END OF FILE */
