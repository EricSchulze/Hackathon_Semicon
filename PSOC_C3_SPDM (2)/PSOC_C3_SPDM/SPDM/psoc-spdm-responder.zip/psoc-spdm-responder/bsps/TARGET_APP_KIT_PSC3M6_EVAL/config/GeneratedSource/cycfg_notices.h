/*******************************************************************************
 * File Name: cycfg_notices.h
 *
 * Description:
 * Contains warnings and errors that occurred while generating code for the
 * design.
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.90.0
 * device-db 4.39.0.10988
 * mtb-dsl-psc3m6 1.0.0.335
 *
 *******************************************************************************
 * Copyright 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#if !defined(CYCFG_NOTICES_H)
#define CYCFG_NOTICES_H

#if defined(__cplusplus)
extern "C" {
#endif /* defined(__cplusplus) */

#if defined(CY_SUPPORTS_DEVICE_VALIDATION)
#if !defined(PSC3M6GES3AHQ1)
#error "Unexpected MPN; expected DEVICE:=PSC3M6GES3AHQ1. There may be an inconsistency between the *.modus file and the makefile target configuration device sets."
#endif /* !defined(PSC3M6GES3AHQ1) */
#endif /* defined(CY_SUPPORTS_DEVICE_VALIDATION) */

#if defined(CY_SUPPORTS_COMPLETE_DEVICE_VALIDATION)
#if !defined(PSC3M6GES3AHQ1)
#error "Unexpected MPN; expected DEVICE:=PSC3M6GES3AHQ1. There may be an inconsistency between the *.modus file and the makefile target configuration device sets."
#endif /* !defined(PSC3M6GES3AHQ1) */
#endif /* defined(CY_SUPPORTS_COMPLETE_DEVICE_VALIDATION) */

#if defined(__cplusplus)
}
#endif /* defined(__cplusplus) */

#endif /* CYCFG_NOTICES_H */
