# SPDM Responder &mdash; architecture and security overview

This document establishes the **mental model** of the SPDM Responder: what the
device is, who it talks to, what is trusted, what is guaranteed, and what is
deliberately out of scope. Read this first to understand the design and its
security posture.

For file-level detail &mdash; how each source file is built, wired, and
initialized &mdash; see [implementation.md](implementation.md). For how to
create, provision, build, and program the application, see the
[Operation](../README.md#operation) section of the README.


## 1. Overview

The device is an **SPDM Responder** on the PSOC&trade; Control C3 MCU. A remote
host (**SPDM Requester**) can ask it to prove three things over an I2C link:

- **Identity / authenticity** &mdash; who the device is, proven with a
  provisioned device key and certificate chain.
- **Measurements / state** &mdash; what firmware/configuration state it is in,
  reported as signed measurements.
- **Secure session** &mdash; an encrypted, authenticated channel for application
  traffic.

The single most important design idea: **the SPDM protocol engine
([libspdm](https://github.com/DMTF/libspdm)) runs in the non-secure world, while
the device private key and every cryptographic operation that touches it stay in
the secure world**, reached only through Non-Secure-Callable (NSC) veneers. This
is the TF-M model (protocol in the NSPE, keys and crypto in the SPE) and it is
the boundary the rest of this document reasons about.


## 2. Actors and system context

```mermaid
flowchart LR
    Host["Host SPDM Requester<br/>(verifier, holds trusted root)"]
    subgraph Device["PSOC Control C3 device"]
        subgraph NS["Non-secure world (NSPE)"]
            LT["libspdm + transport"]
        end
        subgraph S["Secure world (SPE)"]
            CR["PSA crypto + device-key signing"]
            PAS["PAS (read-only)<br/>device key + cert chain<br/>(provisioned beforehand)"]
        end
    end

    Host <-->|SPDM over MCTP / DFU 0x80 / I2C| LT
    LT <-->|NSC veneers| CR
    CR -->|reads key + chain| PAS
```

At runtime the system context is just two actors &mdash; the **Host Requester**
and the **Device** &mdash; talking SPDM over the wire:

- **Host SPDM Requester** &mdash; the *verifier*. It initiates every exchange,
  anchors the served certificate chain to its own trusted root, and checks all
  signatures. The device is never the trust anchor.
- **The device** &mdash; the *responder*, split into a non-secure world (this
  application's libspdm engine and I2C transport) and a secure world (device
  key, PSA crypto, and the read-only Provisioning Asset Store).

> **Provisioned beforehand (out of scope for this repo).** Before the responder
> can attest, the device's SPDM identity assets (device key + cert chain) must be
> in the PAS, and on **KIT_PSC3M5_EVK** the OEM memory-map (MPC) policy must also
> applied. (On **KIT_PSC3M6_EVAL** and **KIT_PSC3M8_EVK** the secure/non-secure
> map comes from the Device Configurator, so no OEM policy provisioning is needed
> &mdash; see [section 7.1](#71-provisioning-phases).) These are separate steps
> using different tooling; see
> [section 7](#7-certificate--identity-provisioning-model) for how the responder
> consumes them and how the pieces relate.


## 3. Threat model and trust boundaries

### 3.1 Trusted vs untrusted

| Component | Trust | Rationale |
|-----------|-------|-----------|
| Secure world (SPE): device key, PSA crypto, PAS accessor | **Trusted** | Isolated by TrustZone&reg; SAU + PPC + flash MPC; holds the only long-term secret. |
| Provisioning process and the assets it writes to PAS | **Trusted (assumed)** | Establishes device identity; a mis-provisioned device has no valid identity to attest. |
| Host Requester | **Trusted as the verifier** | It decides what roots to trust and validates every signature; a malicious host can only fail to trust a genuine device. |
| Non-secure world (NSPE): libspdm, transport, router | **Untrusted for key confidentiality** | Large third-party/protocol code surface; treated as potentially compromised when reasoning about the device key. |
| I2C wire / carrier | **Untrusted** | Passive/active network attacker assumed. |

### 3.2 Attacker capabilities considered

- Observe and tamper with I2C traffic.
- Fully compromise the **non-secure** application (arbitrary code execution in
  the NSPE), and attempt to extract the device key or forge a signed attestation
  through the NSC boundary.

### 3.3 What the boundary buys

```mermaid
flowchart TD
    subgraph NSPE["Non-secure world (untrusted)"]
        L["libspdm engine"]
        T["I2C / DFU transport"]
        C["NS cryptlib (HMAC/HKDF compose)"]
    end
    subgraph SPE["Secure world (trusted)"]
        K["Device private key<br/>(HUK-wrapped, PAS slot 0)"]
        P["PSA crypto + TRNG"]
        M["Measurement provider + DMTF framing"]
        CC["Cert chain (PAS slot 1, served verbatim)"]
    end
    L -->|generic PSA-style veneers<br/>pointer-checked| P
    L -->|sign request| K
    L -->|measurement request| M
    L -->|read chain| CC
```

A full compromise of the non-secure world **cannot**:

- read or export the long-term **device private key** (it is HUK-wrapped in PAS,
  unwrapped only transiently inside a single SPE call, and destroyed);
- forge a **device signature** (signing happens in the SPE over data the SPE
  hashes);
- forge the **measurement record or summary hash** (assembled and hashed in the
  SPE; the NSPE only frames the request);
- abuse a veneer with an out-of-bounds pointer (every non-secure pointer is
  validated with `cmse_check_address_range()` before use).

It **can** still observe or disrupt traffic, and it does transit *transient
session secrets* (see [section 6, Limitations](#6-limitations-and-non-goals)).


## 4. Security properties and assumptions

### 4.1 Properties (guarantees)

1. **Device-key confidentiality.** The private device identity scalar never
   materializes in non-secure memory. It is unwrapped, imported, used for one
   signature, and destroyed entirely within the SPE.
2. **Attestation integrity.** `CHALLENGE_AUTH`, `KEY_EXCHANGE_RSP`, and the
   measurement summary hash are signed over content produced in the SPE, so a
   compromised NSPE cannot substitute a forged identity or state.
3. **Measurement integrity.** DMTF record assembly, subset (`TCB` / `all`)
   selection, and summary hashing execute in the SPE; the NSPE holds no measured
   state and performs no measurement hashing.
4. **Boundary input validation.** Every NSC veneer validates each caller-supplied
   pointer (`cmse_check_address_range()`) and refuses the call on failure; AEAD
   parameter structs are copied into secure memory before use (TOCTOU
   hardening).
5. **Fail-closed AEAD.** Session-record decryption uses a constant-time,
   fail-closed tag verification.

### 4.2 Assumptions (must hold for the properties above)

1. **Provisioning is correct and trusted.** The device key (PAS slot 0) and the
   host-assembled certificate chain (PAS slot 1) were injected by the trusted
   provisioning process, and the OEM policy maps the PAS/secure regions as
   secure via the MPC.
2. **The host anchors trust externally.** The device serves its chain verbatim
   and is not the trust anchor; the host validates that chain against a root it
   obtained out-of-band.
3. **TrustZone isolation is effective.** SAU, PPC, and the flash MPC correctly
   confine the SPE, and the HUK is available only to the SPE.
4. **libspdm context-pointer contract.** libspdm passes the same context pointer
   to a streaming operation's setup/update/finish calls (the NS cryptlib relies
   on this to map to a secure handle).
5. **Transient session secrets in NS SRAM are acceptable.** libspdm's
   secured-message context and the raw session/ephemeral key bytes it passes for
   HKDF/AEAD live in non-secure SRAM by design (see limitations).


## 5. Capabilities and configuration at a glance

| Area | Value |
|------|-------|
| SPDM capabilities | `CERT`, `CHAL`, `MEAS` (signed), `KEY_EX`, `ENCRYPT`, `MAC`, `CHUNK` |
| Disabled capabilities | `MUT_AUTH` (no peer verification), `PSK`, `HBEAT` |
| SPDM version | up to 1.4 (all profiles), selected by `SPDM_PROFILE` |
| Asymmetric | ECDSA / ECDHE **P-256** (`P1`), **P-384** (`P2`) or **P-521** (`P3`); or **ML-DSA-87** / **ML-KEM-1024** (`P4`, CNSA 2.0 PQC) |
| Hash | **SHA-256** (`P1`), **SHA-384** (`P2`, `P4`) or **SHA-512** (`P3`), with HMAC/HKDF over it |
| AEAD | **AES-256-GCM** (all profiles) |
| Certificate handling | host-assembled chain served verbatim; `CERT_PARSE_SUPPORT=0` (no on-device X.509 parser) |
| Concurrent sessions | **1** (`MAX_SESSION_COUNT=1`) |
| Transport | MCTP message over DFU user command `0x80` on I2C; 1-byte MCTP prefix; no SMBus/PEC/4-byte MCTP header |
| Large messages | split by SPDM `CHUNK_CAP` |
| NSC ABI version | `0x0006` |

> The negotiated cipher suite is intentionally minimal (one asym, one hash, one
> AEAD) to keep the secure crypto footprint small and the boundary narrow. The
> suite is fixed at build time by `SPDM_PROFILE`; there is no runtime
> negotiation between the `P1`&ndash;`P4` profiles.

The implemented profiles &mdash; `P1` (ECDSA/ECDHE P-256, SHA-256), `P2`
(P-384, SHA-384), `P3` (P-521, SHA-512) and `P4` (ML-DSA-87 / ML-KEM-1024,
SHA-384) &mdash; are the ones Infineon
validates, but a profile is just a self-consistent build-time selection of one
signature, one transcript hash, one key exchange and one AEAD (see the
[custom-profile authoring guide](implementation.md)). Whether a given profile
also qualifies as **CNSA 2.0** is a separate, stricter question: CNSA 2.0 is a
property of the *whole combination*, not of any single algorithm. A profile is
CNSA 2.0 only if every component clears the suite's 192-bit security floor
together &mdash; ML-DSA-87 for signatures, ML-KEM-1024 for key establishment,
SHA-384 for hashing, and AES-256-GCM for the session. A custom profile that, for
example, pairs ML-DSA-87 with SHA-256 is a perfectly valid SPDM build, but it is
**not** CNSA 2.0: the SHA-256 transcript hash sits below the floor, so the
combination fails the suite even though its signature primitive is post-quantum.
Only `P4` makes the CNSA 2.0 claim.


## 6. Limitations and non-goals

These are deliberate scoping decisions, not defects.

- **Measured values are placeholders.** The immutable-ROM and mutable-firmware
  digests are hashes of fixed pre-image strings, the secure version number is a
  fixed counter, and the informational block is a build string. Only the
  *values* are stand-ins; the DMTF framing, subset selection, and
  negotiated-algorithm hashing are final. Replacing them is confined to
  `core/spdm_meas.c`.
- **Transient session secrets transit non-secure SRAM.** The libspdm cryptlib
  contract passes raw session/ephemeral key bytes for HKDF and AEAD, and the
  secured-message context lives in the NSPE. Moving crypto into the SPE protects
  the *long-term device key* and the crypto implementation, **not** every
  ephemeral session secret.
- **Single concurrent session.** Only one secure session at a time.
- **No mutual authentication.** `MUT_AUTH_CAP=0`; the responder never verifies a
  peer and never parses its own chain.
- **Not a trust anchor.** The device performs no X.509 validation; the host does
  all chain validation against its own root.
- **Not full MCTP.** The 4-byte MCTP packet header, SMBus framing, and PEC are
  not implemented (the carrier is a DFU/I2C tunnel, not a full MCTP stack).
- **No PSK or heartbeat.** Pre-shared-key sessions and in-session liveness
  heartbeats are disabled.


## 7. Certificate & identity provisioning model

The device's SPDM identity assets are established by a **separate provisioning
infrastructure** &mdash; a dedicated provisioning application and its host tool
&mdash; which is documented in detail there. This section explains only *what
this responder consumes* and *how the pieces relate*; for the provisioning
procedure, key-generation, CSR/CA flow, and the Provisioning Asset Store (PAS)
internals, refer to that provisioning infrastructure's own documentation.

### 7.1 Provisioning phases

The assets this responder relies on are put in place by two provisioning steps
that run **before** attestation, with the device booting a different firmware
image at each stage:

1. **Asset provisioning** &mdash; the device runs a **separate provisioning
   device app** (out of scope for this repo), driven by its companion host
   provisioning tool. The app **generates the device key pair on-device** (the
   private key never leaves the device) and stores it in the PAS; the host tool
   then provisions the resulting certificate chain into the PAS.
2. **OEM policy provisioning (KIT_PSC3M5_EVK only)** &mdash; the OEM memory-map
   (MPC) policy for the SPDM application is applied, locking in the
   secure/non-secure split. This is done with `edgeprotecttools` (from the Edge
   Protect Security Suite) via the scripts in this repository; see the
   [README Operation section](../README.md#operation). On **KIT_PSC3M6_EVAL**
   and **KIT_PSC3M8_EVK** this step does not apply: the SAU/MPC/PPC map is owned
   by the Device Configurator (`design.modus`) and applied in `cybsp_init()`, so
   no OEM policy provisioning is required.

Once both steps are complete, the device runs the **SPDM Responder app** (this
repository) and the companion SPDM Requester can issue SPDM commands to attest
it &mdash; that attestation is the use case this repository serves, not a
provisioning phase.

### 7.2 Asset flow

```mermaid
flowchart LR
    subgraph ProvTime["Provisioning time (separate infrastructure)"]
        KG["Device key-pair generated on-device;<br/>private scalar HUK-wrapped"]
        CA["Host assembles SPDM cert_chain<br/>(RootHash + root + intermediates + leaf)"]
    end
    subgraph PAS["Device PAS (secure flash)"]
        S0["Slot 0: HUK-wrapped device private key"]
        S1["Slot 1: host-assembled cert chain (verbatim)"]
    end
    subgraph Runtime["Attestation time (this responder)"]
        GD["GET_DIGESTS -> negotiated hash over served chain"]
        GC["GET_CERTIFICATE -> chain returned verbatim"]
        CH["CHALLENGE_AUTH / KEY_EXCHANGE_RSP -> signed by SPE"]
    end
    HostRoot["Host's out-of-band trusted root"]

    KG --> S0
    CA --> S1
    S1 --> GD
    S1 --> GC
    S0 --> CH
    GC --> HostRoot
    CH --> HostRoot
```

Key relationships:

- **Device key (PAS slot 0)** &mdash; the private identity scalar, stored
  HUK-wrapped. It is unwrapped only inside the SPE for a single signature. It is
  what makes `CHALLENGE_AUTH` / `KEY_EXCHANGE_RSP` signatures verifiable against
  the leaf certificate's public key.
- **Certificate chain (PAS slot 1)** &mdash; a fully-formatted SPDM `cert_chain`
  assembled **off-device** by the provisioning host and written verbatim. The
  device serves it for `GET_CERTIFICATE` and hashes it for `GET_DIGESTS`; it
  never parses it. Root/intermediate rotation is a re-provisioning operation, not
  a firmware change.
- **The host closes the loop.** Because the device is not a trust anchor, the
  host verifies the served chain up to a root it trusts independently, then
  verifies the device signature against the chain's leaf key.


## 8. Responder runtime lifecycle

```mermaid
stateDiagram-v2
    [*] --> Boot
    Boot --> Idle: SPE bring-up (SAU/PPC/crypto/PAS) then NS init<br/>(DFU + router + responder context + I2C)
    Idle --> Serving: DFU 0x80 transaction received
    Serving --> Idle: response returned (LED heartbeat while idle)
    Idle --> InSession: KEY_EXCHANGE / FINISH
    InSession --> InSession: DFU 0x80 transaction<br/>encrypted SPDM request (e.g. GET_MEASUREMENTS) or application record (AES-256-GCM)
    InSession --> Idle: END_SESSION
    note right of InSession
        Only one session at a time
        (MAX_SESSION_COUNT = 1)
    end note
```

The device boots into an idle service loop that toggles the user LED as a
heartbeat and waits for host commands. Identity and measurement requests are
answered statelessly; a `KEY_EXCHANGE`/`FINISH` pair moves it into the single
secure session, and `END_SESSION` returns it to idle. Every request &mdash;
unauthenticated attestation *and* in-session traffic &mdash; arrives as the same
DFU `0x80` transaction and is dispatched by the one router loop. Inside the
session the Requester may keep issuing regular SPDM requests (for example
`GET_MEASUREMENTS`, `GET_CERTIFICATE` or `KEY_UPDATE`) as well as application
records; libspdm decrypts and authenticates the AES-256-GCM payload, routes SPDM
requests to its built-in responder handlers just as it does outside a session,
and only passes messages flagged as application data to the registered echo
handler &mdash; then re-encrypts the reply.


## 9. Measurement composition

```mermaid
flowchart TD
    subgraph Blocks["DMTF measurement blocks (assembled in SPE)"]
        B1["Block 1: immutable-ROM digest (TCB)"]
        B2["Block 2: mutable-firmware digest (TCB)"]
        B3["Block 3: secure version number (raw)"]
        B4["Block 4: informational build string (raw)"]
    end
    TCB["TCB summary hash = H(block1 + block2)"]
    ALL["all summary hash = H(block1..block4)"]

    B1 --> TCB
    B2 --> TCB
    B1 --> ALL
    B2 --> ALL
    B3 --> ALL
    B4 --> ALL
```

The `measurement_summary_hash` embedded in `CHALLENGE_AUTH` and
`KEY_EXCHANGE_RSP` is computed over one of these two subsets in the secure world,
using the negotiated base hash algorithm. (Measured *values* are placeholders
today &mdash; see [section 6](#6-limitations-and-non-goals).)


## 10. Design decisions register

| # | Decision | Rationale | Notable rejected alternative |
|---|----------|-----------|------------------------------|
| D1 | libspdm runs in the **non-secure** world | TCB minimization + TF-M alignment; the SPE keeps only the key and crypto | libspdm in the SPE (larger secure attack surface, secure SRAM pressure) |
| D2 | NSC boundary exposes **generic PSA-shaped** primitives (hash / AEAD / RNG) | A later TF-M port becomes a mechanical `nsc_psa_*` &rarr; `psa_*` rename | SPDM-specific veneers (would not map cleanly to PSA) |
| D3 | **HMAC and HKDF composed in the NSPE** over hash veneers | PSA MAC API has no clone, but the SPDM key schedule duplicates a partial HMAC context; the PSA *hash* API does clone | MAC veneer in the SPE (no clone primitive available) |
| D4 | Certificate chain **host-assembled, served verbatim** (`CERT_PARSE_SUPPORT=0`) | No on-device X.509 parser needed; device is not the trust anchor | On-device assembly / embedded root DER / runtime codegen |
| D5 | **All device-key crypto in the SPE**, sign by slot not by parsed leaf key | Keeps the long-term key confidential and avoids on-device cert parsing | Signing from a key parsed out of the served chain |
| D6 | Transport = **MCTP over a DFU `0x80` I2C tunnel**, 1-byte prefix only | Reuses the existing DFU/I2C carrier; full MCTP needs a real MCTP controller | Full MCTP (4-byte header + SMBus + PEC) |
| D7 | Cipher suite fixed at build time by a **profile** (`SPDM_PROFILE`): `P1` P-256/SHA-256, `P2` P-384/SHA-384, `P3` P-521/SHA-512 or `P4` ML-DSA-87/ML-KEM-1024/SHA-384, single session, AES-256-GCM | Small secure footprint, narrow boundary; one profile per image avoids dual-crypto SRAM cost | Runtime multi-suite negotiation / multiple sessions (more SRAM, wider surface) |


## 11. Glossary

| Term | Meaning |
|------|---------|
| **SPDM** | Security Protocol and Data Model (DMTF DSP0274). |
| **Requester / Responder** | SPDM roles; the host requests, this device responds. |
| **Attestation** | Identity + measurements: proving who the device is and what state it is in. |
| **Authentication** | The identity exchange (`GET_DIGESTS` / `GET_CERTIFICATE` / `CHALLENGE`). |
| **SPE / NSPE** | Secure / Non-Secure Processing Environment (TrustZone worlds). |
| **TrustZone&reg;** | Arm hardware isolation between secure and non-secure worlds. |
| **NSC** | Non-Secure-Callable: the gateway veneers the NSPE uses to enter the SPE. |
| **CMSE** | Cortex-M Security Extensions (the `cmse_*` intrinsics, e.g. pointer checks). |
| **SAU / PPC / MPC** | Security Attribution Unit / Peripheral Protection Controller / Memory Protection Controller. |
| **PAS** | Provisioning Asset Store: the secure read-only flash region holding the device key and cert chain. |
| **HUK** | Hardware Unique Key, used to wrap the device key; available only to the SPE. |
| **PSA** | Platform Security Architecture crypto API (the SPE crypto interface). |
| **libspdm** | The DMTF reference SPDM protocol engine (pinned to 4.0.0-rc). |
| **MCTP** | Management Component Transport Protocol; here only its 1-byte message-type prefix is used. |
| **DFU** | Device Firmware Update middleware, repurposed as the I2C command carrier (opcode `0x80`). |
| **DMTF** | Distributed Management Task Force (the SPDM standards body). |
| **TCB** | Trusted Computing Base; here the measurement subset covering the ROM and firmware digests. |
| **TRNG / DRBG** | True / Deterministic Random Bit Generator (entropy sources in the SPE). |
| **AEAD** | Authenticated Encryption with Associated Data (AES-256-GCM here). |
| **KDF / HKDF** | Key Derivation Function / HMAC-based KDF (RFC 5869). |
| **ECDHE** | Ephemeral Elliptic-Curve Diffie-Hellman (session key agreement; P-256/P-384/P-521 per profile). |
| **ML-DSA / ML-KEM** | CNSA 2.0 post-quantum signature (FIPS 204, ML-DSA-87) and key encapsulation (FIPS 203, ML-KEM-1024). |
| **CNSA 2.0** | NSA Commercial National Security Algorithm Suite 2.0 (the post-quantum profile). |
| **SVN** | Secure Version Number (an anti-rollback measurement datum). |
