# SPDM Responder &mdash; implementation

This document describes how the application is built and initialized today: the
placement of libspdm and the transport in the non-secure world, the crypto
backend and signing seam in the secure world (no device X.509; the host-assembled
certificate chain is served verbatim), the build infrastructure, and the memory
split. It reflects the current implementation and is kept up to date as the code
grows.

For the conceptual and security view &mdash; what the device is, threat model,
trust boundaries, security properties and assumptions, limitations, and
design-decision rationale &mdash; see
[architecture_and_security.md](architecture_and_security.md).

For how to create, provision, build, and program the application, see the
[Operation](../README.md#operation) section of the README.


## 1. Folder structure

The application is one ModusToolbox&trade; **application** made of two projects
(secure and non-secure) plus shared ABI headers and the vendored libspdm
submodule. The three parts are shown separately below.

### Application root and shared files

```
psoc-spdm-responder/                     # MTB APPLICATION (this repo root)
├── Makefile                             # MTB_TYPE=APPLICATION, lists the 2 projects
├── common.mk                            # TARGET, TOOLCHAIN, SPDM_PROFILE, secure SRAM/flash split
├── common_app.mk                        # tool paths (CY_TOOLS)
├── .cyignore  .gitignore
├── profiles/                            # build-time cipher profiles (one folder each)
│   ├── profile_schema.h                 # selector-token vocabulary (shared by all profiles)
│   ├── profile_derive.h                 # expands selectors into SPDM_HAVE_* + ECDSA geometry
│   ├── profile_check.h                  # compile-time validation (#error on bad selection)
│   ├── P1/                              # ECDSA/ECDHE P-256, SHA-256, SPDM up to 1.4
│   ├── P2/                              # ECDSA/ECDHE P-384, SHA-384, SPDM up to 1.4
│   ├── P3/                              # ECDSA/ECDHE P-521, SHA-512, SPDM up to 1.4
│   ├── P4/                              # ML-DSA-87 / ML-KEM-1024, SHA-384, SPDM 1.4 (CNSA 2.0)
│   └── _template/                       # starting point for a custom profile
├── platforms/                          # per-device detect_platform.mk (profile allow-list, memory split)
├── ns_policy/
│   └── policy_oem_provisioning.json     # OEM policy: secure/NS MPC split (+ PAS window)
├── templates/TARGET_KIT_PSC3M5_EVK/     # custom BSP overlay
│   └── config/design.modus              # device configurator overlay (pins/clocks/peripherals)
├── shared/                              # NSC ABI headers shared by both projects
│   ├── nsc.h                            # baseline ABI-version entry point
│   ├── nsc_psa.h                        # PSA crypto/EC veneer ABI
│   ├── nsc_sign.h                       # device-sign veneer ABI
│   ├── nsc_cert.h                       # cert-chain read veneer ABI
│   └── nsc_meas.h                       # measurement veneer ABI
├── third_party/
│   └── libspdm/                         # GIT SUBMODULE — pinned libspdm 4.0.0-rc (pristine)
└── docs/                                # this documentation
```

### Secure project &mdash; `proj_cm33_s` (SPE)

Holds the device key, the PSA crypto, the PAS accessor, and the NSC veneers.

```
proj_cm33_s/                             # ===== SECURE (SPE) =====
├── Makefile                             # VCORE_ATTRS=SECURE, emits nsc_veneer.o
├── main.c                               # SPE bring-up (SAU + PPC) + crypto init + NS launch
├── platform/                            # secure-core platform partitioning
│   └── ppc_config.c/.h                  # PPC partitioning (places UART in the NSPE)
├── config/                              # tailored mbedTLS + PSA capability config
│   ├── spdm_mbedtls_config.h            # MBEDTLS_CONFIG_FILE (full replacement)
│   └── spdm_psa_crypto_config.h         # PSA_WANT_* for the SPDM cipher suite
├── core/                                # secure services (protocol-agnostic)
│   ├── spdm_crypto.c/.h                 # secure PSA crypto service (hash/AEAD/RNG + device sign + key agreement; wolfCrypt ML-DSA-87/ML-KEM-1024)
│   ├── spdm_meas.c/.h                   # secure measurement data provider (protocol-agnostic values)
│   └── key_slot.h                       # read-side key-slot payload layout helper
├── pas/                                 # read-only Provisioning Asset Store accessor
│   ├── pas.c/.h                         # PAS slot query/read
│   └── pas_config.h                     # PAS geometry (base, rows, slot layout)
├── nsc/                                 # NSC veneers (cmse_nonsecure_entry, pointer-validated)
│   ├── nsc.c                            # baseline ABI-version veneer
│   ├── nsc_psa.c                        # PSA crypto/EC veneers (hash/AEAD/RNG/key agreement; ML-KEM encapsulate)
│   ├── nsc_sign.c                       # device-sign veneer (signs from PAS key slot)
│   ├── nsc_cert.c                       # cert-chain read veneer
│   └── nsc_meas.c                       # measurement sourcing veneers (DMTF framing + summary hash)
└── deps/                                # secure-side library dependencies
    ├── ifx-mbedtls.mtb
    └── cy-mbedtls-acceleration.mtb
```

### Non-secure project &mdash; `proj_cm33_ns` (NSPE)

Holds libspdm, the cryptlib/measurement HAL over the veneers, the transport, and
the router.

```
proj_cm33_ns/                            # ===== NON-SECURE (NSPE) =====
├── Makefile                             # VCORE_ATTRS=NON_SECURE, PREBUILD libspdm, links .a's + nsc_veneer.o
├── main.c                               # board + logging + DFU/I2C carrier bring-up, then SPDM router loop
├── dfu_user.c                           # DFU middleware hooks (I2C transport glue; NVM hooks unused by SPDM)
├── router/  spdm_router.c/.h            # SPDM command router: DFU opcode 0x80 handler + DFU service loop
├── spdm/                                # libspdm integration glue
│   ├── spdm_lib_config_psc3.h           # tailored libspdm config (-DLIBSPDM_CONFIG)
│   ├── spdm_debuglib.c                  # debuglib hook -> UART log facility
│   ├── spdm_memlib.c                    # memlib hook (static copy/set/zero/compare)
│   ├── spdm_platform.c                  # platform_lib hook (libspdm_sleep)
│   ├── spdm_transport_dfu.c/.h          # DFU/I2C carrier bridge + libspdm device-I/O callbacks
│   ├── spdm_responder.c/.h              # libspdm responder context: init (caps/algos/cert) + dispatch
│   ├── device_secret.c                  # libspdm_responder_data_sign -> device-sign veneer
│   ├── spdm_measlib.c                   # libspdm measurement HAL -> measurement NSC veneers
│   ├── cryptlib/                        # libspdm cryptlib, split by primitive family
│   │   ├── rand.c                       # libspdm_random_bytes -> RNG veneer
│   │   ├── hash.c                       # SHA-256 / SHA-384 / SHA-512 -> generic hash veneers
│   │   ├── mac.c                        # HMAC (SHA-256/SHA-384/SHA-512), built NS-side on hash veneers
│   │   ├── kdf.c                        # HKDF (RFC 5869), built NS-side on HMAC
│   │   ├── aead.c                       # AES-256-GCM -> AEAD veneer
│   │   ├── ec.c                         # ECDHE P-256/P-384/P-521 -> EC key-agreement veneers
│   │   ├── mldsa.c                      # ML-DSA-87 glue -> device-sign veneer
│   │   ├── mlkem.c                      # ML-KEM-1024 encapsulate -> nsc_psa veneer
│   │   └── internal.h                   # shared constants + best-effort zeroize
│   ├── toolchain_arm_none_eabi.cmake    # CMake toolchain mirroring NS ABI flags
│   ├── libspdm_psc3.cmake               # builds the Responder static libs
│   └── CMakeLists.txt                   # thin entry point including libspdm_psc3.cmake
├── log/  log.c/.h                       # UART logging facility (retarget-io)
└── deps/  dfu.mtb, retarget-io.mtb
```

The following are **generated on your machine** and are git-ignored, never
committed here: `bsps/` (from the manifest + `templates/` overlay),
`mtb_shared/` and `libs/` (from `make getlibs`), `proj_cm33_ns/build_libspdm/`
(the libspdm CMake output), and `build/`.


## 2. Secure / non-secure memory split

The SRAM/flash split is established differently on the two kit families:
**KIT_PSC3M5_EVK** uses build-time knobs plus an OEM MPC policy, while
**KIT_PSC3M6_EVAL** and **KIT_PSC3M8_EVK** delegate the whole map to the Device
Configurator. On all of them, the split must stay in sync with the provisioned
assets &mdash; changing it requires re-provisioning the device.

### 2.1 KIT_PSC3M5_EVK

The split is defined in `common.mk` (the single source of truth) and mirrored in
two dependent places:

- `common.mk` &mdash; `SECURE_SRAM_SIZE` / `SECURE_FLASH_SIZE`, emitted as the
  GCC defsyms `_size_S_SRAM` / `_size_S_FLASH` via `LDFLAGS`.
- `proj_cm33_s/Makefile` &mdash; `USER_SRAM_S_SIZE` / `USER_FLASH_S_SIZE`,
  derived from the `common.mk` values above (feed the BSP `partition_psc3.h`
  that programs the secure-core SAU).
- `ns_policy/policy_oem_provisioning.json` &mdash; the MPC RAM & flash regions
  actually enforced at provisioning time; must be kept in sync by hand.

The secure partition is **32 KB SRAM / 100 KB flash**. The non-secure app gets
the remaining **148 KB** of flash (100 KB .. 248 KB), and the top **8 KB**
(248 KB .. 256 KB) is the secure-only Provisioning Asset Store (PAS). Changing
the split requires re-provisioning. This kit runs the classic PSA / mbedTLS
profiles `P1`, `P2` and `P3` only; the wolfCrypt-backed PQC profile `P4` does
not fit this device's SRAM/flash. It pins the v2.X `cy-mbedtls-acceleration`
asset (`platforms/PSC3M5/deps`); see the per-device acceleration table under
[Crypto backend](#crypto-backend) for what that covers and what falls back to
software.

### 2.2 KIT_PSC3M6_EVAL

The SAU/MPC/PPC memory map is owned by the Device Configurator
(*templates/TARGET_KIT_PSC3M6_EVAL/config/design.modus* → generated
*cymem_\*.ld* / *partition_psc3.h*) and applied inside `cybsp_init()`, so the M5
knobs above (`SECURE_*_SIZE`, the `_size_S_*` defsyms, `USER_*_S_SIZE`) are
guarded out (defined-but-unused) and no OEM policy provisioning is needed to
establish the split. The device also pins its own `cy-mbedtls-acceleration`
version through `platforms/PSC3M6/deps` (v3.X vs the M5 v2.X); re-run
`make getlibs` after switching `TARGET`. See the per-device acceleration table
under [Crypto backend](#crypto-backend) for what the v3.X accelerator covers.

The 128 KB on-chip SRAM is split **58 KB secure / 68 KB non-secure / 2 KB
shared**. The secure partition is leftover-heap sized: after static `.bss` and
an 8 KB stack, the remaining **~30 KB is the secure heap**, which matches the
ML-DSA-87 signer's working-set high-water for the `P4` suite (see
`core/spdm_crypto.c`).

The larger `P4` post-quantum cert chain drove this split. A fully-PQC chain
(ML-DSA-87 root + ML-DSA-87 leaf, ~15 KB) needs a 16 KB NS buffer
(`LIBSPDM_MAX_CERT_CHAIN_SIZE = 0x4000`, up from the classic-profile 4 KB). The
extra NS SRAM is funded from the secure side by moving the mbedTLS software-AES
tables to flash (`MBEDTLS_AES_ROM_TABLES` + `MBEDTLS_AES_FEWER_TABLES` in
`config/spdm_mbedtls_config.h`), freeing ~8.7 KB of secure SRAM for ~2.6 KB of
secure flash. Because AES-256-GCM is not CryptoLite-accelerated (see the table
under [Crypto backend](#crypto-backend)), both the CTR_DRBG RNG and the session
AES-256-GCM data path run on mbedTLS software AES; the ROM-table build trades a
small amount of AES throughput for the SRAM saving.

### 2.3 KIT_PSC3M8_EVK

PSC3M8 is a multicore part, but only its main CM33 (TrustZone) core is used
here, so it tracks **KIT_PSC3M6_EVAL** exactly: the SAU/MPC/PPC memory map is
owned by the Device Configurator
(*templates/TARGET_KIT_PSC3M8_EVK/config/design.modus* → generated
*cymem_\*.ld* / *partition_psc3.h*) and applied inside `cybsp_init()`; the M5
knobs are guarded out and no OEM policy provisioning is needed. It pins its own
asset versions through `platforms/PSC3M8/deps` (same v3.X family as M6). All
four profiles (`P1`&ndash;`P4`) are supported. The concrete secure/non-secure
split follows the generated M8 memory map defined in its *design.modus*.


## 3. Build infrastructure

This repository is a single ModusToolbox&trade; **application** with two
projects that build together from the top-level `Makefile`:

- `proj_cm33_s` (secure / SPE) &mdash; `VCORE_ATTRS=SECURE`. It compiles the
  Non-Secure-Callable (NSC) veneers and produces the CMSE **import library**
  (`nsc_veneer.o`) that exports the secure entry points to the non-secure world,
  plus its own secure image (`proj_cm33_s.hex`).
- `proj_cm33_ns` (non-secure / NSPE) &mdash; `VCORE_ATTRS=NON_SECURE`. It links
  against the secure import library and the libspdm archives to produce the
  non-secure image (`proj_cm33_ns.hex`).

The secure project builds first because the non-secure link consumes its import
library; `make program` then flashes both images as one application. The secure
/ non-secure memory split is applied at link time through the defsyms and BSP
partition described in [section 2](#2-secure--non-secure-memory-split).

### libspdm archives

libspdm is vendored as a **pristine git submodule** at `third_party/libspdm`
pinned to **4.0.0-rc** and is built from source by CMake into
**config-specialized static archives**, which the ModusToolbox non-secure
project then links. Two build systems produce one image.

- `proj_cm33_ns/spdm/spdm_lib_config_psc3.h` &mdash; the tailored config passed
  to the libspdm build via `-DLIBSPDM_CONFIG`. The active cipher profile is
  chosen by `SPDM_PROFILE`: `P1` selects ECDSA/ECDHE P-256 + SHA-256, `P2`
  P-384 + SHA-384, `P3` P-521 + SHA-512 (all SPDM up to 1.4); `P4` selects
  ML-DSA-87, ML-KEM-1024, SHA-384, SPDM 1.4. All
  share
  AES-256-GCM; `CHUNK_CAP=1`; `MAX_SESSION_COUNT=1`; transport header = 1 byte.
  It ends by including libspdm's own `library/spdm_lib_config.h` so upstream
  defaults fill in everything it does not override.
- `proj_cm33_ns/spdm/toolchain_arm_none_eabi.cmake` &mdash; a CMake toolchain
  file whose ABI flags exactly mirror the MTB non-secure GCC build
  (`-mcpu=cortex-m33`, `--specs=nano.specs`, `-mthumb`, softfloat, section GC).
  The non-secure core needs no `-mcmse`.
- `proj_cm33_ns/spdm/libspdm_psc3.cmake` (+ a thin `CMakeLists.txt`) &mdash;
  builds only the Responder set into `build_libspdm/lib/`:
  `spdm_common_lib`, `spdm_crypt_lib`, `spdm_secured_message_lib`,
  `spdm_responder_lib`, `spdm_transport_mctp_lib`.

The archives call a small set of platform primitives (`debuglib`, `memlib`,
`platform_lib`) and the crypto backend and device-secret / signing hooks, none
of which libspdm ships an implementation for. The platform primitives are
provided by the app-local glue described in
[the platform hooks section](#platform-hooks). The crypto backend is resolved by
the NS cryptlib and the secure crypto service described in
[the crypto backend section](#crypto-backend). The device-secret signing hook
(`libspdm_responder_data_sign`) and the ECDHE key-agreement primitives are
resolved by `spdm/device_secret.c` / `spdm/cryptlib/ec.c` over the device-sign
and EC NSC veneers. When the profile selects ML-DSA-87 / ML-KEM-1024, those
signing and encapsulation hooks are resolved by `spdm/cryptlib/mldsa.c` /
`mlkem.c` over the device-sign and `nsc_psa` veneers instead. The Responder never verifies a peer (`MUT_AUTH_CAP=0`) and
never parses its own chain, so with `LIBSPDM_CERT_PARSE_SUPPORT=0` no
certificate-parse crypto (`libspdm_x509_*`, `libspdm_ecdsa_verify`, DER/X.509
public-key extraction) is referenced &mdash; the archives carry no X.509 parser. The non-secure `Makefile` runs the CMake build in its
`PREBUILD` step &mdash; pinning the ModusToolbox-bundled Ninja via
`CMAKE_MAKE_PROGRAM` and excluding the CMake build tree from MTB source
discovery via `CY_IGNORE` &mdash; and links the archives through `LDLIBS`
(wrapped in a linker group so listing order does not matter).

```mermaid
flowchart LR
    subgraph SEC["MTB Make: proj_cm33_s (SECURE / SPE)"]
        ssrc["main.c + core/ + nsc/ + pas/"] --> sbuild["secure build"]
        sbuild --> veneer["nsc_veneer.o<br/>(CMSE import library)"]
        sbuild --> shex["proj_cm33_s.hex"]
    end
    subgraph CMake["PREBUILD: CMake (libspdm submodule)"]
        cfg["spdm_lib_config_psc3.h<br/>(-DLIBSPDM_CONFIG)"] --> libs
        tc["toolchain_arm_none_eabi.cmake<br/>(mirrors MTB NS flags)"] --> libs
        libs["build_libspdm/lib/<br/>libspdm_*.a"]
    end
    subgraph NS["MTB Make: proj_cm33_ns (NON-SECURE / NSPE)"]
        libs --> link["NS link"]
        hooks["spdm/*.c<br/>(debuglib / memlib / platform_lib)"] --> link
        veneer --> link
        link --> nshex["proj_cm33_ns.hex"]
    end
    shex --> app["Application<br/>(make program: S + NS)"]
    nshex --> app
```

Any change to `spdm_lib_config_psc3.h` or the toolchain flags requires
rebuilding the archives.

### Composing a custom profile

A profile is the single build-time declaration of the cipher suite. Each lives
in `profiles/<name>/` and is selected by include path: `SPDM_PROFILE=<name>`
makes the build add `profiles/<name>` to the include path, and every consumer
reaches it through a fixed `#include "profile.h"`. The four implemented profiles
(`P1`&ndash;`P4`) are just points in a small space you can extend.

A `profile.h` defines exactly **five selectors**, drawn from the token
vocabulary in `profiles/profile_schema.h`. The axes are orthogonal &mdash;
signature, transcript hash, key exchange and AEAD are chosen independently:

| Selector | Tokens | Meaning |
| -------- | ------ | ------- |
| `SPDM_DEV_ID` | `SPDM_DEV_ID_ECDSA_P256` \| `_P384` \| `_P521` \| `SPDM_DEV_ID_MLDSA87` | device identity / asymmetric signature |
| `SPDM_BASE_HASH` | `SPDM_HASH_SHA256` \| `SPDM_HASH_SHA384` \| `SPDM_HASH_SHA512` | transcript / key-schedule hash |
| `SPDM_MEAS_HASH` | same as `SPDM_BASE_HASH` | measurement-block hash (optional; omit to default to `SPDM_BASE_HASH`) |
| `SPDM_KEX` | `SPDM_KEX_ECDHE_P256` \| `_P384` \| `_P521` \| `SPDM_KEX_MLKEM1024` | session key exchange |
| `SPDM_AEAD_SUITE` | `SPDM_AEAD_AES256_GCM` | session AEAD |

A profile never defines capability flags directly. `profiles/profile_derive.h`
expands the five selectors into the `SPDM_HAVE_*` vocabulary the libspdm config
and crypto backends switch on (`SPDM_HAVE_ECDSA_P256` / `_P384` / `_P521`,
`_MLDSA87`, `_ECDHE_P256` / `_P384` / `_P521`, `_MLKEM1024`, `_SHA256` /
`_SHA384` / `_SHA512`, `_AES256_GCM`), each
expanding to `0` or `1`, plus the ECDSA device-key PSA geometry
(`SPDM_DEV_HASH_ALG` / `SPDM_DEV_EC_FAMILY` / `SPDM_DEV_EC_BITS`).
`profiles/profile_check.h`, included last, rejects an out-of-range or missing
selector at compile time with a `#error`.

To author `profiles/my_profile/`:

1. Copy `profiles/_template/` to `profiles/my_profile/`.
2. Edit `profile.h`: set the five selectors to the tokens you want.
3. Edit the sibling `profile.mk` &mdash; the build-graph delta. A profile that
   needs the post-quantum primitives sets `SPDM_PROFILE_USES_WOLFCRYPT := 1`
   (as `P4` does) so the secure project wires the wolfCrypt backend;
   a pure PSA/mbedTLS profile leaves it unset (as `P1`&ndash;`P3` do).
4. Add `my_profile` to the `SPDM_PROFILES_SUPPORTED` allow-list in each
   `platforms/<platform>/detect_platform.mk` that may build it. A profile that
   pulls in wolfCrypt must only be listed on platforms whose
   `detect_platform.mk` also sets `PLATFORM_SUPPORTS_WOLFCRYPT`; the build
   errors out otherwise.
5. Build with `make build SPDM_PROFILE=my_profile` (run `make clean` when
   switching profiles). Provision the device with an identity chain whose
   signature algorithm matches `SPDM_DEV_ID`.

Not every selector combination is a *recognized* suite &mdash; it just has to be
a self-consistent SPDM build that `profile_check.h` and `profile_derive.h`
accept. Whether a given custom combination also satisfies an external standard
(for example CNSA 2.0) is a separate question; see
[architecture_and_security.md](architecture_and_security.md).

### Platform hooks

libspdm delegates a few platform primitives to the integrator. They are
implemented app-local under `proj_cm33_ns/spdm/` and compiled directly by the
ModusToolbox non-secure project (not the CMake archive build), so they can reach
application facilities such as the UART log. The non-secure `Makefile` compiles
them with the same `-DLIBSPDM_CONFIG="spdm_lib_config_psc3.h"` the archives use,
so the libspdm headers resolve to the identical configuration on both sides.

- `spdm_debuglib.c` &mdash; routes libspdm's `libspdm_debug_print()` and
  `libspdm_debug_assert()` onto the same debug UART the `LOG_*` macros use.
  libspdm ERROR output is always surfaced; its verbose INFO stream is emitted
  only when the image is built at `LOG_LEVEL_DEBUG`. Building with
  `LIBSPDM_DEBUG_ENABLE=0` drops the routines and all libspdm debug strings.
- `spdm_memlib.c` &mdash; the four memory primitives (`libspdm_copy_mem`,
  `libspdm_set_mem`, `libspdm_zero_mem`, `libspdm_consttime_is_mem_equal`),
  implemented with volatile accesses (constant-time compare, non-elidable
  scrub) and no dynamic allocation.
- `spdm_platform.c` &mdash; `libspdm_sleep()` on the PDL SysLib delay. The
  heartbeat watchdog hooks are intentionally omitted: `HBEAT_CAP` is disabled in
  the config, so the libspdm Responder never references them.

### Crypto backend

libspdm's `libspdm_*` crypto primitives are left unresolved by the archives. The
SPDM Responder cipher suite (SHA-256/SHA-384/SHA-512, HMAC/HKDF,
ECDSA/ECDHE P-256/P-384/P-521 or
ML-DSA-87/ML-KEM-1024, AES-256-GCM, RNG) is resolved by a **PSA-shaped seam**
that keeps the actual cryptography and all key material in the secure world. The
Non-Secure-Callable boundary deliberately exposes only **generic PSA-style
primitives** &mdash; a multipart hash mirroring `psa_hash_*`, a one-call AEAD,
and the RNG. Because that boundary offers no MAC primitive, the parts of the
cipher suite that are pure compositions of a hash (HMAC and HKDF) are
reconstructed **in the non-secure world** on top of the generic hash veneers;
the hash compression itself still runs in the SPE. The post-quantum primitives
(ML-DSA-87 signing, ML-KEM-1024 encapsulation), when a profile selects them, run
in the SPE on **wolfCrypt**, which PSA / mbedTLS cannot provide.

1. **NS cryptlib** &mdash; `proj_cm33_ns/spdm/cryptlib/` implements the
   `libspdm_*` entry points, split one file per primitive family: `rand.c`,
   `hash.c` and `aead.c` forward straight to a veneer, while `mac.c`
   (HMAC) and `kdf.c` (HKDF) run in the non-secure world over the
   hash veneers, and `mldsa.c` / `mlkem.c` (compiled when the profile selects
   the post-quantum primitives) forward those operations to the secure world.
   `internal.h` holds the shared
   constants and a best-effort buffer scrub.
2. **NSC veneers** &mdash; `proj_cm33_s/nsc/nsc_psa.c` (`nsc_psa_*`,
   `cmse_nonsecure_entry`) form the crypto trust boundary, alongside the
   boundary-wide ABI-version veneer in `nsc/nsc.c`. Every pointer the non-secure
   caller supplies is checked with `cmse_check_address_range()` to prove it lies
   wholly in non-secure memory with the required access before it is
   dereferenced; a failed check makes the veneer refuse the call. Veneers return
   a `nsc_psa_status_t` value-compatible with `psa_status_t` (`0` == success).
3. **Secure PSA crypto service** &mdash; `proj_cm33_s/core/spdm_crypto.c` runs
   the actual cryptography on the PSA Crypto API (ifx-mbedtls + MXCRYPTOLITE +
   TRNG), configured by `config/spdm_mbedtls_config.h` and
   `config/spdm_psa_crypto_config.h` and initialized by `spdm_crypto_init()` in
   the secure `main()` before the non-secure world is launched.

```mermaid
flowchart LR
    A["libspdm (NSPE)"] --> B["cryptlib/ (NSPE)<br/>rand/hash/aead forward;<br/>mac/kdf compose over hash"]
    B --> C["nsc_psa_* veneer<br/>(cmse checks, PSA-style)"]
    C ==>|NSC gateway| D["spdm_crypto_* service<br/>PSA / MXCRYPTOLITE / TRNG"]
```

Design points:

- **Generic hash recomposed non-secure.** The one-shot `psa_hash_compute` is not
  a veneer: it is recomposed non-secure from `setup`+`update`+`finish`, which
  also keeps every hash veneer within the four-register CMSE argument limit.
- **Streaming hash handles.** Streaming hash contexts (SHA-256 or SHA-384) live
  in a fixed secure hash pool; a veneer returns a small non-zero handle. Because
  libspdm passes the *same* context pointer to init/update/final, the non-secure
  cryptlib keeps a tiny pool of cells that each hold one secure handle and hands
  libspdm a pointer to the cell. A forged handle can at worst select a pool slot.
- **HMAC/HKDF construction.** HMAC is built in `mac.c` on the cloneable
  hash veneers (`H((k^opad) || H((k^ipad) || msg))`) &mdash; the PSA MAC API has
  no clone, but the SPDM key schedule needs to duplicate a partial HMAC context
  &mdash; and HKDF (`kdf.c`) is the RFC 5869 construction over it. Only the
  ipad/opad blocks and intermediate PRK/T values sit in non-secure memory; every
  hash compression still executes in the SPE.
- **AEAD.** The AEAD veneer is deliberately coarse: it takes the raw session key
  bytes and a separate tag buffer (matching libspdm's per-record interface). The
  SPE imports the volatile AES key, runs AES-GCM through the PSA multipart AEAD
  API so the ciphertext and tag land in separate buffers with no payload-sized
  bounce, and destroys the key &mdash; all inside the single call. Decryption
  uses `psa_aead_verify()` for the constant-time, fail-closed tag check.
- **Device and ephemeral keys stay in the SPE.** `spdm_crypto_device_sign()`
  reads the wrapped scalar from PAS slot 0, HUK-derives the wrapping key,
  unwraps, imports, signs once and destroys it; the ephemeral key-agreement
  private key (the ECDHE private scalar or the ML-KEM decapsulation state,
  whichever the profile selects) stays in the secure world, so only the public
  value and the shared secret cross the boundary.

**Hardware acceleration (per device).** The MXCryptolite PSA transparent driver
accelerates part of the suite; everything else runs in mbedTLS (or wolfCrypt)
software. What is accelerated depends on the `cy-mbedtls-acceleration` version
pinned per device in `platforms/PSC3Mx/deps`:

| Device | Accelerator | Hardware accelerated |
|--------|-------------|----------------------|
| PSC3M5 | v2.X | SHA-256; ECDSA / ECDH P-256, P-384 |
| PSC3M6 / M8 | v3.X | SHA-256/384/512; ECDSA / ECDH P-256, P-384 |

P-521 EC and AES-256-GCM are not CryptoLite-accelerated and run in mbedTLS
software. The CryptoLite user config (`config/spdm_cryptolite_config_v3.h` for
M6/M8, `platforms/PSC3M5/config/spdm_cryptolite_config.h` for M5) excludes the
P-521 curve entirely so a P-521 ECDSA sign routes to software instead of failing
on hardware that cannot perform it; the exact mechanism is documented in those
two headers. Deterministic ECDSA (RFC 6979) is deliberately not enabled:
MXCryptolite only accelerates the randomised variant, so enabling it would
silently fall back to software.

> The *rationale* for this seam (why crypto and keys live in the SPE, why
> HMAC/HKDF are composed in the NSPE) and its *security posture* (what the
> boundary does and does not protect &mdash; notably that transient session
> secrets still transit non-secure SRAM) are covered in
> [architecture_and_security.md](architecture_and_security.md); the points above
> are only the implementation mechanics.


## 4. Initialization sequence

The secure application owns reset. It brings up the board, configures the SAU
and the Peripheral Protection Controller (PPC) &mdash; which hands *most*
peripherals to the non-secure world (including the debug UART) while keeping the
CryptoLite accelerator, the TRNG and the flash controller (FLASHC) secure by
leaving them at their secure reset default &mdash; initializes the secure PSA
crypto service and the read-only Provisioning Asset Store (PAS) accessor, and
launches the non-secure application.

```mermaid
flowchart LR
    subgraph SPE["Secure world (SPE)"]
        direction LR
        A["cybsp_init"] --> B["TZ_SAU_Setup()"]
        B --> C["config_ppc()<br/>most peripherals to NSPE<br/>(CryptoLite/TRNG/flash stay secure)"]
        C --> D["spdm_crypto_init()<br/>TRNG/DRBG ready"]
        D --> E["pas_init()<br/>validate PAS geometry"]
        E --> F["__enable_irq()"]
        F --> G["launch NonSecure_ResetHandler"]
    end
```

The non-secure application initializes the board and the logging facility, calls
the secure NSC veneer to confirm the TrustZone&reg; path, and enters its service
loop.

```mermaid
flowchart LR
    subgraph NSPE["Non-secure world (NSPE)"]
        direction LR
        G["cybsp_init + __enable_irq"] --> H["log_init()<br/>debug UART"]
        H --> I["nsc_get_abi_version()<br/>NS→S path check"]
        I --> J["libspdm_module_version()<br/>libspdm link check"]
        J --> K["Cy_DFU_Init + spdm_router_register"]
        K --> L["spdm_responder_init()<br/>context/caps/algos/cert"]
        L --> M["I2C transport start"]
        M --> N["spdm_router_run()<br/>DFU 0x80 loop + heartbeat LED"]
    end
```

The secure world exports the baseline veneer `nsc_get_abi_version()`
alongside the crypto-service, device-sign, certificate-chain and
measurement-sourcing veneers (the NSC ABI is now `0x0006`). The baseline veneer confirms the non-secure&rarr;secure
call path and gives the GCC CMSE import library a gateway to export (an import
library with no gateways fails to link). Before the service loop, the non-secure
app calls `libspdm_module_version()`; because that symbol lives in
`libspdm_common_lib`, logging the version proves the archives link and the
platform hooks resolve at runtime. The non-secure app then initializes the DFU
middleware, registers the SPDM router as the DFU user-command handler, builds
the libspdm responder context with `spdm_responder_init()`, brings up the I2C
slave transport, and hands control to `spdm_router_run()` &mdash; the DFU
command/response service loop that dispatches the SPDM transfer opcode (`0x80`)
and toggles the user LED while idle. The `0x80` handler drives the SPDM command
flow described in [section 5](#5-spdm-command-flow).


## 5. SPDM command flow

The device answers SPDM requests from a host Requester using the libspdm
Responder. Requests are carried as an MCTP message type over a DFU user-defined
command on I2C: a single DFU opcode (`0x80`) carries one MCTP-framed SPDM
transport message per transaction (request in, response out), and
`spdm_transport_mctp_lib` supplies the 1-byte MCTP message-type prefix (`0x05`
SPDM / `0x06` secured). The 4-byte MCTP packet header, SMBus framing and PEC of
full MCTP are not used; SPDM messages larger than one I2C/DFU payload are split
across transactions by SPDM `CHUNK_CAP`.

### The push/pull bridge

The DFU middleware *pushes* each command into a synchronous handler and expects
the response back from that same call, whereas libspdm *pulls* a request and
*pushes* its reply through device-I/O callbacks that it invokes itself. The
carrier bridge `spdm/spdm_transport_dfu.c` reconciles the two with a single
in-flight transport message held in static staging buffers. It has exactly two
consumers:

- **`router/spdm_router.c`** &mdash; the *staging* API. The DFU `0x80` handler
  calls `spdm_transport_dfu_stage_request()` to park the inbound request, then
  `spdm_transport_dfu_take_response()` to copy the produced reply back into the
  DFU response (`spdm_transport_dfu_reset()` clears the bridge on session
  re-arm).
- **libspdm** &mdash; the *device-I/O* callbacks. `spdm_transport_dfu.c`
  implements libspdm's `libspdm_device_*` hook set: `receive_message` hands
  libspdm the staged request, `send_message` captures the encoded reply, and the
  acquire/release sender/receiver pairs lend libspdm its transport scratch
  buffers. These are the libspdm hooks &mdash; they match libspdm's
  `libspdm_device_*_func` typedefs and are bound to the responder context with
  `libspdm_register_device_io_func()` and
  `libspdm_register_device_buffer_func()`, so libspdm calls them itself while
  running `libspdm_responder_dispatch_message()`.

The sequence below shows one SPDM transaction end to end &mdash; who calls whom,
and which side of the bridge each call lands on:

```mermaid
sequenceDiagram
    autonumber
    participant Host as Host Requester
    participant DFU as DFU middleware (I2C)
    participant Router as spdm_router.c
    participant Bridge as spdm_transport_dfu.c
    participant SPDM as libspdm responder

    Host->>DFU: DFU cmd 0x80 (MCTP-framed SPDM request)
    DFU->>Router: custom-command handler(packet)
    Router->>Bridge: stage_request(request)
    Router->>SPDM: libspdm_responder_dispatch_message(ctx)
    SPDM->>Bridge: acquire_receiver_buffer()
    SPDM->>Bridge: receive_message() reads staged request
    Note over SPDM: decode, process, encode<br/>(device-key crypto via NSC to the SPE)
    SPDM->>Bridge: acquire_sender_buffer()
    SPDM->>Bridge: send_message() writes reply
    SPDM-->>Router: dispatch returns
    Router->>Bridge: take_response() reads reply
    Router-->>DFU: reply bytes
    DFU-->>Host: DFU response (MCTP-framed SPDM response)
```

Cryptographic operations that touch the device key are forwarded across the NSC
boundary into the secure world (the `decode, process, encode` step above), which
signs from the device private key (PAS slot 0) and returns the result. The
host-assembled certificate chain is served verbatim; the device holds no X.509
of its own.

If a dispatch produces no response &mdash; an error, or a request libspdm drops
silently &mdash; the `0x80` handler returns a single-byte `SPDM_XFER_NOT_READY`
status instead so the host does not block; an empty or oversized request returns
`SPDM_XFER_BAD_LEN`.

### The responder context

`spdm/spdm_responder.c` owns the single libspdm responder context and all of its
backing storage, allocated statically (the part has no dynamic allocator).
`spdm_responder_init()` runs once at bring-up and:

1. initializes the context (`libspdm_init_context`);
2. registers the carrier device-I/O and buffer callbacks
   (`libspdm_register_device_io_func` / `libspdm_register_device_buffer_func`)
   and the MCTP transport layer (`libspdm_register_transport_layer_func` with
   `libspdm_transport_mctp_encode_message` / `_decode_message`);
3. sets the scratch buffer libspdm needs for chunk reassembly and secured-message
   working space (`libspdm_set_scratch_buffer`);
4. sets the supported capabilities (`CERT`, `CHAL`, `MEAS` signed, `KEY_EX`,
   `ENCRYPT`, `MAC`, `CHUNK`) and the negotiated algorithm suite the active
   profile selects (ECDSA/ECDHE P-256 with SHA-256, P-384 with SHA-384, P-521
   with SHA-512, or ML-DSA-87/ML-KEM-1024 with SHA-384) &mdash; plus
   AES-256-GCM, the SPDM key schedule, and the DMTF
   measurement specification with its measurement hash, via `libspdm_set_data`;
   and
5. reads the provisioned SPDM certificate chain from the secure PAS through the
   `nsc_read_cert_chain()` veneer and hands it to libspdm
   (`libspdm_set_data(LIBSPDM_DATA_LOCAL_PUBLIC_CERT_CHAIN)`) to serve verbatim.

The negotiated `DataTransferSize` (127 bytes) and the local maximum SPDM message
size are derived by libspdm from the registered buffer sizes and transport
header, so they are not set explicitly. The certificate chain is stored in the
context **by pointer**, so its buffer is a persistent static; it is public key
material and never parsed on the device.

### Message flow

With the context in place the device supports two flows from a host Requester:

- **Identity attestation** &mdash; `GET_VERSION`, `GET_CAPABILITIES`,
  `NEGOTIATE_ALGORITHMS`, `GET_DIGESTS` (negotiated hash over the served chain),
  `GET_CERTIFICATE` (the chain returned verbatim in `MAX_CERT_CHAIN_BLOCK_LEN`
  portions), and `CHALLENGE` / `CHALLENGE_AUTH` signed with the device key.
- **Measurement attestation** &mdash; `GET_MEASUREMENTS` returns the DMTF
  measurement record and, with `GENERATE_SIGNATURE`, a signature over the
  measurement transcript; `CHALLENGE_AUTH` and `KEY_EXCHANGE_RSP` additionally
  embed a `measurement_summary_hash`. All measured state, DMTF record assembly
  and hashing happen in the secure world (see
  [section 6](#6-measurements)).
- **Secure session** &mdash; `KEY_EXCHANGE` / `FINISH` establish a session
  (using the key exchange the active profile selects &mdash; ECDHE-P256 or
  ML-KEM-1024) whose `KEY_EXCHANGE_RSP`
  is signed with the device key; application
  records are then protected with AES-256-GCM keyed from the session secret.
  Application data the Requester sends *inside* the session is delivered to a
  registered app-message handler (`spdm_responder_process_app_message`, wired in
  with `libspdm_register_get_response_func`) once libspdm has decrypted and
  de-framed it. That handler is currently a **placeholder that echoes the
  decrypted payload back unchanged** &mdash; the secure channel is exercised
  end to end, but there is no in-session application protocol yet; an integrator
  adds one in that single function.

The sequence below shows a full attestation exchange &mdash; version and
capability negotiation, identity, measurements, and a secure session &mdash; and
which responses are signed inside the secure world (SPE). Each arrow is one MCTP
transport message (one DFU `0x80` transaction):

```mermaid
sequenceDiagram
    autonumber
    participant H as Host Requester
    participant D as Device Responder (NSPE)
    participant S as Secure world (SPE)

    Note over H,D: Negotiation (unauthenticated)
    H->>D: GET_VERSION
    D-->>H: VERSION
    H->>D: GET_CAPABILITIES
    D-->>H: CAPABILITIES
    H->>D: NEGOTIATE_ALGORITHMS
    D-->>H: ALGORITHMS

    Note over H,D: Identity attestation
    H->>D: GET_DIGESTS
    D-->>H: DIGESTS (negotiated hash over served chain)
    H->>D: GET_CERTIFICATE
    D-->>H: CERTIFICATE (chain served verbatim)
    H->>D: CHALLENGE (nonce)
    D->>S: sign transcript with device key
    S-->>D: signature
    D-->>H: CHALLENGE_AUTH (+ measurement_summary_hash)

    Note over H,D: Measurement attestation
    H->>D: GET_MEASUREMENTS (GENERATE_SIGNATURE)
    D->>S: assemble DMTF record + summary hash + sign
    S-->>D: record + signature
    D-->>H: MEASUREMENTS (signed)

    Note over H,D: Secure session
    H->>D: KEY_EXCHANGE (ECDHE point / ML-KEM encap key)
    D->>S: key agreement + sign KEY_EXCHANGE_RSP
    S-->>D: shared secret + signature
    D-->>H: KEY_EXCHANGE_RSP (signed)
    H->>D: FINISH
    D-->>H: FINISH_RSP
    Note over H,D: Application data over the secure session (AES-256-GCM)
    H->>D: application message (encrypted)
    Note over D: libspdm decrypts and de-frames, app handler echoes payload (placeholder)
    D-->>H: application message echoed (encrypted)
    H->>D: END_SESSION
    D-->>H: END_SESSION_ACK
```

Each request/response is one MCTP-framed transport message and therefore one DFU
`0x80` transaction. Messages larger than a single 128-byte payload (a certificate
portion, a signed `KEY_EXCHANGE_RSP`) are split across transactions by SPDM
`CHUNK_CAP`: libspdm reassembles inbound chunks and emits outbound chunks itself,
using the scratch buffer, so the router and the carrier bridge stay oblivious and
still see exactly one transport message per transaction.

## 6. Measurements

The Responder advertises **signed measurements** (`MEAS_CAP_SIG`), so it answers
`GET_MEASUREMENTS` and embeds a `measurement_summary_hash` in `CHALLENGE_AUTH`
and `KEY_EXCHANGE_RSP`. The trust-sensitive work &mdash; assembling the record
and computing the summary hash &mdash; happens in the secure world (see the
measurement-integrity property and the
[measurement composition](architecture_and_security.md#9-measurement-composition)
diagram in [architecture_and_security.md](architecture_and_security.md)).

The measurement path mirrors the crypto seam &mdash; a thin non-secure HAL over
Non-Secure-Callable veneers into an SPE implementation &mdash; and the secure
side is split by concern:

1. **NS measurement HAL** &mdash; `spdm/spdm_measlib.c` implements libspdm's
   responder measurement hooks (`libspdm_measurement_collection`,
   `libspdm_generate_measurement_summary_hash`,
   `libspdm_measurement_opaque_data`). It is a thin wrapper: it applies the
   protocol framing concerns that belong to the non-secure responder (DMTF
   specification check, content-changed reporting, summary hash-type / size
   validation) and forwards the request &mdash; with the negotiated
   `measurement_hash_algo` / `base_hash_algo` &mdash; over the veneers. It holds
   no measured state and does no hashing.
2. **Measurement NSC veneers** &mdash; `proj_cm33_s/nsc/nsc_meas.c`
   (`nsc_get_measurement_record` / `nsc_get_measurement_summary`,
   `cmse_nonsecure_entry`) validate every non-secure pointer with
   `cmse_check_address_range()`, then own the SPDM/DMTF **wire representation**:
   they frame the measured values into DMTF measurement blocks, select the
   requested index or `TCB`/`all` subset, and compute the summary hash with the
   negotiated base hash algorithm. The DMTF block layout lives here, private to
   the secure image, and never crosses the boundary.
3. **Measurement data provider** &mdash; `proj_cm33_s/core/spdm_meas.c` is a
   protocol-agnostic provider that owns *what* the device measures. It returns
   each measurement as a neutral item (an index, a kind, and the value bytes),
   computing the digest-form values with the negotiated measurement hash
   algorithm and returning the raw-form values as-is. It knows nothing about the
   DMTF wire encoding or the summary hash, so the future real measured state has
   a single home next to `spdm_crypto`.

> **Caveat &mdash; the measured values are placeholders.** They are stand-ins (a
> fixed pre-image hash, a fixed counter, a build string); only the values are
> provisional &mdash; the DMTF record framing, subset selection, and
> negotiated-algorithm hashing are final. Replacing them with the real measured
> state (hashing the actual immutable-ROM and mutable-firmware image regions and
> reading the secure version number from the anti-rollback counter / eFuse) is a
> change confined to `core/spdm_meas.c`.


## 7. Error handling

Errors fall into two classes. **Fatal bring-up errors** stop the device: a
mis-provisioned or misconfigured device cannot attest, so it halts rather than
run in an undefined state. **Runtime request errors** are reported back to the
host (as an SPDM `ERROR` response or a single-byte carrier status) while the
responder stays available for the next transaction.

| Scenario | Detected in | Behavior |
|----------|-------------|----------|
| **PAS geometry invalid** / accessor init fails | SPE `pas_init()` | Returns non-`PAS_OK`; secure `main()` halts on `CY_ASSERT(0)` before the non-secure world is launched. |
| **Certificate not provisioned** or slot invalid (bad magic / CRC / type) | `nsc_read_cert_chain()` &rarr; `pas_slot_query()` | Veneer returns `NSC_CERT_ERROR_DOES_NOT_EXIST`; `spdm_responder_init()` fails; NS `main()` logs `SPDM responder init failed` and halts on `CY_ASSERT(0)`. |
| **Device key not provisioned** | SPE device-sign veneer at `CHALLENGE` / `KEY_EXCHANGE` time | Signing fails; libspdm returns an SPDM `ERROR` response (fail-closed) and no signature leaves the device. |
| **NSC validation failure** (a non-secure pointer is secure, straddles the boundary, or lacks access) | every veneer, `cmse_check_address_range()` | The veneer refuses the call and returns `*_ERROR_INVALID_ARGUMENT` **without dereferencing**; the cryptlib / measurement HAL propagates the failure to libspdm. |
| **Crypto failure** (a PSA operation returns non-success) | SPE crypto service &rarr; veneer status | Veneer returns a non-zero `nsc_psa_status_t`; the cryptlib returns a libspdm failure; the dispatch produces no response, so the router replies with a single-byte `SPDM_XFER_NOT_READY`. |
| **Unsupported SPDM command** | libspdm responder / `process_app_message` fallback | libspdm emits an SPDM `ERROR` response (delivered to the host normally); a non-application request reaching the fallback returns `LIBSPDM_STATUS_UNSUPPORTED_CAP`. An unknown DFU opcode (not `0x80`) is rejected by the router with `CY_DFU_ERROR_CMD`. |
| **Bad chunk sequence** / malformed transport message | libspdm chunk + transport decode | libspdm errors the dispatch; with no response produced the router replies `SPDM_XFER_NOT_READY`. An empty or oversized DFU payload is rejected earlier with `SPDM_XFER_BAD_LEN`. |

`SPDM_XFER_NOT_READY` and `SPDM_XFER_BAD_LEN` are **single-byte carrier
statuses** from the DFU `0x80` handler, not SPDM protocol messages &mdash; they
let the host distinguish "no SPDM response this transaction" from a framed SPDM
reply without blocking.

**Session re-arm.** After a finished, failed, or timed-out DFU session the
service loop calls `spdm_router_rearm()`, which resets the carrier bridge
(`spdm_transport_dfu_reset()`), re-initializes the DFU session, and re-registers
the SPDM handler. A single bad transaction therefore never wedges the responder;
the next request is served normally.
