/*****************************************************************************
 * File Name        : nsc_meas.c
 *
 * Description      : Secure (SPE) implementation of the SPDM measurement
 *                    sourcing Non-Secure-Callable (NSC) veneers for the SPDM
 *                    Responder.
 *
 *                    These veneers keep the measured state trustworthy by
 *                    producing the DMTF measurement record and the measurement
 *                    summary hash entirely inside the secure world:
 *
 *                      - nsc_get_measurement_record() assembles the requested
 *                        block(s) and copies the bytes to a non-secure buffer.
 *                      - nsc_get_measurement_summary() assembles the record
 *                        internally, selects the requested subset (TCB / all)
 *                        and returns only the hash, so a compromised non-secure
 *                        world can neither assemble nor hash the record it
 *                        later asks the device key to sign.
 *
 *                    The measurement VALUES come from the secure provider
 *                    (core/spdm_meas): a digest for digest-form measurements
 *                    (computed there with the negotiated measurement hash
 *                    algorithm) or the raw datum otherwise. This veneer owns
 *                    only the wire representation -- it frames those values into
 *                    DMTF measurement blocks, selects the requested index or
 *                    subset, and computes the summary hash with the negotiated
 *                    base hash algorithm (both mapped to a PSA algorithm, never
 *                    a hard-coded one). The destination buffers and length
 *                    out-pointers are validated with cmse_check_address_range()
 *                    to prove they lie wholly in non-secure memory before the
 *                    secure world writes to them.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <arm_cmse.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

#include "psa/crypto.h"

#include "nsc_meas.h"
#include "profile.h"
#include "spdm_meas.h"

/******************************************************************************
 * DMTF measurement encoding (secure framing, veneer-local)
 *
 * The device's measured values come from the secure provider (spdm_meas); this
 * veneer owns their SPDM/DMTF wire representation. These structs are
 * byte-identical to the DMTF measurement-block layout and are private to the
 * veneer -- the non-secure world never sees them.
 *****************************************************************************/

/* measurement_specification: DMTF. */
#define DMTF_MEAS_SPEC                     (0x01U)

/* DMTF measurement value types (low 7 bits) and the raw-bit-stream flag. */
#define DMTF_MEAS_TYPE_IMMUTABLE_ROM       (0U)
#define DMTF_MEAS_TYPE_MUTABLE_FIRMWARE    (1U)
#define DMTF_MEAS_TYPE_SECURE_VERSION_NUM  (7U)
#define DMTF_MEAS_TYPE_INFORMATIONAL       (9U)
#define DMTF_MEAS_TYPE_RAW_BIT_STREAM_FLAG (0x80U)

/* Measurement index semantics (mirror the SPDM GET_MEASUREMENTS operation). */
#define MEAS_INDEX_TOTAL_COUNT             (0x00U)   /* count only */
#define MEAS_INDEX_ALL                     (0xFFU)   /* every block */

/* measurement_summary_hash_type (mirror the SPDM request values). */
#define MEAS_SUMMARY_TCB                   (0x01U)   /* TCB-component subset */
#define MEAS_SUMMARY_ALL                   (0xFFU)   /* all measurements */

/* SPDM BaseHashAlgo identifiers used for the summary hash. This is the
 * SPDM_ALGORITHMS_BASE_HASH_ALGO_* namespace where SHA-256 is bit 0 (0x01) and
 * SHA-384 is bit 1 (0x02) -- distinct from the MeasurementHashAlgo namespace
 * (SHA-256 = 0x02). Profiles negotiate SHA-256, SHA-384, or SHA-512 per the
 * measurement-hash selection. */
#if SPDM_HAVE_SHA256
#define BASE_HASH_ALG_SHA_256              (0x00000001U)
#endif
#if SPDM_HAVE_SHA384
#define BASE_HASH_ALG_SHA_384              (0x00000002U)
#endif
#if SPDM_HAVE_SHA512
#define BASE_HASH_ALG_SHA_512              (0x00000004U)
#endif

/* Largest measurement record this veneer will frame (bytes). Comfortably above
 * the four-block PSC3 record (~117 B); bounds the summary subset scratch. */
#define MEAS_MAX_RECORD_SIZE               (256U)

#if defined(__GNUC__) || defined(__clang__)
#define MEAS_PACKED __attribute__((packed))
#else
#define MEAS_PACKED
#endif

/* Common measurement block header: index, spec, then the size of everything
 * that follows in this block (the DMTF value header plus the value). */
typedef struct MEAS_PACKED {
    uint8_t  index;
    uint8_t  measurement_specification;
    uint16_t measurement_size;
} dmtf_block_common_header_t;

/* DMTF measurement value header: value type and value size. */
typedef struct MEAS_PACKED {
    uint8_t  value_type;
    uint16_t value_size;
} dmtf_value_header_t;

/******************************************************************************
 * Internal helpers -- non-secure pointer validation
 *
 * cmse_check_address_range() confirms the whole [ptr, ptr+len) range is
 * non-secure and carries the requested access for the current (non-secure)
 * security state. A NULL return means the caller passed a pointer that is
 * secure, straddles the boundary, or lacks permission.
 *****************************************************************************/

static bool ns_readable(const void *ptr, size_t len)
{
    if (len == 0U) {
        return true;
    }
    return (cmse_check_address_range((void *)ptr, len,
                                     CMSE_NONSECURE | CMSE_MPU_READ) != NULL);
}

static bool ns_writable(void *ptr, size_t len)
{
    if (len == 0U) {
        return true;
    }
    return (cmse_check_address_range(ptr, len,
                                     CMSE_NONSECURE | CMSE_MPU_READWRITE) !=
            NULL);
}

/******************************************************************************
 * Internal helpers -- negotiated hash mapping (summary hash)
 *****************************************************************************/

/* Map the negotiated SPDM base hash algorithm identifier to a PSA algorithm and
 * its digest size, for the measurement summary hash. Driven by the negotiated
 * value; only the algorithms this responder negotiates are accepted. */
static psa_status_t summary_map_hash(uint32_t base_hash_algo,
                                     psa_algorithm_t *psa_alg,
                                     size_t *digest_size)
{
    switch (base_hash_algo) {
#if SPDM_HAVE_SHA256
    case BASE_HASH_ALG_SHA_256:
        *psa_alg = PSA_ALG_SHA_256;
        *digest_size = 32U;
        return PSA_SUCCESS;
#endif
#if SPDM_HAVE_SHA384
    case BASE_HASH_ALG_SHA_384:
        *psa_alg = PSA_ALG_SHA_384;
        *digest_size = 48U;
        return PSA_SUCCESS;
#endif
#if SPDM_HAVE_SHA512
    case BASE_HASH_ALG_SHA_512:
        *psa_alg = PSA_ALG_SHA_512;
        *digest_size = 64U;
        return PSA_SUCCESS;
#endif
    default:
        return PSA_ERROR_NOT_SUPPORTED;
    }
}

/******************************************************************************
 * Internal helpers -- DMTF framing
 *****************************************************************************/

/* Translate a provider measurement kind to its DMTF value type, setting the
 * raw-bit-stream flag for raw-form measurements. */
static uint8_t dmtf_value_type_from_kind(spdm_meas_kind_t kind)
{
    switch (kind) {
    case SPDM_MEAS_KIND_IMMUTABLE_ROM:
        return (uint8_t)DMTF_MEAS_TYPE_IMMUTABLE_ROM;      /* digest form */
    case SPDM_MEAS_KIND_MUTABLE_FIRMWARE:
        return (uint8_t)DMTF_MEAS_TYPE_MUTABLE_FIRMWARE;   /* digest form */
    case SPDM_MEAS_KIND_SECURE_VERSION:
        return (uint8_t)(DMTF_MEAS_TYPE_SECURE_VERSION_NUM |
                         DMTF_MEAS_TYPE_RAW_BIT_STREAM_FLAG);
    case SPDM_MEAS_KIND_INFORMATIONAL:
    default:
        return (uint8_t)(DMTF_MEAS_TYPE_INFORMATIONAL |
                         DMTF_MEAS_TYPE_RAW_BIT_STREAM_FLAG);
    }
}

/* Whether a measurement belongs to the device TCB. The TCB comprises the
 * immutable ROM and the mutable firmware; the version-number and informational
 * measurements are excluded. */
static bool kind_is_tcb(spdm_meas_kind_t kind)
{
    return (kind == SPDM_MEAS_KIND_IMMUTABLE_ROM) ||
           (kind == SPDM_MEAS_KIND_MUTABLE_FIRMWARE);
}

/* Frame one measurement value into a DMTF measurement block at @buf[*off].
 * Returns false if the block would overflow @cap; on success advances @*off
 * past the new block. */
static bool frame_block(uint8_t *buf, size_t cap, size_t *off,
                        uint8_t index, uint8_t value_type,
                        const uint8_t *value, size_t value_size)
{
    dmtf_block_common_header_t common;
    dmtf_value_header_t dmtf;
    size_t need = sizeof(common) + sizeof(dmtf) + value_size;

    if ((*off > cap) || (need > (cap - *off))) {
        return false;
    }

    common.index = index;
    common.measurement_specification = DMTF_MEAS_SPEC;
    common.measurement_size = (uint16_t)(sizeof(dmtf) + value_size);
    dmtf.value_type = value_type;
    dmtf.value_size = (uint16_t)value_size;

    memcpy(buf + *off, &common, sizeof(common));
    *off += sizeof(common);
    memcpy(buf + *off, &dmtf, sizeof(dmtf));
    *off += sizeof(dmtf);
    memcpy(buf + *off, value, value_size);
    *off += value_size;
    return true;
}

/* Frame a single provider item into a DMTF measurement block. */
static bool frame_item(uint8_t *buf, size_t cap, size_t *off,
                       const spdm_meas_item_t *item)
{
    return frame_block(buf, cap, off, item->index,
                       dmtf_value_type_from_kind(item->kind),
                       item->value, item->value_size);
}

/******************************************************************************
 * Measurement record veneer
 *****************************************************************************/

__attribute__((cmse_nonsecure_entry))
nsc_meas_status_t nsc_get_measurement_record(const nsc_meas_record_params_t *params)
{
    nsc_meas_record_params_t p;
    spdm_meas_item_t items[SPDM_MEAS_ITEM_COUNT];
    size_t item_count = 0U;
    size_t off = 0U;
    size_t i;
    psa_status_t st;

    if (!ns_readable(params, sizeof(*params))) {
        return NSC_MEAS_ERROR_INVALID_ARGUMENT;
    }
    p = *params;

    if (!ns_writable(p.record_size, sizeof(*p.record_size)) ||
        !ns_writable(p.block_count, sizeof(*p.block_count)) ||
        !ns_writable(p.record, p.record_cap)) {
        return NSC_MEAS_ERROR_INVALID_ARGUMENT;
    }

    st = spdm_meas_collect(p.measurement_hash_algo, items,
                           SPDM_MEAS_ITEM_COUNT, &item_count);
    if (st != PSA_SUCCESS) {
        return (nsc_meas_status_t)st;
    }

    /* Index 0: report only the total block count, no record bytes. */
    if (p.measurement_index == MEAS_INDEX_TOTAL_COUNT) {
        *p.block_count = (uint8_t)item_count;
        *p.record_size = 0U;
        return NSC_MEAS_SUCCESS;
    }

    /* Index 0xFF: frame every block straight into the non-secure buffer. */
    if (p.measurement_index == MEAS_INDEX_ALL) {
        for (i = 0U; i < item_count; i++) {
            if (!frame_item(p.record, p.record_cap, &off, &items[i])) {
                return NSC_MEAS_ERROR_BUFFER_TOO_SMALL;
            }
        }
        *p.block_count = (uint8_t)item_count;
        *p.record_size = off;
        return NSC_MEAS_SUCCESS;
    }

    /* Single index: frame the one matching block. */
    for (i = 0U; i < item_count; i++) {
        if (items[i].index == p.measurement_index) {
            if (!frame_item(p.record, p.record_cap, &off, &items[i])) {
                return NSC_MEAS_ERROR_BUFFER_TOO_SMALL;
            }
            *p.block_count = 1U;
            *p.record_size = off;
            return NSC_MEAS_SUCCESS;
        }
    }
    return NSC_MEAS_ERROR_DOES_NOT_EXIST;
}

/******************************************************************************
 * Measurement summary hash veneer
 *****************************************************************************/

__attribute__((cmse_nonsecure_entry))
nsc_meas_status_t nsc_get_measurement_summary(const nsc_meas_summary_params_t *params)
{
    nsc_meas_summary_params_t p;
    spdm_meas_item_t items[SPDM_MEAS_ITEM_COUNT];
    uint8_t subset[MEAS_MAX_RECORD_SIZE];
    size_t item_count = 0U;
    size_t off = 0U;
    size_t produced = 0U;
    size_t i;
    psa_algorithm_t base_alg;
    size_t base_digest_size;
    psa_status_t st;

    if (!ns_readable(params, sizeof(*params))) {
        return NSC_MEAS_ERROR_INVALID_ARGUMENT;
    }
    p = *params;

    if (!ns_writable(p.summary_size, sizeof(*p.summary_size)) ||
        !ns_writable(p.summary_hash, p.summary_cap)) {
        return NSC_MEAS_ERROR_INVALID_ARGUMENT;
    }

    if ((p.summary_type != MEAS_SUMMARY_TCB) &&
        (p.summary_type != MEAS_SUMMARY_ALL)) {
        return NSC_MEAS_ERROR_INVALID_ARGUMENT;
    }

    st = summary_map_hash(p.base_hash_algo, &base_alg, &base_digest_size);
    if (st != PSA_SUCCESS) {
        return (nsc_meas_status_t)st;
    }
    if (base_digest_size > p.summary_cap) {
        return NSC_MEAS_ERROR_BUFFER_TOO_SMALL;
    }

    st = spdm_meas_collect(p.measurement_hash_algo, items,
                           SPDM_MEAS_ITEM_COUNT, &item_count);
    if (st != PSA_SUCCESS) {
        return (nsc_meas_status_t)st;
    }

    /* Concatenate the selected blocks, then hash. Framing and hashing here (in
     * the SPE) is what stops a compromised non-secure world forging the summary
     * hash it later asks the device key to sign. */
    for (i = 0U; i < item_count; i++) {
        if ((p.summary_type == MEAS_SUMMARY_ALL) || kind_is_tcb(items[i].kind)) {
            if (!frame_item(subset, sizeof(subset), &off, &items[i])) {
                return NSC_MEAS_ERROR_GENERIC;
            }
        }
    }

    st = psa_hash_compute(base_alg, subset, off, p.summary_hash,
                          p.summary_cap, &produced);
    if (st != PSA_SUCCESS) {
        return (nsc_meas_status_t)st;
    }

    *p.summary_size = produced;
    return NSC_MEAS_SUCCESS;
}

/* [] END OF FILE */
