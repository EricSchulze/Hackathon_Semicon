/*****************************************************************************
 * File Name        : nsc_sign.c
 *
 * Description      : Secure (SPE) implementation of the device-identity signing
 *                    Non-Secure-Callable (NSC) veneer for the SPDM Responder.
 *
 *                    The single veneer here lets the non-secure libspdm ask the
 *                    responder to sign a challenge / measurement transcript with
 *                    the device identity key. The wrapped private key lives in
 *                    PAS slot 0 and is only ever unwrapped, used and destroyed
 *                    inside the secure PSA crypto service (core/spdm_crypto.c).
 *                    The veneer is a hardened trust boundary: the parameter
 *                    block pointer and every buffer pointer it names are checked
 *                    with cmse_check_address_range() to prove they lie wholly in
 *                    non-secure memory with the required access before use.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <arm_cmse.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "nsc_sign.h"
#include "spdm_crypto.h"

/******************************************************************************
 * Internal helpers -- non-secure pointer validation
 *
 * cmse_check_address_range() confirms the whole [ptr, ptr+len) range is
 * non-secure and carries the requested access for the current (non-secure)
 * security state. A NULL return means the caller passed a pointer that is
 * secure, straddles the boundary, or lacks permission.
 *****************************************************************************/

static bool ns_readable(const void *ptr, size_t len)
{
    if (len == 0U) {
        return true;
    }
    return (cmse_check_address_range((void *)ptr, len,
                                     CMSE_NONSECURE | CMSE_MPU_READ) != NULL);
}

static bool ns_writable(void *ptr, size_t len)
{
    if (len == 0U) {
        return true;
    }
    return (cmse_check_address_range(ptr, len,
                                     CMSE_NONSECURE | CMSE_MPU_READWRITE) !=
            NULL);
}

/******************************************************************************
 * Device-identity signing veneer
 *****************************************************************************/

__attribute__((cmse_nonsecure_entry))
nsc_sign_status_t nsc_device_sign(const nsc_sign_params_t *params)
{
    nsc_sign_params_t p;

    if (!ns_readable(params, sizeof(*params))) {
        return NSC_SIGN_ERROR_INVALID_ARGUMENT;
    }
    p = *params;

    if (!ns_readable(p.message, p.message_size) ||
        !ns_writable(p.signature, p.signature_cap) ||
        !ns_writable(p.signature_size, sizeof(*p.signature_size))) {
        return NSC_SIGN_ERROR_INVALID_ARGUMENT;
    }

#if SPDM_HAVE_MLDSA87
    /* ML-DSA-87 device key: the message buffer is signed directly with the SPDM
     * per-op-code signing context (validated here as a non-secure read range
     * before it is handed to wolfCrypt). */
    if (!ns_readable(p.context, p.context_size)) {
        return NSC_SIGN_ERROR_INVALID_ARGUMENT;
    }
    return (nsc_sign_status_t)spdm_crypto_device_sign_mldsa87(
        p.context, p.context_size, p.message, p.message_size,
        p.signature, p.signature_cap, p.signature_size);
#elif SPDM_HAVE_ECDSA
    return (nsc_sign_status_t)spdm_crypto_device_sign(
        p.is_data_hash, p.message, p.message_size,
        p.signature, p.signature_cap, p.signature_size);
#else
#error "No device-identity signing algorithm selected for this profile"
#endif
}

/* [] END OF FILE */
