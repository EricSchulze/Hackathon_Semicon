/*****************************************************************************
 * File Name        : nsc_cert.c
 *
 * Description      : Secure (SPE) implementation of the certificate-chain read
 *                    Non-Secure-Callable (NSC) veneer for the SPDM Responder.
 *
 *                    The non-secure libspdm needs the provisioned SPDM
 *                    certificate chain to answer GET_CERTIFICATE / GET_DIGESTS.
 *                    The chain lives in a PAS certificate slot written by the
 *                    separate provisioning application as a single verbatim
 *                    SPDM cert_chain buffer. This veneer copies that public
 *                    payload out of the secure PAS flash into a non-secure
 *                    buffer. It is a hardened trust boundary: the destination
 *                    buffer and the length out-pointer are checked with
 *                    cmse_check_address_range() to prove they lie wholly in
 *                    non-secure memory with the required access before the
 *                    secure world writes to them.
 *
 *                    Only the certificate chain (public key material) crosses
 *                    the boundary here; no private key or secret is involved.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <arm_cmse.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "nsc_cert.h"
#include "pas.h"

/******************************************************************************
 * Internal helpers -- non-secure pointer validation
 *
 * cmse_check_address_range() confirms the whole [ptr, ptr+len) range is
 * non-secure and carries the requested access for the current (non-secure)
 * security state. A NULL return means the caller passed a pointer that is
 * secure, straddles the boundary, or lacks permission.
 *****************************************************************************/

static bool ns_writable(void *ptr, size_t len)
{
    if (len == 0U) {
        return true;
    }
    return (cmse_check_address_range(ptr, len,
                                     CMSE_NONSECURE | CMSE_MPU_READWRITE) !=
            NULL);
}

/******************************************************************************
 * Certificate-chain read veneer
 *****************************************************************************/

__attribute__((cmse_nonsecure_entry))
nsc_cert_status_t nsc_read_cert_chain(uint8_t slot_id, uint8_t *out,
                                      size_t out_cap, size_t *out_len)
{
    pas_slot_info_t info;
    uint32_t copied = 0U;

    if (!ns_writable(out, out_cap) ||
        !ns_writable(out_len, sizeof(*out_len))) {
        return NSC_CERT_ERROR_INVALID_ARGUMENT;
    }

    if (pas_slot_query(slot_id, &info) != PAS_OK) {
        return NSC_CERT_ERROR_DOES_NOT_EXIST;
    }
    if (!info.valid || (info.type != SLOT_TYPE_CERT) || (info.payload_len == 0U)) {
        return NSC_CERT_ERROR_DOES_NOT_EXIST;
    }
    if (info.payload_len > out_cap) {
        return NSC_CERT_ERROR_BUFFER_TOO_SMALL;
    }

    if (pas_slot_read(slot_id, 0U, out, info.payload_len, &copied) != PAS_OK) {
        return NSC_CERT_ERROR_DOES_NOT_EXIST;
    }

    *out_len = (size_t)copied;
    return NSC_CERT_SUCCESS;
}

/* [] END OF FILE */
