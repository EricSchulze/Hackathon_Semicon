/*****************************************************************************
 * File Name        : nsc.c
 *
 * Description      : Secure (SPE) implementation of the boundary-wide SPDM
 *                    Responder Non-Secure-Callable (NSC) veneers.
 *
 *                    This file holds the veneers that are not tied to any single
 *                    crypto family -- currently just the ABI version query used
 *                    by the non-secure world to confirm the secure image is
 *                    present and both halves agree on the veneer ABI. It also
 *                    guarantees the secure image exports at least one gateway so
 *                    the GCC import-library link step succeeds even before the
 *                    domain-specific veneers are compiled in. The PSA-shaped
 *                    crypto veneers live in nsc_psa.c; the device-key sign and
 *                    cert-chain read veneers are added in a later stage.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <arm_cmse.h>
#include <stdint.h>

#include "nsc.h"

/******************************************************************************
 * Non-Secure-Callable Veneers
 *****************************************************************************/

/**
 * @brief Return the version of the SPDM Responder NSC boundary ABI.
 *
 * See nsc.h for the contract. The cmse_nonsecure_entry attribute makes this a
 * Non-Secure-Callable gateway; the linker records it in the secure gateway
 * veneer table and exports it through the import library.
 */
__attribute__((cmse_nonsecure_entry))
uint32_t nsc_get_abi_version(void)
{
    return NSC_ABI_VERSION;
}

/* [] END OF FILE */
