/*****************************************************************************
 * File Name        : nsc_psa.c
 *
 * Description      : Secure (SPE) implementation of the PSA-shaped SPDM
 *                    Responder Non-Secure-Callable (NSC) crypto veneers.
 *
 *                    This stage implements the PSA-shaped crypto veneers (RNG, a
 *                    generic multipart hash, a one-call AES-GCM AEAD and the
 *                    ephemeral ECDHE P-256 key agreement) that back the
 *                    non-secure libspdm cryptlib. Each veneer is a
 *                    hardened trust boundary: every pointer supplied by the
 *                    non-secure caller is checked with cmse_check_address_range()
 *                    to prove it lies wholly in non-secure memory with the
 *                    required access before it is dereferenced, and hash and EC
 *                    operations are referenced only by opaque pool handles
 *                    (never secure pointers). The actual cryptography runs in
 *                    the secure PSA crypto service (core/spdm_crypto.c).
 *                    HMAC-SHA256 and HKDF-SHA256 are built in the non-secure
 *                    world on top of the generic hash veneers, so they are not
 *                    veneers here. The device-identity ECDSA sign veneer lives
 *                    in nsc_sign.c; the boundary-wide ABI version veneer lives
 *                    in nsc.c.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <arm_cmse.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "nsc_psa.h"
#include "spdm_crypto.h"

/******************************************************************************
 * Internal helpers -- non-secure pointer validation
 *
 * cmse_check_address_range() confirms the whole [ptr, ptr+len) range is
 * non-secure and carries the requested access permission for the current
 * (non-secure) security state. A NULL return means the caller passed a pointer
 * that is secure, straddles the boundary, or lacks permission -- in every such
 * case the veneer must refuse to touch the memory.
 *****************************************************************************/

static bool ns_readable(const void *ptr, size_t len)
{
    if (len == 0U) {
        return true;
    }
    return (cmse_check_address_range((void *)ptr, len,
                                     CMSE_NONSECURE | CMSE_MPU_READ) != NULL);
}

static bool ns_writable(void *ptr, size_t len)
{
    if (len == 0U) {
        return true;
    }
    return (cmse_check_address_range(ptr, len,
                                     CMSE_NONSECURE | CMSE_MPU_READWRITE) !=
            NULL);
}

/******************************************************************************
 * Random number generation -- mirrors psa_generate_random()
 *****************************************************************************/

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_generate_random(uint8_t *output, size_t output_size)
{
    if (!ns_writable(output, output_size)) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    return (nsc_psa_status_t)spdm_crypto_generate_random(output, output_size);
}

/*---------------------------------------------------------------------------
 * Multipart hash -- mirrors the psa_hash_* API
 *
 * Operation handles are plain integers validated by the secure service (a
 * hostile handle can only select a pool slot), so they are not pointer-checked
 * here; only the out-handle and the data/digest buffers are validated.
 *-------------------------------------------------------------------------*/

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_hash_setup(nsc_psa_hash_op_t *op,
                                    nsc_psa_algorithm_t alg)
{
    spdm_crypto_hash_op_t sop;
    psa_status_t st;

    if (!ns_writable(op, sizeof(*op))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    st = spdm_crypto_hash_setup(&sop, (psa_algorithm_t)alg);
    *op = (nsc_psa_hash_op_t)sop;
    return (nsc_psa_status_t)st;
}

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_hash_update(nsc_psa_hash_op_t op,
                                     const uint8_t *input, size_t input_size)
{
    if (!ns_readable(input, input_size)) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    return (nsc_psa_status_t)spdm_crypto_hash_update(
        (spdm_crypto_hash_op_t)op, input, input_size);
}

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_hash_finish(nsc_psa_hash_op_t op, uint8_t *hash,
                                     size_t hash_size, size_t *hash_length)
{
    if (!ns_writable(hash, hash_size) ||
        !ns_writable(hash_length, sizeof(*hash_length))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    return (nsc_psa_status_t)spdm_crypto_hash_finish(
        (spdm_crypto_hash_op_t)op, hash, hash_size, hash_length);
}

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_hash_clone(nsc_psa_hash_op_t src,
                                    nsc_psa_hash_op_t *dst)
{
    spdm_crypto_hash_op_t sdst;
    psa_status_t st;

    if (!ns_writable(dst, sizeof(*dst))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    st = spdm_crypto_hash_clone((spdm_crypto_hash_op_t)src, &sdst);
    *dst = (nsc_psa_hash_op_t)sdst;
    return (nsc_psa_status_t)st;
}

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_hash_abort(nsc_psa_hash_op_t op)
{
    return (nsc_psa_status_t)spdm_crypto_hash_abort((spdm_crypto_hash_op_t)op);
}

/*---------------------------------------------------------------------------
 * AES-GCM AEAD (one call per record)
 *
 * A GCM record has more operands than the four core registers a gateway may
 * use, so they arrive in a single parameter block passed by pointer. The block
 * pointer is validated, copied into secure memory (so the non-secure side
 * cannot mutate the fields between check and use), and then each buffer pointer
 * it names is validated before the secure service touches it.
 *-------------------------------------------------------------------------*/

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_aead_encrypt(const nsc_psa_aead_encrypt_params_t *params)
{
    nsc_psa_aead_encrypt_params_t p;
    size_t out_cap;

    if (!ns_readable(params, sizeof(*params))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    p = *params;

    if (!ns_readable(p.key, p.key_size) || !ns_readable(p.iv, p.iv_size) ||
        !ns_readable(p.a_data, p.a_data_size) ||
        !ns_readable(p.data_in, p.data_in_size) ||
        !ns_writable(p.tag_out, p.tag_size) ||
        !ns_writable(p.data_out, p.data_in_size) ||
        !ns_writable(p.data_out_size, sizeof(*p.data_out_size))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }

    /* data_out_size is in/out: honour the caller-supplied output capacity. */
    out_cap = *p.data_out_size;
    if (out_cap < p.data_in_size) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }

    return (nsc_psa_status_t)spdm_crypto_aead_encrypt(
        p.key, p.key_size, p.iv, p.iv_size, p.a_data, p.a_data_size,
        p.data_in, p.data_in_size, p.tag_out, p.tag_size, p.data_out,
        p.data_out_size);
}

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_aead_decrypt(const nsc_psa_aead_decrypt_params_t *params)
{
    nsc_psa_aead_decrypt_params_t p;
    size_t out_cap;

    if (!ns_readable(params, sizeof(*params))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    p = *params;

    if (!ns_readable(p.key, p.key_size) || !ns_readable(p.iv, p.iv_size) ||
        !ns_readable(p.a_data, p.a_data_size) ||
        !ns_readable(p.data_in, p.data_in_size) ||
        !ns_readable(p.tag, p.tag_size) ||
        !ns_writable(p.data_out, p.data_in_size) ||
        !ns_writable(p.data_out_size, sizeof(*p.data_out_size))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }

    out_cap = *p.data_out_size;
    if (out_cap < p.data_in_size) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }

    return (nsc_psa_status_t)spdm_crypto_aead_decrypt(
        p.key, p.key_size, p.iv, p.iv_size, p.a_data, p.a_data_size,
        p.data_in, p.data_in_size, p.tag, p.tag_size, p.data_out,
        p.data_out_size);
}

#if SPDM_HAVE_ECDHE
/*---------------------------------------------------------------------------
 * Ephemeral ECDHE (P-256/P-384/P-521) key agreement
 *
 * EC context handles are plain integers validated by the secure service (a
 * hostile handle can only select a pool slot), so only out-handles and buffers
 * are pointer-checked here. compute()'s operands exceed the four-register CMSE
 * limit, so they arrive in a parameter block passed by pointer, validated and
 * copied into secure memory before use.
 *-------------------------------------------------------------------------*/

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_ec_new(nsc_psa_ec_op_t *op)
{
    spdm_crypto_ec_op_t sop;
    psa_status_t st;

    if (!ns_writable(op, sizeof(*op))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    st = spdm_crypto_ec_new(&sop);
    *op = (nsc_psa_ec_op_t)sop;
    return (nsc_psa_status_t)st;
}

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_ec_generate(nsc_psa_ec_op_t op, uint8_t *public_key,
                                     size_t public_key_cap,
                                     size_t *public_key_size)
{
    if (!ns_writable(public_key, public_key_cap) ||
        !ns_writable(public_key_size, sizeof(*public_key_size))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    return (nsc_psa_status_t)spdm_crypto_ec_generate(
        (spdm_crypto_ec_op_t)op, public_key, public_key_cap, public_key_size);
}

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_ec_compute(const nsc_psa_ec_compute_params_t *params)
{
    nsc_psa_ec_compute_params_t p;

    if (!ns_readable(params, sizeof(*params))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    p = *params;

    if (!ns_readable(p.peer_public, p.peer_public_size) ||
        !ns_writable(p.secret, p.secret_cap) ||
        !ns_writable(p.secret_size, sizeof(*p.secret_size))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }

    return (nsc_psa_status_t)spdm_crypto_ec_compute(
        (spdm_crypto_ec_op_t)p.op, p.peer_public, p.peer_public_size,
        p.secret, p.secret_cap, p.secret_size);
}

__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_ec_free(nsc_psa_ec_op_t op)
{
    return (nsc_psa_status_t)spdm_crypto_ec_free((spdm_crypto_ec_op_t)op);
}
#endif /* SPDM_HAVE_ECDHE */

#if SPDM_HAVE_MLKEM1024
__attribute__((cmse_nonsecure_entry))
nsc_psa_status_t nsc_psa_mlkem_encapsulate(
    const nsc_psa_mlkem_encapsulate_params_t *params)
{
    nsc_psa_mlkem_encapsulate_params_t p;

    if (!ns_readable(params, sizeof(*params))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }
    p = *params;

    if (!ns_readable(p.peer_encap_key, p.peer_encap_key_size) ||
        !ns_writable(p.cipher_text, p.cipher_text_cap) ||
        !ns_writable(p.cipher_text_size, sizeof(*p.cipher_text_size)) ||
        !ns_writable(p.shared_secret, p.shared_secret_cap) ||
        !ns_writable(p.shared_secret_size, sizeof(*p.shared_secret_size))) {
        return NSC_PSA_ERROR_INVALID_ARGUMENT;
    }

    return (nsc_psa_status_t)spdm_crypto_mlkem_encapsulate(
        p.peer_encap_key, p.peer_encap_key_size,
        p.cipher_text, p.cipher_text_cap, p.cipher_text_size,
        p.shared_secret, p.shared_secret_cap, p.shared_secret_size);
}
#endif /* SPDM_HAVE_MLKEM1024 */

/* [] END OF FILE */
