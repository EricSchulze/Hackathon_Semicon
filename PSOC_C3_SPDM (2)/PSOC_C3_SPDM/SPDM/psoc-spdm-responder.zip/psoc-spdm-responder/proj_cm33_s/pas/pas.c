/*****************************************************************************
 * File Name        : pas.c
 *
 * Description      : READ-ONLY Provisioning Asset Store (PAS) accessor for the
 *                    SPDM Responder secure application. Implements slot
 *                    discovery, CRC validation and payload reads by direct
 *                    dereference of the secure S-bus flash alias.
 *
 *                    No flash-program driver, PPC re-partitioning, store header
 *                    or freeze record is used here: the store is provisioned by
 *                    the separate provisioning application and is only read.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#include "pas.h"

#include <stddef.h>
#include <string.h>

/******************************************************************************
 * Internal macros
 *****************************************************************************/

/** Minimum of two values. */
#define PAS_MIN(a, b)   ((a) < (b) ? (a) : (b))

/** Maximum number of slots this module supports (bounds s_slot_start_row[]). */
#define PAS_SLOTS_MAX   8u

/** First region row available for slots (rows 0 and 1 are reserved by the
 *  provisioning application for the store header and freeze record, which this
 *  read-only accessor never touches). */
#define PAS_FIRST_SLOT_ROW  2u

/******************************************************************************
 * Slot row table (derived from PAS_SLOT_ROWS_INIT at compile time)
 *****************************************************************************/

/* Per-slot row counts, one entry per slot.  Must match the geometry the
 * provisioning application used. PAS_NUM_SLOTS is derived from the length. */
static const uint8_t pas_slot_rows[] = PAS_SLOT_ROWS_INIT;

#define PAS_NUM_SLOTS   ((uint8_t)(sizeof(pas_slot_rows) / sizeof(pas_slot_rows[0])))

_Static_assert(PAS_NUM_SLOTS <= PAS_SLOTS_MAX,
               "PAS: PAS_SLOT_ROWS_INIT defines more slots than this PAS "
               "version supports (PAS_SLOTS_MAX = 8).");

/* Derived: PAS_SLOT_SIZE(i) = number of bytes in slot i. */
#define PAS_SLOT_SIZE(i)  ((uint32_t)pas_slot_rows[(i)] * PAS_FLASH_ROW_SIZE)

/******************************************************************************
 * Module state
 *****************************************************************************/

/* Precomputed start-row index for each slot (row relative to PAS_BASE_ADDR).
 * Populated by pas_init(). */
static uint8_t s_slot_start_row[PAS_SLOTS_MAX];

/******************************************************************************
 * CRC-32 (ISO-HDLC / IEEE 802.3, poly 0xEDB88320)
 *****************************************************************************/

static uint32_t crc32_step(uint32_t crc, const void *data, uint32_t len)
{
    const uint8_t *p = (const uint8_t *)data;
    while (len--)
    {
        uint8_t byte = *p++;
        crc ^= (uint32_t)byte;
        for (int i = 0; i < 8; i++)
        {
            crc = (crc & 1u) ? ((crc >> 1) ^ 0xEDB88320u) : (crc >> 1);
        }
    }
    return crc;
}

/** Compute CRC-32 over two non-contiguous blocks (header fields + payload). */
static uint32_t crc32_compute2(const void *a, uint32_t alen,
                               const void *b, uint32_t blen)
{
    uint32_t ctx = crc32_step(0xFFFFFFFFu, a, alen);
    ctx = crc32_step(ctx, b, blen);
    return ctx ^ 0xFFFFFFFFu;
}

/******************************************************************************
 * Address helpers
 *****************************************************************************/

/** Byte address of the PAS region row at index @p row. */
static inline uint32_t pas_row_addr(uint8_t row)
{
    return PAS_BASE_ADDR + ((uint32_t)row * PAS_FLASH_ROW_SIZE);
}

/** Byte address of the start of slot @p slot (first byte of slot_hdr_t). */
static inline uint32_t pas_slot_addr(uint8_t slot)
{
    return pas_row_addr(s_slot_start_row[slot]);
}

/******************************************************************************
 * Slot validity predicate (internal)
 *****************************************************************************/

/**
 * Return the slot's type if its header is present and its CRC verifies,
 * otherwise SLOT_TYPE_FREE.
 *
 * The CRC covers:
 *   bytes[0..offsetof(slot_hdr_t,crc32)-1]  (16 bytes of header fields)
 *   followed by the payload bytes            (read directly from flash)
 */
static slot_type_t pas_slot_get_type(uint8_t slot)
{
    const slot_hdr_t *hdr = (const slot_hdr_t *)pas_slot_addr(slot);

    /* Erased slot. */
    if (hdr->slot_magic == SLOT_MAGIC_FREE) { return SLOT_TYPE_FREE; }

    /* Determine expected type from magic. */
    slot_type_t type;
    if      (hdr->slot_magic == SLOT_MAGIC_KEY)  { type = SLOT_TYPE_KEY;  }
    else if (hdr->slot_magic == SLOT_MAGIC_CERT) { type = SLOT_TYPE_CERT; }
    else { return SLOT_TYPE_FREE; }   /* unknown magic */

    /* Validate payload length fits within slot. */
    uint32_t capacity = PAS_SLOT_SIZE(slot);
    if (hdr->payload_len > capacity - sizeof(slot_hdr_t)) { return SLOT_TYPE_FREE; }

    /* Verify CRC over header prefix + payload (both read directly from flash). */
    const uint8_t *payload = (const uint8_t *)hdr + sizeof(slot_hdr_t);
    uint32_t crc = crc32_compute2(hdr, offsetof(slot_hdr_t, crc32),
                                  payload, hdr->payload_len);
    if (crc != hdr->crc32) { return SLOT_TYPE_FREE; }

    return type;
}

/******************************************************************************
 * Public API — pas_init
 *****************************************************************************/

pas_status_t pas_init(void)
{
    /* ------------------------------------------------------------------
     * 1. Geometry validation (build-time configuration check).
     * ------------------------------------------------------------------ */
    if ((PAS_BASE_ADDR % PAS_FLASH_ROW_SIZE) != 0u)
    {
        return PAS_ERR_PARAM;   /* base address not row-aligned */
    }

    /* Verify: 2 (header + freeze) + sum(pas_slot_rows) <= PAS_REGION_ROWS. */
    uint32_t total_rows = PAS_FIRST_SLOT_ROW;
    for (uint8_t i = 0u; i < PAS_NUM_SLOTS; i++)
    {
        total_rows += pas_slot_rows[i];
    }
    if (total_rows > PAS_REGION_ROWS)
    {
        return PAS_ERR_PARAM;   /* slot row budget exceeds region size */
    }

    /* ------------------------------------------------------------------
     * 2. Build the per-slot start-row table (prefix sum).
     * ------------------------------------------------------------------ */
    uint8_t row = PAS_FIRST_SLOT_ROW;
    for (uint8_t i = 0u; i < PAS_NUM_SLOTS; i++)
    {
        s_slot_start_row[i] = row;
        row = (uint8_t)(row + pas_slot_rows[i]);
    }

    return PAS_OK;
}

/******************************************************************************
 * Public API — geometry queries
 *****************************************************************************/

uint32_t pas_slot_count(void)
{
    return (uint32_t)PAS_NUM_SLOTS;
}

uint32_t pas_slot_size(uint8_t slot)
{
    if (slot >= PAS_NUM_SLOTS) { return 0u; }
    return PAS_SLOT_SIZE(slot);
}

/******************************************************************************
 * Public API — slot query
 *****************************************************************************/

pas_status_t pas_slot_query(uint8_t slot, pas_slot_info_t *out)
{
    if (slot >= PAS_NUM_SLOTS) { return PAS_ERR_NO_SLOT; }
    if (out == NULL)           { return PAS_ERR_PARAM;   }

    slot_type_t type = pas_slot_get_type(slot);

    /* Read the slot header directly from flash. */
    const slot_hdr_t *hdr = (const slot_hdr_t *)pas_slot_addr(slot);
    bool valid = (type != SLOT_TYPE_FREE) && (hdr->slot_magic != SLOT_MAGIC_FREE);

    out->type        = type;
    out->slot_id     = slot;
    out->assoc_slot  = valid ? hdr->assoc_slot   : SLOT_ASSOC_NONE;
    out->alg_id      = valid ? hdr->alg_id       : 0u;
    out->payload_len = valid ? hdr->payload_len  : 0u;
    out->valid       = valid;

    return PAS_OK;
}

/******************************************************************************
 * Public API — slot read
 *****************************************************************************/

pas_status_t pas_slot_read(uint8_t slot, uint32_t off,
                           void *buf, uint32_t len, uint32_t *ret)
{
    if (slot >= PAS_NUM_SLOTS)      { return PAS_ERR_NO_SLOT;   }
    if (buf == NULL || ret == NULL) { return PAS_ERR_PARAM;     }

    slot_type_t type = pas_slot_get_type(slot);
    if (type == SLOT_TYPE_FREE)     { return PAS_ERR_SLOT_TYPE; }

    /* Read the slot header directly from flash. */
    const slot_hdr_t *hdr = (const slot_hdr_t *)pas_slot_addr(slot);
    uint32_t payload_len = hdr->payload_len;

    if (off >= payload_len)         { return PAS_ERR_LENGTH;    }

    uint32_t available = payload_len - off;
    uint32_t to_read   = PAS_MIN(len, available);

    const uint8_t *payload =
        (const uint8_t *)hdr + sizeof(slot_hdr_t) + off;
    memcpy(buf, payload, to_read);
    *ret = to_read;

    return PAS_OK;
}

/* [] END OF FILE */
