/*****************************************************************************
 * File Name        : pas.h
 *
 * Description      : READ-ONLY Provisioning Asset Store (PAS) accessor for the
 *                    SPDM Responder secure application.
 *
 *                    The device identity key (slot 0) and SPDM certificate
 *                    chain (slot 1) are written to the PAS by the SEPARATE
 *                    provisioning application. This module is a read-only
 *                    consumer: it locates, validates (CRC) and reads slot
 *                    payloads. It deliberately provides NO write / erase /
 *                    freeze API and pulls in no flash-program driver — the
 *                    SPDM Responder never mutates the store.
 *
 *                    Slots are read by direct dereference of the secure S-bus
 *                    flash alias (see pas_config.h). Reads are safe because the
 *                    consumed slots are always provisioned before the SPDM
 *                    Responder runs; a never-programmed flash row can raise an
 *                    ECC bus fault, so only provisioned slots are accessed.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef PAS_H
#define PAS_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "pas_config.h"

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Flash geometry constants
 *****************************************************************************/

/** Minimum erase/program unit on PSoC Control C3 (512 B). */
#define PAS_FLASH_ROW_SIZE  512u

/** PAS on-flash structure version.  Must match the provisioning application. */
#define PAS_VERSION         0x0003u

/** Derived region size in bytes. */
#define PAS_REGION_SIZE     ((uint32_t)PAS_REGION_ROWS * PAS_FLASH_ROW_SIZE)

/******************************************************************************
 * Slot magic values  (role of a slot)
 *****************************************************************************/

/** Slot is erased / unassigned (flash-erase state reads as 0x00 on this device). */
#define SLOT_MAGIC_FREE     0x00000000u
/** Slot holds a key pair or symmetric key ("_KEY"). */
#define SLOT_MAGIC_KEY      0x5F4B4559u
/** Slot holds a certificate ("CERT"). */
#define SLOT_MAGIC_CERT     0x43455254u

/** assoc_slot value when there is no binding to another slot. */
#define SLOT_ASSOC_NONE     0xFFu

/******************************************************************************
 * Enumerations
 *****************************************************************************/

/** Runtime role of a slot, derived from slot_magic. */
typedef enum {
    SLOT_TYPE_FREE = 0x00,  /**< Unassigned (erased)                          */
    SLOT_TYPE_KEY  = 0x01,  /**< Holds a key pair (or symmetric key)          */
    SLOT_TYPE_CERT = 0x02   /**< Holds a certificate, bound to a key slot     */
} slot_type_t;

/**
 * PAS accessor status codes.
 *
 * Only read-relevant codes are defined; the mutating codes used by the
 * provisioning application (PAS_ERR_FROZEN, PAS_ERR_FLASH) are intentionally
 * absent because this consumer never writes.
 */
typedef enum {
    PAS_OK           = 0,   /**< Success                                      */
    PAS_ERR_NO_SLOT,        /**< Slot index out of range                      */
    PAS_ERR_SLOT_TYPE,      /**< Slot empty or its header/CRC is invalid      */
    PAS_ERR_CRC,            /**< Slot CRC mismatch                            */
    PAS_ERR_LENGTH,         /**< Offset exceeds slot payload length           */
    PAS_ERR_PARAM           /**< Malformed argument / bad geometry            */
} pas_status_t;

/******************************************************************************
 * On-flash structures
 *****************************************************************************/

/**
 * Common header at the start of every slot (row-aligned within the slot's
 * allocated rows).  A slot is PRESENT/VALID iff slot_magic is a known type AND
 * crc32 verifies over the first 16 bytes of this struct + payload.
 *
 * This layout MUST match the provisioning application byte-for-byte.
 */
typedef struct {
    uint32_t slot_magic;    /**< SLOT_MAGIC_KEY | _CERT | _FREE               */
    uint16_t pas_version;   /**< PAS_VERSION                                  */
    uint8_t  slot_id;       /**< This slot's index (0..pas_slot_count()-1)    */
    uint8_t  assoc_slot;    /**< Bound slot id (e.g. cert->key); SLOT_ASSOC_NONE */
    uint16_t alg_id;        /**< Caller tag (crypto suite id); 0 if unused    */
    uint16_t reserved;      /**< Must be 0                                    */
    uint32_t payload_len;   /**< Bytes of payload following this header       */
    uint32_t crc32;         /**< CRC-32 over bytes[0..15] + payload           */
} slot_hdr_t;

/******************************************************************************
 * Runtime slot descriptor (not stored on flash)
 *****************************************************************************/

/**
 * Filled by pas_slot_query().  Captures the slot role, binding and validity
 * derived live from the slot_hdr_t in flash.
 */
typedef struct {
    slot_type_t type;       /**< FREE / KEY / CERT (from slot_magic)          */
    uint8_t     slot_id;    /**< Slot index                                   */
    uint8_t     assoc_slot; /**< Binding (e.g. cert->key); SLOT_ASSOC_NONE    */
    uint16_t    alg_id;     /**< Caller tag                                   */
    uint32_t    payload_len;/**< Stored payload length                        */
    bool        valid;      /**< magic present AND crc32 verifies             */
} pas_slot_info_t;

/******************************************************************************
 * PAS accessor API (read-only)
 *****************************************************************************/

/**
 * @brief Initialize the read-only PAS accessor.
 *
 * Validates the build-time geometry (base-address alignment and row budget)
 * and builds the per-slot start-row table.  Performs no flash access — the
 * store is provisioned externally and only read here.
 *
 * Must be called once from secure main() before any other PAS function.
 *
 * @return PAS_OK on success, or PAS_ERR_PARAM if the geometry is invalid
 *         (base address not row-aligned, or slot rows exceed the region).
 */
pas_status_t pas_init(void);

/**
 * @brief Return the number of configured slots.
 *
 * @return Number of slots (always >= 1).
 */
uint32_t pas_slot_count(void);

/**
 * @brief Return the size in bytes of an individual slot.
 *
 * @param slot  Slot index (0..pas_slot_count()-1).
 * @return Slot size in bytes, or 0 if slot is out of range.
 */
uint32_t pas_slot_size(uint8_t slot);

/**
 * @brief Query a slot's current role and validity without copying payload.
 *
 * All fields are derived live from the slot_hdr_t in flash.
 *
 * @param slot  Slot index.
 * @param out   Filled with the slot descriptor on success.
 * @return PAS_OK, PAS_ERR_NO_SLOT, or PAS_ERR_PARAM.
 */
pas_status_t pas_slot_query(uint8_t slot, pas_slot_info_t *out);

/**
 * @brief Read bytes from the payload of a slot.
 *
 * The slot must be PRESENT/VALID.  Offset is relative to the start of the
 * payload (i.e. after slot_hdr_t).
 *
 * @param slot  Slot index.
 * @param off   Byte offset into the payload.
 * @param buf   Destination buffer.
 * @param len   Maximum bytes to read.
 * @param ret   Actual bytes copied (may be less than len near end of payload).
 * @return PAS_OK, PAS_ERR_NO_SLOT, PAS_ERR_SLOT_TYPE (slot empty/CRC bad),
 *         PAS_ERR_LENGTH (offset >= payload_len), or PAS_ERR_PARAM.
 */
pas_status_t pas_slot_read(uint8_t slot, uint32_t off,
                           void *buf, uint32_t len, uint32_t *ret);

#if defined(__cplusplus)
}
#endif

#endif /* PAS_H */

/* [] END OF FILE */
