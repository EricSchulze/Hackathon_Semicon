/*****************************************************************************
* File Name        : ppc_config.h
*
* Description      : Peripheral Protection Controller (PPC) configuration for
*                    the secure CM33 SPDM Responder application.
*
*                    config_ppc() partitions the peripherals into secure and
*                    non-secure worlds at start-up. In this baseline stage the
*                    peripherals the non-secure world needs -- notably the
*                    debug UART SCB used for logging -- are placed in the
*                    non-secure world so the NS app can drive them directly.
*
*                    The cryptographic accelerator (MXCRYPTOLITE) and TRNG are
*                    left at their secure reset default and are formally locked
*                    secure-only in a later stage, when the secure PSA crypto
*                    service is added.
*
*******************************************************************************
* (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
* Technologies AG. All rights reserved.
* This software, associated documentation and materials ("Software") is
* owned by Infineon Technologies AG or one of its affiliates ("Infineon")
* and is protected by and subject to worldwide patent protection, worldwide
* copyright laws, and international treaty provisions. Therefore, you may use
* this Software only as provided in the license agreement accompanying the
* software package from which you obtained this Software. If no license
* agreement applies, then any use, reproduction, modification, translation, or
* compilation of this Software is prohibited without the express written
* permission of Infineon.
*
* Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
* IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
* THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
* SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
* Infineon reserves the right to make changes to the Software without notice.
* You are responsible for properly designing, programming, and testing the
* functionality and safety of your intended application of the Software, as
* well as complying with any legal requirements related to its use. Infineon
* does not guarantee that the Software will be free from intrusion, data theft
* or loss, or other breaches ("Security Breaches"), and Infineon shall have
* no liability arising out of any Security Breaches. Unless otherwise
* explicitly approved by Infineon, the Software may not be used in any
* application where a failure of the Product or any consequences of the use
* thereof can reasonably be expected to result in personal injury.
*****************************************************************************/

#ifndef PPC_CONFIG_H
#define PPC_CONFIG_H

#include "cy_ppc.h"

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * @brief Configure PPC.
 *
 * Partitions the peripherals into secure and non-secure worlds. Resources the
 * non-secure world uses (including the debug UART SCB for logging) are placed
 * non-secure; the flash controller and the cryptographic accelerator / TRNG
 * are left at their secure reset default (they are not accessed by either world
 * in this baseline stage and are formally locked secure-only later, when the
 * secure crypto service is introduced).
 *
 * @return The status cy_en_ppc_status_t.
 */
cy_en_ppc_status_t config_ppc(void);

#if defined(__cplusplus)
}
#endif

#endif /* PPC_CONFIG_H */

/* [] END OF FILE */
