/*****************************************************************************
 * File Name        : spdm_psa_crypto_config.h
 *
 * Description      : Project PSA-Crypto configuration for the secure SPDM
 *                    crypto service -- FULL REPLACEMENT of the Infineon PSA
 *                    capability base config.
 *
 *                    Selected via MBEDTLS_PSA_CRYPTO_CONFIG_FILE (set inside the
 *                    companion spdm_mbedtls_config.h), so it REPLACES the vendor
 *                    PSA config (target/.../psc3/psc3_crypto_config.h). Only the
 *                    PSA_WANT_* features declared here are compiled, which keeps
 *                    the secure image small: the IFX PSA base config otherwise
 *                    enables RSA, FFDH, every curve, all hash families and every
 *                    cipher, none of which the SPDM responder crypto suite uses.
 *
 *                    The SPDM Responder negotiates a single cipher suite per
 *                    profile:
 *                      - ECDSA / ECDHE over a NIST curve (P-256, P-384 or P-521)
 *                      - SHA-256 / SHA-384 / SHA-512 (per the profile hash)
 *                      - AES-256-GCM
 *                      - HKDF (SPDM session key schedule)
 *                    matching spdm_lib_config_psc3.h in the non-secure project.
 *
 *                    The Infineon accelerator (cy-mbedtls-acceleration) derives
 *                    its own per-feature configuration from these same PSA_WANT_*
 *                    switches. What actually ends up hardware accelerated versus
 *                    running in mbedTLS software is device-dependent and is
 *                    documented in one place -- docs/implementation.md (Crypto
 *                    backend) -- with the P-521-sign software-fallback mechanism
 *                    in the CryptoLite config headers
 *                    (config/spdm_cryptolite_config_v3.h and
 *                    platforms/PSC3M5/config/spdm_cryptolite_config.h).
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef PSA_CRYPTO_CONFIG_SPDM_H
#define PSA_CRYPTO_CONFIG_SPDM_H

/* SPDM_HAVE_* capability flags for the selected profile (profiles/<name>). */
#include "profile.h"

/******************************************************************************
 * Hash: SHA-256.
 *
 * Used directly for the SPDM transcript hash and, through the secure crypto
 * service, as the building block for HMAC-SHA256 and HKDF-SHA256.
 *****************************************************************************/
#define PSA_WANT_ALG_SHA_256                    1

/******************************************************************************
 * Hash: SHA-384 (profiles whose base/measurement hash is SHA-384).
 *
 * These profiles negotiate SHA-384 for the SPDM 1.4 transcript /
 * measurement hash and the session key schedule. libspdm (non-secure) computes
 * these hashes through the secure crypto service (the multipart-hash veneer),
 * so the SPE must be able to run SHA-384. MXCRYPTOLITE only accelerates
 * SHA-256, so SHA-384 falls back to the mbedTLS software implementation
 * (PSA_WANT_ALG_SHA_384 auto-enables MBEDTLS_SHA384_C / MBEDTLS_SHA512_C).
 *****************************************************************************/
#if SPDM_HAVE_SHA384
#define PSA_WANT_ALG_SHA_384                    1
#endif

/******************************************************************************
 * Hash: SHA-512 (profiles whose base/measurement hash is SHA-512).
 *
 * The P-521 ECC profile negotiates SHA-512 for the SPDM transcript /
 * measurement hash and the session key schedule; libspdm computes these hashes
 * through the secure multipart-hash veneer, so the SPE must run SHA-512.
 * MXCRYPTOLITE does not accelerate it, so it falls back to the mbedTLS software
 * implementation (SHA-384 already pulls in MBEDTLS_SHA512_C).
 *****************************************************************************/
#if SPDM_HAVE_SHA512
#define PSA_WANT_ALG_SHA_512                    1
#endif

/******************************************************************************
 * HMAC-SHA256 / HKDF-SHA256.
 *
 * The SPDM session key schedule (spdm_secured_message_lib) is HMAC/HKDF based.
 * The secure crypto service implements HMAC and HKDF on top of the SHA-256
 * primitive, but the PSA HMAC key type / algorithm are still declared so the
 * MXCRYPTOLITE driver and any PSA-internal use remain available.
 *****************************************************************************/
#define PSA_WANT_ALG_HMAC                       1
#define PSA_WANT_ALG_HKDF                       1
#define PSA_WANT_KEY_TYPE_HMAC                  1

/******************************************************************************
 * ECDSA / ECDHE over NIST P-256 / P-384 / P-521.
 *
 * ECDSA signs the SPDM CHALLENGE_AUTH / KEY_EXCHANGE_RSP / FINISH transcripts
 * with the device identity key (PAS slot 0). ECDH performs the ephemeral
 * key agreement for the SPDM secure session. The curve(s) are fixed by the
 * active profile. Randomised ECDSA only (see the header note about MXCRYPTOLITE
 * acceleration).
 *
 * Each PSA_WANT_* follows the specific capability that needs it, so a profile
 * that mixes a PQ primitive with a traditional one (e.g. ML-DSA-87 sign + ECDHE
 * P-256 KEX, or ECDSA sign + ML-KEM-1024 KEX) compiles only the half it uses;
 * a pure-PQ profile drops the EC path entirely. Each NIST curve is enabled by
 * whichever ECDSA/ECDHE capability selects it.
 *****************************************************************************/

/* Per-curve support, enabled if either the signature or the key-exchange path
 * uses that curve. */
#if SPDM_HAVE_ECDSA_P256 || SPDM_HAVE_ECDHE_P256
#define PSA_WANT_ECC_SECP_R1_256                1
#endif
#if SPDM_HAVE_ECDSA_P384 || SPDM_HAVE_ECDHE_P384
#define PSA_WANT_ECC_SECP_R1_384                1
#endif
#if SPDM_HAVE_ECDSA_P521 || SPDM_HAVE_ECDHE_P521
#define PSA_WANT_ECC_SECP_R1_521                1
#endif

/* Shared EC machinery (key-pair object support), needed by either the
 * signature or the key-exchange path on any NIST curve. */
#if SPDM_HAVE_ECDSA || SPDM_HAVE_ECDHE
#define PSA_WANT_KEY_TYPE_ECC_KEY_PAIR_BASIC    1
#define PSA_WANT_KEY_TYPE_ECC_KEY_PAIR_EXPORT   1
#define PSA_WANT_KEY_TYPE_ECC_PUBLIC_KEY        1
#endif /* SPDM_HAVE_ECDSA || SPDM_HAVE_ECDHE */

/* Device-identity signing: import the unwrapped private scalar, then sign. */
#if SPDM_HAVE_ECDSA
#define PSA_WANT_ALG_ECDSA                      1
#define PSA_WANT_KEY_TYPE_ECC_KEY_PAIR_IMPORT   1
#endif /* SPDM_HAVE_ECDSA */

/* Ephemeral key agreement: generate the ephemeral key, then derive the secret. */
#if SPDM_HAVE_ECDHE
#define PSA_WANT_ALG_ECDH                       1
#define PSA_WANT_KEY_TYPE_ECC_KEY_PAIR_GENERATE 1
#endif /* SPDM_HAVE_ECDHE */

/******************************************************************************
 * AES-256-GCM.
 *
 * Per-record authenticated encryption for the SPDM secure session, and the
 * AES-GCM unwrap of the HUK-wrapped device private scalar (PAS slot 0).
 *****************************************************************************/
#define PSA_WANT_KEY_TYPE_AES                   1
#define PSA_WANT_ALG_GCM                        1

/******************************************************************************
 * AES-CMAC -- not used directly, but REQUIRED by the Infineon MXCRYPTOLITE
 * driver: mbedTLS always auto-enables PSA_WANT_KEY_TYPE_DERIVE
 * (psa/crypto_adjust_auto_enabled.h), which makes the vendor's always-compiled
 * SP800-108 counter-mode KDF driver pull in the CryptoLite CMAC primitives.
 * Omitting this breaks the vendor acceleration library build.
 *****************************************************************************/
#define PSA_WANT_ALG_CMAC                       1

#endif /* PSA_CRYPTO_CONFIG_SPDM_H */

/* [] END OF FILE */
