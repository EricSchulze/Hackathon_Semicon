/* user_settings.h
 *
 * wolfCrypt configuration for the SPDM Responder secure (SPE) project,
 * post-quantum profiles (SPDM_HAVE_MLDSA87 / SPDM_HAVE_MLKEM1024).
 *
 * Scope: ML-DSA-87 (FIPS 204, category 5) device-identity SIGNING on-device,
 * using wolfCrypt's pure-C Dilithium. The wrapped ML-DSA-87 private key is
 * provisioned into PAS slot 0; the SPE unwraps it with the HUK-derived key,
 * imports the raw private key and signs the SPDM transcript with the negotiated
 * op-code signing context (see core/spdm_crypto.c,
 * spdm_crypto_device_sign_mldsa87).
 *
 * The traditional ECDSA-P256 / SHA-256 / AES-GCM SPDM suite is served entirely by
 * PSA / mbedTLS, not wolfCrypt; this file only enables the Dilithium primitive
 * and its SHA-3/SHAKE + RNG dependencies, and disables everything else so the
 * auto-discovered wolfcrypt src .c sources compile to (near) nothing.
 *
 * Selected from proj_cm33_s/Makefile via WOLFSSL_USER_SETTINGS, and compiled
 * only when the profile uses the wolfCrypt backend (SPDM_PROFILE_USES_WOLFCRYPT).
 * Which primitives are enabled below is derived from the profile's
 * SPDM_HAVE_MLDSA87 / SPDM_HAVE_MLKEM1024 flags (profiles/<name>/profile.h), not
 * from a separate make define.
 */

#ifndef WOLFSSL_USER_SETTINGS_H
#define WOLFSSL_USER_SETTINGS_H

#ifdef __cplusplus
extern "C" {
#endif

/* Capability flags for the selected profile (profiles/<name>/profile.h, on the
 * include path via SPDM_PROFILE_DIR). Which PQ primitives this wolfCrypt build
 * enables is derived from these, so there is a single source of truth. */
#include "profile.h"

/* --- ML-DSA / Dilithium (FIPS 204) -------------------------------------- *
 * Device-identity SIGNING on-device, pure-C wolfCrypt Dilithium (not liboqs),
 * enabled only when the profile advertises ML-DSA-87. The responder imports a
 * provisioned private key and signs; it never generates or verifies ML-DSA keys
 * on-device, so wc_MlDsaKey_ImportPrivRaw and wc_MlDsaKey_SignCtx must stay
 * compiled in -- do NOT define the verify-only optimisations
 * (WOLFSSL_DILITHIUM_VERIFY_ONLY / _NO_SIGN / _VERIFY_SMALL_MEM /
 * _VERIFY_NO_MALLOC). Trimming the unused make-key path is deferred to the
 * Phase 5 memory pass. */
#if SPDM_HAVE_MLDSA87
#define HAVE_DILITHIUM
#define WOLFSSL_WC_DILITHIUM

/* Private key imported raw and the signature returned raw over the NSC
 * boundary, so the full ASN.1 OID lookup is not needed; use the hardcoded hash
 * OID tables and keep asn.c compiling to almost nothing. */
#define WOLFSSL_DILITHIUM_NO_ASN1

/* Category-5 (ML-DSA-87) only; drop the unused 44/65 sets to save code and RAM. */
#define WOLFSSL_NO_ML_DSA_44
#define WOLFSSL_NO_ML_DSA_65

/* ML-DSA-87 (k=8, l=7) would expand a full A matrix of 56 polynomials
 * (56 * 256 * 4 = 57,344 bytes) during signing; on this 64 KB-SRAM part that is
 * not an option, so stream the matrix a row at a time (a few KB working set). */
#define WOLFSSL_DILITHIUM_MAKE_KEY_SMALL_MEM
#define WOLFSSL_DILITHIUM_SIGN_SMALL_MEM
#endif /* SPDM_HAVE_MLDSA87 */

/* --- ML-KEM / Kyber (FIPS 203) ------------------------------------------ *
 * CNSA 2.0 key establishment, enabled only when the profile advertises
 * ML-KEM-1024. The Responder is the ML-KEM-1024 encapsulator in SPDM
 * KEY_EXCHANGE (core/spdm_crypto.c, spdm_crypto_mlkem_encapsulate): it only
 * decodes the requester's public encapsulation key and runs encapsulate(); it
 * never generates a key pair or decapsulates. Compile only the category-5
 * (1024) set -- the 512/768 sets are disabled to save code and RAM. */
#if SPDM_HAVE_MLKEM1024
#define WOLFSSL_HAVE_MLKEM
#define WOLFSSL_WC_MLKEM
#define WOLFSSL_NO_ML_KEM_512
#define WOLFSSL_NO_ML_KEM_768

/* Stream the encapsulate working matrix a slice at a time (same SRAM-budget
 * trade-off as ML-DSA above); caps the transient encapsulate heap at a few KB,
 * mandatory on this 64 KB-SRAM part. */
#define WOLFSSL_MLKEM_ENCAPSULATE_SMALL_MEM
#endif /* SPDM_HAVE_MLKEM1024 */

/* --- Shared PQ dependencies: SHA-3/SHAKE + RNG -------------------------- *
 * SHA-3/SHAKE are the hashing/sampling primitives of both ML-DSA and ML-KEM.
 * Both the sign (ML-DSA) and encapsulate (ML-KEM) paths need a WC_RNG; use
 * wolfCrypt's Hash-DRBG seeded from the PSC3 hardware TRNG. On M6 (HAL v3) the
 * asset's built-in CY_USING_HAL TRNG branch in random.c cannot be used (defining
 * CY_USING_HAL makes the generated BSP include the HAL-v2 cyhal_hwmgr.h, absent
 * on the v3 mtb-hal / DSL device), so the seed comes from our own
 * CUSTOM_RAND_GENERATE_SEED hook (core/spdm_wc_seed.c, spdm_wc_generate_seed)
 * which drives the MTB HAL TRNG directly. CUSTOM_RAND_GENERATE_SEED itself is
 * defined on the Makefile command line so the .S asm sources (which do not
 * include this header) never see it. NO_DEV_RANDOM keeps the POSIX /dev/random
 * fallback out of the build. */
#if SPDM_HAVE_MLDSA87 || SPDM_HAVE_MLKEM1024
#define WOLFSSL_SHA3
#define WOLFSSL_SHAKE128
#define WOLFSSL_SHAKE256
#define HAVE_HASHDRBG
#define NO_DEV_RANDOM
extern int spdm_wc_generate_seed(unsigned char* output, unsigned int sz);
#endif

/* --- Trim everything unused -------------------------------------------- */

/* No TLS/PKI layer, filesystem, sockets or threads on this bare-metal secure
 * core; the EC path lives in mbedTLS, so all traditional wolfCrypt algorithms are
 * turned off. */
#define WOLFCRYPT_ONLY
#define SINGLE_THREADED
#define WOLFSSL_USER_IO
#define NO_FILESYSTEM
#define NO_WRITEV
#define NO_MAIN_DRIVER
#define NO_DSA
#define NO_DH
#define NO_RSA
#define NO_PSK
#define NO_MD4
#define NO_MD5
#define NO_RC4
#define NO_DES3
#define NO_OLD_TLS
#define NO_SESSION_CACHE
#define NO_ERROR_STRINGS

/* Use standard C fixed-width types. */
#define SIZEOF_LONG_LONG 8

#ifdef __cplusplus
}
#endif

#endif /* WOLFSSL_USER_SETTINGS_H */
