/*****************************************************************************
 * File Name        : spdm_mbedtls_config.h
 *
 * Description      : Project mbedTLS configuration for the secure SPDM crypto
 *                    service -- FULL REPLACEMENT of the Infineon platform base
 *                    config.
 *
 *                    Selected via MBEDTLS_CONFIG_FILE (see proj_cm33_s/Makefile)
 *                    and therefore REPLACES the vendor base config
 *                    (target/.../psc3/psc3_mbedtls_config.h, normally pulled in
 *                    through infineon_platform.h). mbedTLS and every ifx-mbedtls
 *                    source file is compiled against this file alone, so only
 *                    the modules declared here are built.
 *
 *                    The secure crypto service exposes only what the SPDM
 *                    Responder needs (SHA-256, HMAC/HKDF-SHA256, ECDSA/ECDHE
 *                    P-256, AES-256-GCM, TRNG) and drives it entirely through
 *                    the PSA Crypto API, so the legacy mbedTLS PK / X.509 /
 *                    CSR layers are intentionally NOT enabled (unlike the
 *                    provisioning service, the device never builds a CSR nor
 *                    parses a certificate -- see the Option C1 cert-chain
 *                    decision in docs/implementation.md).
 *
 *                    Hardware acceleration: replacing the base config drops
 *                    psc3_mbedtls_user_config.h (which defines
 *                    IFX_PSA_CRYPTOLITE_PRESENT and wires the MXCRYPTOLITE
 *                    transparent driver into the PSA driver wrappers), so we
 *                    re-supply that master switch below under the same
 *                    COMPONENT_MW_CY_MBEDTLS_ACCELERATION guard. The driver's
 *                    per-feature configuration is derived from the PSA_WANT_*
 *                    macros in spdm_psa_crypto_config.h; what ends up hardware
 *                    accelerated per device is documented in
 *                    docs/implementation.md (Crypto backend).
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef MBEDTLS_CONFIG_SPDM_H
#define MBEDTLS_CONFIG_SPDM_H

/******************************************************************************
 * Infineon MXCRYPTOLITE PSA transparent driver.
 *
 * Reproduce the wiring normally provided by psc3_mbedtls_user_config.h (pulled
 * in by infineon_platform.h). Replacing the IFX base config drops that include,
 * so re-supply the master switch here. IFX_PSA_CRYPTOLITE_PRESENT registers the
 * CryptoLite transparent driver in the PSA driver wrappers; the driver's
 * per-feature macros are derived from PSA_WANT_* in spdm_psa_crypto_config.h.
 *****************************************************************************/
#ifdef COMPONENT_MW_CY_MBEDTLS_ACCELERATION
#define IFX_PSA_CRYPTOLITE_PRESENT
#endif

/* The companion CryptoLite driver config (IFX_PSA_CRYPTOLITE_USER_CONFIG_FILE)
 * is intentionally NOT defined here: the vendor's ifx_cryptolite_transparent_*.h
 * pull in ifx_cryptolite_config.h before mbedtls/build_info.h, so a macro
 * defined in this config header would not yet be visible when the driver config
 * is evaluated. It is therefore wired per device as a compiler -D in
 * proj_cm33_s/Makefile (which config each device selects is covered there). */

/******************************************************************************
 * Platform abstraction (mirrors the IFX base config so the platform behaviour
 * is identical to the proven build: no libc stdio assumptions, custom snprintf,
 * calloc/free-backed allocator).
 *****************************************************************************/
#define MBEDTLS_PLATFORM_C
#define MBEDTLS_PLATFORM_MEMORY
#define MBEDTLS_PLATFORM_NO_STD_FUNCTIONS
#define MBEDTLS_PLATFORM_SNPRINTF_ALT
#define MBEDTLS_PLATFORM_STD_MEM_HDR   <stdlib.h>
#define MBEDTLS_PLATFORM_STD_CALLOC        calloc
#define MBEDTLS_PLATFORM_STD_FREE            free

/******************************************************************************
 * Entropy / RNG.
 *
 * The TRNG is provided by the IFX acceleration library through the hardware
 * entropy hook (mbedtls_hardware_poll); no platform/OS entropy source exists.
 * PSA's internal RNG is seeded from the entropy module through CTR_DRBG, which
 * in turn relies on the software AES primitive (hence MBEDTLS_AES_C). This is
 * what backs libspdm_random_bytes() and the ECDHE ephemeral key generation.
 *****************************************************************************/
#define MBEDTLS_ENTROPY_C
#define MBEDTLS_ENTROPY_HARDWARE_ALT
#define MBEDTLS_NO_PLATFORM_ENTROPY
#define MBEDTLS_CTR_DRBG_C
#define MBEDTLS_AES_C

/* Move the AES T-tables/S-boxes to flash and keep only one of each (rotations
 * reconstructed inline). Software AES here backs only CTR_DRBG (the RNG), which
 * is off the session data path (AES-256-GCM is MXCRYPTOLITE-accelerated), so
 * the marginal round cost is immaterial; this reclaims ~8.7 KB of secure SRAM
 * for ~2.6 KB of secure flash. */
#define MBEDTLS_AES_ROM_TABLES
#define MBEDTLS_AES_FEWER_TABLES

/* Cipher layer: required because mbedTLS always auto-enables
 * PSA_WANT_KEY_TYPE_DERIVE, which makes the Infineon MXCRYPTOLITE KDF driver
 * pull in CMAC (PSA_WANT_ALG_CMAC -> MBEDTLS_CMAC_C). CMAC needs the cipher
 * abstraction layer (MBEDTLS_CIPHER_C + MBEDTLS_AES_C). MBEDTLS_CIPHER_C also
 * satisfies the PSA soft-block-mode prerequisite (check_config.h). */
#define MBEDTLS_CIPHER_C

/******************************************************************************
 * PSA Crypto core (driver-based configuration).
 *
 * MBEDTLS_PSA_CRYPTO_CONFIG makes the enabled crypto primitives follow the
 * PSA_WANT_* switches in spdm_psa_crypto_config.h; MBEDTLS_PSA_CRYPTO_DRIVERS
 * enables the transparent-driver dispatch used by the CryptoLite accelerator.
 * The whole secure crypto service is written against the PSA Crypto API, so
 * MBEDTLS_USE_PSA_CRYPTO is enabled as well.
 *****************************************************************************/
#define MBEDTLS_PSA_CRYPTO_C
#define MBEDTLS_PSA_CRYPTO_CONFIG
#define MBEDTLS_PSA_CRYPTO_DRIVERS
#define MBEDTLS_PSA_CRYPTO_CONFIG_FILE "spdm_psa_crypto_config.h"
#define MBEDTLS_USE_PSA_CRYPTO

/******************************************************************************
 * Secure-RAM footprint: the SPDM crypto service holds only a handful of PSA
 * keys live at once (unwrapped device key, ephemeral ECDHE key, transient
 * AEAD keys). Cap the key store (default 32) to fit the secure SRAM budget.
 *****************************************************************************/
#define MBEDTLS_PSA_KEY_SLOT_COUNT 8

#endif /* MBEDTLS_CONFIG_SPDM_H */

/* [] END OF FILE */
