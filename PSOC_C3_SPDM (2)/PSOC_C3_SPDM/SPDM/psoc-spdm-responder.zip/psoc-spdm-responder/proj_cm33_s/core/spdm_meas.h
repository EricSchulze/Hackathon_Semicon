/*****************************************************************************
 * File Name        : spdm_meas.h
 *
 * Description      : Secure (SPE) measurement data provider for the SPDM
 *                    Responder.
 *
 *                    This module owns WHAT the device measures -- the device's
 *                    measured state -- and nothing about how it is framed on the
 *                    wire. It exposes each measurement as a neutral item: an
 *                    index, a semantic kind, and the measurement's final value
 *                    bytes. For digest-form measurements (immutable ROM, mutable
 *                    firmware) the value is a digest that this module computes
 *                    with the negotiated measurement hash algorithm; for
 *                    raw-form measurements (secure version number, informational
 *                    string) the value is the datum itself.
 *
 *                    It is deliberately protocol-agnostic: it has no knowledge
 *                    of the SPDM/DMTF measurement-block wire layout, of the
 *                    measurement summary hash, or of the Non-Secure-Callable
 *                    boundary. The measurement veneer (proj_cm33_s/nsc/
 *                    nsc_meas.c) consumes these items, frames them into DMTF
 *                    measurement blocks and computes the summary hash.
 *
 *                    This split keeps the future real measured state -- hashing
 *                    actual ROM / firmware image regions, reading the secure
 *                    version number from an anti-rollback counter / eFuse -- in
 *                    one place, next to spdm_crypto, without dragging any SPDM
 *                    encoding into it.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef SPDM_MEAS_H
#define SPDM_MEAS_H

#include <stddef.h>
#include <stdint.h>

#include "psa/crypto.h"

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Macros / Types
 *****************************************************************************/

/* Number of measurements the device reports. */
#define SPDM_MEAS_ITEM_COUNT        (4U)

/* Largest digest this provider may produce (SHA-512 worst case). */
#define SPDM_MEAS_MAX_DIGEST_SIZE   (64U)

/**
 * Semantic classification of a measurement. The kind fixes both the device's
 * meaning of the measurement and whether it is represented as a digest or as a
 * raw value; it carries no SPDM/DMTF wire encoding.
 */
typedef enum {
    SPDM_MEAS_KIND_IMMUTABLE_ROM = 0, /* digest form */
    SPDM_MEAS_KIND_MUTABLE_FIRMWARE,  /* digest form */
    SPDM_MEAS_KIND_SECURE_VERSION,    /* raw form */
    SPDM_MEAS_KIND_INFORMATIONAL      /* raw form */
} spdm_meas_kind_t;

/**
 * One measurement. @value points to secure storage owned by this module and is
 * valid until the next spdm_meas_collect() call; it holds the measurement's
 * final bytes (a digest for digest-form kinds, the raw datum otherwise).
 */
typedef struct {
    uint8_t          index;       /* 1-based measurement index */
    spdm_meas_kind_t kind;        /* semantic classification */
    const uint8_t   *value;       /* final value bytes */
    size_t           value_size;  /* length of @value in bytes */
} spdm_meas_item_t;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Collect the device's measurements.
 *
 * Fills @p items with the device's measurement set, computing the digest-form
 * values with the negotiated @p measurement_hash_algo. Raw-form values are
 * returned as-is.
 *
 * @param measurement_hash_algo  Negotiated SPDM measurement hash algorithm id.
 * @param items                  Destination array (at least SPDM_MEAS_ITEM_COUNT).
 * @param max_items              Capacity of @p items.
 * @param out_count              On success, the number of items written.
 *
 * @return PSA_SUCCESS on success;
 *         PSA_ERROR_INVALID_ARGUMENT for a null pointer or too-small array;
 *         PSA_ERROR_NOT_SUPPORTED if the hash algorithm is not supported;
 *         or a PSA error from the hashing operation.
 */
psa_status_t spdm_meas_collect(uint32_t measurement_hash_algo,
                               spdm_meas_item_t *items, size_t max_items,
                               size_t *out_count);

#if defined(__cplusplus)
}
#endif

#endif /* SPDM_MEAS_H */

/* [] END OF FILE */
