/*****************************************************************************
 * File Name        : spdm_meas.c
 *
 * Description      : Secure (SPE) measurement data provider for the SPDM
 *                    Responder.
 *
 *                    Owns the device's measured state and exposes it as neutral
 *                    items (index, kind, final value bytes) through
 *                    spdm_meas_collect(). Digest-form measurements (immutable
 *                    ROM, mutable firmware) are hashed here with the negotiated
 *                    measurement hash algorithm; raw-form measurements (secure
 *                    version number, informational string) are returned as-is.
 *                    This module has no knowledge of the SPDM/DMTF wire layout
 *                    or of the measurement summary hash -- those belong to the
 *                    measurement veneer (proj_cm33_s/nsc/nsc_meas.c).
 *
 *                    The measurement VALUES are placeholders in this stage.
 *                    FUTURE: hash the actual immutable-ROM and mutable-firmware
 *                    image regions, and read the secure version number from the
 *                    anti-rollback counter / eFuse. The provider contract and
 *                    the digest hashing are final; only the sources change.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stddef.h>
#include <stdint.h>

#include "psa/crypto.h"

#include "profile.h"
#include "spdm_meas.h"

/******************************************************************************
 * Macros
 *****************************************************************************/

/* SPDM measurement hash algorithm identifiers (MeasurementHashAlgo namespace):
 * profiles negotiate SHA-256, SHA-384, or SHA-512 per the measurement-hash
 * selection. */
#define SPDM_MEAS_HASH_ALG_SHA_256  (0x00000002U)
#if SPDM_HAVE_SHA384
#define SPDM_MEAS_HASH_ALG_SHA_384  (0x00000004U)
#endif
#if SPDM_HAVE_SHA512
#define SPDM_MEAS_HASH_ALG_SHA_512  (0x00000008U)
#endif

/******************************************************************************
 * Placeholder measurement sources
 *
 * FUTURE: replace these with the real measured state -- the immutable-ROM and
 * mutable-firmware image regions to be hashed, and the secure version number
 * read from the anti-rollback counter / eFuse.
 *****************************************************************************/

static const uint8_t s_rom_preimage[] =
    "PSC3M5 immutable ROM measurement (placeholder)";
static const uint8_t s_fw_preimage[] =
    "PSC3M5 mutable firmware measurement (placeholder)";
static const uint64_t s_secure_version_number = 1U;
static const char s_version_info[] = "PSC3M5-SPDM-1.0.0";

/* Storage for the computed digest-form values; the returned items point here,
 * so it must outlive the call. The SPE serialises measurement requests, so a
 * single set of buffers is sufficient. */
static uint8_t s_rom_digest[SPDM_MEAS_MAX_DIGEST_SIZE];
static uint8_t s_fw_digest[SPDM_MEAS_MAX_DIGEST_SIZE];

/******************************************************************************
 * Internal helpers
 *****************************************************************************/

/* Map a negotiated SPDM measurement hash algorithm identifier to a PSA
 * algorithm and its digest size. Driven by the caller-supplied (negotiated)
 * value; only the algorithms this responder negotiates are accepted. */
static psa_status_t meas_map_hash(uint32_t spdm_hash_algo,
                                  psa_algorithm_t *psa_alg, size_t *digest_size)
{
    switch (spdm_hash_algo) {
    case SPDM_MEAS_HASH_ALG_SHA_256:
        *psa_alg = PSA_ALG_SHA_256;
        *digest_size = 32U;
        return PSA_SUCCESS;
#if SPDM_HAVE_SHA384
    case SPDM_MEAS_HASH_ALG_SHA_384:
        *psa_alg = PSA_ALG_SHA_384;
        *digest_size = 48U;
        return PSA_SUCCESS;
#endif
#if SPDM_HAVE_SHA512
    case SPDM_MEAS_HASH_ALG_SHA_512:
        *psa_alg = PSA_ALG_SHA_512;
        *digest_size = 64U;
        return PSA_SUCCESS;
#endif
    default:
        return PSA_ERROR_NOT_SUPPORTED;
    }
}

/******************************************************************************
 * Measurement collection
 *****************************************************************************/

psa_status_t spdm_meas_collect(uint32_t measurement_hash_algo,
                               spdm_meas_item_t *items, size_t max_items,
                               size_t *out_count)
{
    psa_algorithm_t psa_alg;
    size_t digest_size;
    size_t produced;
    psa_status_t st;

    if ((items == NULL) || (out_count == NULL) ||
        (max_items < SPDM_MEAS_ITEM_COUNT)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }

    st = meas_map_hash(measurement_hash_algo, &psa_alg, &digest_size);
    if (st != PSA_SUCCESS) {
        return st;
    }

    /* Digest-form values: hash the (placeholder) measured object with the
     * negotiated algorithm. */
    st = psa_hash_compute(psa_alg, s_rom_preimage, sizeof(s_rom_preimage) - 1U,
                          s_rom_digest, sizeof(s_rom_digest), &produced);
    if ((st != PSA_SUCCESS) || (produced != digest_size)) {
        return (st == PSA_SUCCESS) ? PSA_ERROR_GENERIC_ERROR : st;
    }
    st = psa_hash_compute(psa_alg, s_fw_preimage, sizeof(s_fw_preimage) - 1U,
                          s_fw_digest, sizeof(s_fw_digest), &produced);
    if ((st != PSA_SUCCESS) || (produced != digest_size)) {
        return (st == PSA_SUCCESS) ? PSA_ERROR_GENERIC_ERROR : st;
    }

    items[0].index = 1U;
    items[0].kind = SPDM_MEAS_KIND_IMMUTABLE_ROM;
    items[0].value = s_rom_digest;
    items[0].value_size = digest_size;

    items[1].index = 2U;
    items[1].kind = SPDM_MEAS_KIND_MUTABLE_FIRMWARE;
    items[1].value = s_fw_digest;
    items[1].value_size = digest_size;

    /* Raw-form values: the datum itself, not hashed. */
    items[2].index = 3U;
    items[2].kind = SPDM_MEAS_KIND_SECURE_VERSION;
    items[2].value = (const uint8_t *)&s_secure_version_number;
    items[2].value_size = sizeof(s_secure_version_number);

    items[3].index = 4U;
    items[3].kind = SPDM_MEAS_KIND_INFORMATIONAL;
    items[3].value = (const uint8_t *)s_version_info;
    items[3].value_size = sizeof(s_version_info) - 1U; /* drop the NUL */

    *out_count = SPDM_MEAS_ITEM_COUNT;
    return PSA_SUCCESS;
}

/* [] END OF FILE */
