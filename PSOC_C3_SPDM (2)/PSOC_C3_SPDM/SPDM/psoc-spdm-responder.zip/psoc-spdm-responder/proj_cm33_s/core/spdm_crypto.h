/*****************************************************************************
 * File Name        : spdm_crypto.h
 *
 * Description      : Secure (SPE) PSA crypto service for the SPDM Responder.
 *
 *                    This is the secure-world crypto engine that backs the
 *                    non-secure libspdm cryptlib. libspdm runs in the
 *                    non-secure world and calls the libspdm_* crypto interface;
 *                    the non-secure cryptlib (proj_cm33_ns/spdm/cryptlib/)
 *                    forwards each call to a Non-Secure-Callable veneer
 *                    (proj_cm33_s/nsc/nsc_psa.c), which validates the caller's
 *                    pointers and then calls the functions declared here. All
 *                    actual cryptography executes in the SPE on the PSA Crypto
 *                    API (ifx-mbedtls + MXCRYPTOLITE + TRNG), which is PPC-locked
 *                    to the secure world.
 *
 *                    The service is deliberately GENERIC and PSA-shaped -- it
 *                    exposes thin gateways that mirror the PSA Crypto API
 *                    (psa_hash_*, one-call AEAD, psa_generate_random) rather
 *                    than SPDM-specific primitives. This keeps the SPE
 *                    algorithm-agnostic so the eventual TF-M switch is "delete
 *                    the SPE, relink the PSA NS interface." Stage 4a implements:
 *                      - a multipart SHA-256 hash (setup/update/finish/clone/
 *                        abort) plus one-shot compute, over a fixed secure
 *                        operation pool
 *                      - AES-256-GCM AEAD (encrypt / decrypt), one call per
 *                        record, with a per-call volatile imported key
 *                      - random bytes (TRNG-seeded PSA DRBG)
 *
 *                    HMAC-SHA256 and HKDF-SHA256 are intentionally NOT here:
 *                    PSA has no MAC clone but the SPDM key schedule duplicates a
 *                    partial HMAC context, so they are reconstructed in the
 *                    non-secure world on top of the generic hash gateway (see
 *                    proj_cm33_ns/spdm/cryptlib/mac.c and kdf.c).
 *
 *                    A streaming hash operation lives in a fixed secure pool;
 *                    callers receive an opaque 1-based index handle
 *                    (spdm_crypto_hash_op_t), never a secure pointer, so a
 *                    malicious non-secure handle can only ever select a pool
 *                    slot. The ephemeral ECDHE contexts follow the same
 *                    handle-pool pattern (spdm_crypto_ec_op_t).
 *
 *                    Stage 4b adds the device-identity signing and the
 *                    session key agreement, both keeping every private key in
 *                    the SPE:
 *                      - device-key ECDSA signing (P-256/P-384/P-521, the curve
 *                        fixed by the active profile). The wrapped private
 *                        scalar is read from PAS slot 0, unwrapped with the
 *                        HUK-derived key, imported, used once and destroyed.
 *                        The non-secure world only ever sees the signature.
 *                      - ephemeral ECDHE (P-256/P-384/P-521) key agreement over
 *                        a fixed secure context pool: generate returns only the
 *                        public point; compute returns the raw shared secret.
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef SPDM_CRYPTO_H
#define SPDM_CRYPTO_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "psa/crypto.h"

#include "profile.h"  /* SPDM_HAVE_* capability flags for the selected profile */

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Macros / Types
 *****************************************************************************/

/* EC key-agreement sizes at the boundary, derived from the profile's ECDHE
 * curve: P-256 -> 64/32, P-384 -> 96/48, P-521 -> 132/66. */
#if SPDM_HAVE_ECDHE
#define SPDM_CRYPTO_EC_PUB_LEN      (2U * SPDM_KEX_EC_BYTES)   /* raw public point X||Y */
#define SPDM_CRYPTO_EC_SECRET_LEN   (SPDM_KEX_EC_BYTES)        /* ECDH shared secret    */
#endif /* SPDM_HAVE_ECDHE */

/* ECDSA signature size (R||S), derived from the device-key curve. Defined only
 * for an ECDSA device key. */
#if SPDM_HAVE_ECDSA
#define SPDM_CRYPTO_SIG_LEN         (2U * SPDM_DEV_EC_BYTES)   /* ECDSA signature R||S  */
#endif

/* Opaque streaming hash-operation handle handed to the non-secure world. Value
 * 0 is always "no operation"; valid handles are 1-based indices into a secure
 * operation pool. Mirrors the role of psa_hash_operation_t for a PSA client. */
typedef int32_t spdm_crypto_hash_op_t;

#define SPDM_CRYPTO_HASH_OP_NONE    ((spdm_crypto_hash_op_t)0)

/* Opaque ephemeral-ECDHE context handle. Value 0 is "no operation"; valid
 * handles are 1-based indices into a secure EC context pool. */
#if SPDM_HAVE_ECDHE
typedef int32_t spdm_crypto_ec_op_t;

#define SPDM_CRYPTO_EC_OP_NONE      ((spdm_crypto_ec_op_t)0)
#endif /* SPDM_HAVE_ECDHE */

/******************************************************************************
 * Service lifecycle
 *****************************************************************************/

/**
 * @brief Initialize the secure PSA crypto service.
 *
 * Calls psa_crypto_init() so the PSA DRBG (seeded from the hardware TRNG) and
 * the MXCRYPTOLITE transparent driver are ready before the non-secure world is
 * launched. Must be called once from the secure main() before starting the
 * non-secure application.
 *
 * @retval true   The PSA subsystem initialized successfully.
 * @retval false  Initialization failed.
 */
bool spdm_crypto_init(void);

/******************************************************************************
 * Random number generation -- mirrors psa_generate_random()
 *****************************************************************************/

psa_status_t spdm_crypto_generate_random(uint8_t *output, size_t output_size);

/******************************************************************************
 * Multipart hash -- mirrors the psa_hash_* API
 *
 * setup() allocates a secure operation and returns its handle through *op.
 * finish() validates the digest length. finish()/abort() release the operation.
 *****************************************************************************/

psa_status_t spdm_crypto_hash_setup(spdm_crypto_hash_op_t *op,
                                    psa_algorithm_t alg);
psa_status_t spdm_crypto_hash_update(spdm_crypto_hash_op_t op,
                                     const uint8_t *input, size_t input_size);
psa_status_t spdm_crypto_hash_finish(spdm_crypto_hash_op_t op, uint8_t *hash,
                                     size_t hash_size, size_t *hash_length);
psa_status_t spdm_crypto_hash_clone(spdm_crypto_hash_op_t src,
                                    spdm_crypto_hash_op_t *dst);
psa_status_t spdm_crypto_hash_abort(spdm_crypto_hash_op_t op);

/******************************************************************************
 * AES-256-GCM AEAD (one call per record, per-call volatile key)
 *****************************************************************************/

psa_status_t spdm_crypto_aead_encrypt(const uint8_t *key, size_t key_size,
                                      const uint8_t *iv, size_t iv_size,
                                      const uint8_t *a_data, size_t a_data_size,
                                      const uint8_t *data_in, size_t data_in_size,
                                      uint8_t *tag_out, size_t tag_size,
                                      uint8_t *data_out, size_t *data_out_size);

psa_status_t spdm_crypto_aead_decrypt(const uint8_t *key, size_t key_size,
                                      const uint8_t *iv, size_t iv_size,
                                      const uint8_t *a_data, size_t a_data_size,
                                      const uint8_t *data_in, size_t data_in_size,
                                      const uint8_t *tag, size_t tag_size,
                                      uint8_t *data_out, size_t *data_out_size);

/******************************************************************************
 * Device-identity signing (ECDSA over the PAS slot-0 key; P-256/P-384/P-521)
 *
 * Reads the wrapped private scalar from PAS slot 0, unwraps it with the
 * HUK-derived key, imports it, signs once and destroys it. The private key
 * never leaves the SPE; only the signature is returned. The curve and hash are
 * fixed by the active profile (SPDM_DEV_EC_* / SPDM_DEV_HASH_ALG).
 *
 * is_data_hash mirrors libspdm's convention:
 *   is_data_hash == true  -> message is the raw data; hash-then-sign
 *                            (psa_sign_message).
 *   is_data_hash == false -> message is the pre-computed digest; sign it
 *                            directly (psa_sign_hash).
 *****************************************************************************/

#if SPDM_HAVE_ECDSA
psa_status_t spdm_crypto_device_sign(bool is_data_hash,
                                     const uint8_t *message, size_t message_size,
                                     uint8_t *signature, size_t signature_cap,
                                     size_t *signature_size);
#endif /* SPDM_HAVE_ECDSA */

#if SPDM_HAVE_MLDSA87
/******************************************************************************
 * Device-identity signing (ML-DSA-87) -- PQC suite
 *
 * Reads the wrapped ML-DSA-87 private key from PAS slot 0, unwraps it with the
 * HUK-derived key, imports it, signs once (wolfCrypt) and destroys it. The
 * private key never leaves the SPE; only the signature is returned.
 *
 * The signature is a pure ML-DSA (FIPS 204) signature over @p message using
 * @p context as the FIPS-204 signing context (the SPDM per-op-code
 * signing-context string). This matches how a libspdm requester verifies the
 * ML-DSA signature, so @p context MUST NOT be empty for SPDM interop.
 *****************************************************************************/

/* ML-DSA-87 raw signature size (FIPS 204, category 5). */
#define SPDM_CRYPTO_MLDSA87_SIG_LEN     (4627U)

psa_status_t spdm_crypto_device_sign_mldsa87(const uint8_t *context,
                                             size_t context_size,
                                             const uint8_t *message,
                                             size_t message_size,
                                             uint8_t *signature,
                                             size_t signature_cap,
                                             size_t *signature_size);
#endif /* SPDM_HAVE_MLDSA87 */

#if SPDM_HAVE_MLKEM1024
/******************************************************************************
 * Key establishment (ML-KEM-1024 encapsulate) -- PQC suite
 *
 * The Responder is the KEM encapsulator in the CNSA 2.0 SPDM KEY_EXCHANGE. It
 * decodes the requester's raw ML-KEM-1024 public encapsulation key, runs one
 * encapsulate (wolfCrypt), and returns the ciphertext plus the shared secret.
 * The key object and wolfCrypt working set are transient (heap-backed): they
 * are allocated and freed inside the call so nothing persists in secure BSS.
 * The Responder never generates an ML-KEM key pair and never decapsulates.
 *****************************************************************************/

/* ML-KEM-1024 boundary sizes (FIPS 203, category 5). */
#define SPDM_CRYPTO_MLKEM1024_PUB_LEN   (1568U)  /* peer encapsulation key    */
#define SPDM_CRYPTO_MLKEM1024_CT_LEN    (1568U)  /* ciphertext                */
#define SPDM_CRYPTO_MLKEM1024_SS_LEN    (32U)    /* shared secret             */

psa_status_t spdm_crypto_mlkem_encapsulate(const uint8_t *peer_encap_key,
                                           size_t peer_encap_key_size,
                                           uint8_t *cipher_text,
                                           size_t cipher_text_cap,
                                           size_t *cipher_text_size,
                                           uint8_t *shared_secret,
                                           size_t shared_secret_cap,
                                           size_t *shared_secret_size);
#endif /* SPDM_HAVE_MLKEM1024 */

/******************************************************************************
 * Ephemeral ECDHE key agreement over a fixed secure context pool (P-256/P-384/
 * P-521; the curve is fixed by the active profile, SPDM_KEX_EC_*)
 *
 * new()      allocates a secure context and returns its handle through *op.
 * generate() creates the ephemeral key pair and exports the raw public point
 *            (X||Y, SPDM_CRYPTO_EC_PUB_LEN bytes).
 * compute()  performs ECDH against the peer's raw public point and returns the
 *            raw shared secret (SPDM_CRYPTO_EC_SECRET_LEN bytes).
 * free()     destroys the ephemeral key and releases the context.
 *****************************************************************************/
#if SPDM_HAVE_ECDHE

psa_status_t spdm_crypto_ec_new(spdm_crypto_ec_op_t *op);
psa_status_t spdm_crypto_ec_generate(spdm_crypto_ec_op_t op,
                                     uint8_t *public_key, size_t public_key_cap,
                                     size_t *public_key_size);
psa_status_t spdm_crypto_ec_compute(spdm_crypto_ec_op_t op,
                                    const uint8_t *peer_public,
                                    size_t peer_public_size,
                                    uint8_t *secret, size_t secret_cap,
                                    size_t *secret_size);
psa_status_t spdm_crypto_ec_free(spdm_crypto_ec_op_t op);

#endif /* SPDM_HAVE_ECDHE */

#if defined(__cplusplus)
}
#endif

#endif /* SPDM_CRYPTO_H */
