/*****************************************************************************
 * File Name        : spdm_heap.c
 *
 * Description      : Secure (SPE) heap-break implementation for the SPDM
 *                    Responder.
 *
 *                    The default newlib libnosys _sbrk() is a bare stub: it
 *                    advances the program break without ever checking a limit,
 *                    so a large malloc() (for example the ML-DSA-87 signer's
 *                    single ~27 KB working-set allocation) can silently hand
 *                    back a buffer that runs past __HeapLimit, through the
 *                    secure stack, and off the top of the secure SRAM window.
 *                    The first write into that region is rejected by the MPC
 *                    and surfaces as a precise BusFault deep inside a crypto
 *                    primitive, with no useful diagnosis.
 *
 *                    This strong override enforces the linker-defined heap
 *                    bounds [__HeapBase, __HeapLimit). When the requested
 *                    growth would cross __HeapLimit the break is left unchanged
 *                    and (void *)-1 is returned, so malloc() fails cleanly and
 *                    the caller gets a normal out-of-memory error instead of a
 *                    hard fault. This turns a silent heap/stack collision into
 *                    a deterministic, testable failure.
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/
#include <errno.h>
#include <stddef.h>

/* Heap bounds provided by the secure linker script (linker_s_flash.ld):
 *   __HeapBase  - first byte of the heap (== end of .bss / __end__)
 *   __HeapLimit - one past the last usable heap byte (== __StackLimit) */
extern char __HeapBase;
extern char __HeapLimit;

/******************************************************************************
 * Function Definitions
 *****************************************************************************/

/*******************************************************************************
 * Function Name: _sbrk
 ********************************************************************************
 * Summary:
 *  Bounds-checked program-break primitive used by the C library allocator.
 *  Grows or shrinks the heap within [__HeapBase, __HeapLimit) and fails with
 *  ENOMEM rather than overrunning the secure stack / SRAM window.
 *
 * Parameters:
 *  incr - Signed number of bytes to add to (or remove from) the program break.
 *
 * Return:
 *  The previous program break on success, or (void *)-1 with errno set to
 *  ENOMEM if the requested change would leave the heap bounds.
 *******************************************************************************/
void *_sbrk(int incr)
{
    static char *heap_end;
    char *prev_heap_end;
    char *new_heap_end;

    if (heap_end == NULL) {
        heap_end = &__HeapBase;
    }

    prev_heap_end = heap_end;
    new_heap_end = heap_end + incr;

    /* Reject growth past the heap ceiling and shrinkage below the heap base. */
    if ((new_heap_end > &__HeapLimit) || (new_heap_end < &__HeapBase)) {
        errno = ENOMEM;
        return (void *)-1;
    }

    heap_end = new_heap_end;
    return (void *)prev_heap_end;
}
