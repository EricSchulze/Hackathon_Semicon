/*****************************************************************************
 * File Name        : spdm_crypto.c
 *
 * Description      : Secure (SPE) PSA crypto service for the SPDM Responder.
 *                    See spdm_crypto.h for the role of this module.
 *
 *                    All cryptography runs here, in the secure world, on the
 *                    PSA Crypto API (ifx-mbedtls + MXCRYPTOLITE + TRNG). The
 *                    non-secure libspdm cryptlib reaches these functions only
 *                    through the Non-Secure-Callable veneers, which validate
 *                    every caller pointer first.
 *
 *                    The service is generic and PSA-shaped: a multipart hash
 *                    gateway over a fixed secure operation pool, a one-call
 *                    AES-GCM AEAD with a per-call volatile key, and the RNG.
 *                    HMAC-SHA256 and HKDF-SHA256 are NOT implemented here -- the
 *                    non-secure world rebuilds them on top of the hash gateway
 *                    (PSA has no MAC clone, but the SPDM key schedule clones a
 *                    partial HMAC context; psa_hash_clone does exist).
 *
 * Related Document : docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

/******************************************************************************
 * Header Files
 *****************************************************************************/

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "psa/crypto.h"

#include "cy_pdl.h"

#include "spdm_crypto.h"
#include "pas.h"
#include "key_slot.h"

#if SPDM_HAVE_MLDSA87 || SPDM_HAVE_MLKEM1024
/* wolfCrypt (ifx-wolfcrypto) provides the post-quantum ML-DSA-87 signer and
 * ML-KEM-1024 encapsulation; mbedTLS / PSA cannot do them. Configuration lives
 * in config/user_settings.h (selected by WOLFSSL_USER_SETTINGS). */
#include "wolfssl/wolfcrypt/settings.h"
#include "wolfssl/wolfcrypt/dilithium.h"
#include "wolfssl/wolfcrypt/wc_mlkem.h"
#include "wolfssl/wolfcrypt/random.h"
#endif

/******************************************************************************
 * Macros
 *****************************************************************************/

/* Fixed secure hash-operation pool. libspdm keeps several transcript-hash
 * contexts live and duplicates them, and each non-secure HMAC context (rebuilt
 * on top of this gateway) also holds one inner hash operation, so this single
 * generic pool must cover the sum. Ten slots preserve the headroom of the
 * previous split 6-hash / 4-HMAC pools. */
#define SPDM_HASH_POOL_COUNT        (10U)

/******************************************************************************
 * Types
 *****************************************************************************/

typedef struct {
    bool                 in_use;
    psa_hash_operation_t op;
} spdm_hash_slot_t;

/******************************************************************************
 * Module State
 *****************************************************************************/

static spdm_hash_slot_t g_hash_pool[SPDM_HASH_POOL_COUNT];

/******************************************************************************
 * Internal helpers -- pool handle validation
 *****************************************************************************/

static spdm_hash_slot_t *hash_slot_from_op(spdm_crypto_hash_op_t op)
{
    if ((op < 1) || (op > (spdm_crypto_hash_op_t)SPDM_HASH_POOL_COUNT)) {
        return NULL;
    }
    spdm_hash_slot_t *slot = &g_hash_pool[op - 1];
    return slot->in_use ? slot : NULL;
}

/******************************************************************************
 * Service lifecycle
 *****************************************************************************/

bool spdm_crypto_init(void)
{
    return (psa_crypto_init() == PSA_SUCCESS);
}

/******************************************************************************
 * Random number generation
 *****************************************************************************/

psa_status_t spdm_crypto_generate_random(uint8_t *output, size_t output_size)
{
    if (output == NULL) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (output_size == 0U) {
        return PSA_SUCCESS;
    }
    return psa_generate_random(output, output_size);
}

/******************************************************************************
 * Multipart hash
 *****************************************************************************/

psa_status_t spdm_crypto_hash_setup(spdm_crypto_hash_op_t *op,
                                    psa_algorithm_t alg)
{
    if (op == NULL) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    *op = SPDM_CRYPTO_HASH_OP_NONE;

    for (uint32_t i = 0U; i < SPDM_HASH_POOL_COUNT; i++) {
        if (!g_hash_pool[i].in_use) {
            psa_status_t st;
            g_hash_pool[i].op = (psa_hash_operation_t)PSA_HASH_OPERATION_INIT;
            st = psa_hash_setup(&g_hash_pool[i].op, alg);
            if (st != PSA_SUCCESS) {
                (void)psa_hash_abort(&g_hash_pool[i].op);
                return st;
            }
            g_hash_pool[i].in_use = true;
            *op = (spdm_crypto_hash_op_t)(i + 1U);
            return PSA_SUCCESS;
        }
    }
    return PSA_ERROR_INSUFFICIENT_MEMORY;
}

psa_status_t spdm_crypto_hash_update(spdm_crypto_hash_op_t op,
                                     const uint8_t *input, size_t input_size)
{
    spdm_hash_slot_t *slot = hash_slot_from_op(op);
    if ((slot == NULL) || ((input == NULL) && (input_size != 0U))) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (input_size == 0U) {
        return PSA_SUCCESS;
    }
    return psa_hash_update(&slot->op, input, input_size);
}

psa_status_t spdm_crypto_hash_finish(spdm_crypto_hash_op_t op, uint8_t *hash,
                                     size_t hash_size, size_t *hash_length)
{
    spdm_hash_slot_t *slot = hash_slot_from_op(op);
    psa_status_t st;

    if ((slot == NULL) || (hash == NULL) || (hash_length == NULL)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }

    st = psa_hash_finish(&slot->op, hash, hash_size, hash_length);
    /* finish() consumes the PSA operation regardless of outcome; release the
     * pool slot so the handle cannot be reused. */
    (void)psa_hash_abort(&slot->op);
    slot->in_use = false;
    return st;
}

psa_status_t spdm_crypto_hash_clone(spdm_crypto_hash_op_t src,
                                    spdm_crypto_hash_op_t *dst)
{
    spdm_hash_slot_t *s = hash_slot_from_op(src);

    if ((s == NULL) || (dst == NULL)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    *dst = SPDM_CRYPTO_HASH_OP_NONE;

    for (uint32_t i = 0U; i < SPDM_HASH_POOL_COUNT; i++) {
        if (!g_hash_pool[i].in_use) {
            psa_status_t st;
            g_hash_pool[i].op = (psa_hash_operation_t)PSA_HASH_OPERATION_INIT;
            st = psa_hash_clone(&s->op, &g_hash_pool[i].op);
            if (st != PSA_SUCCESS) {
                (void)psa_hash_abort(&g_hash_pool[i].op);
                return st;
            }
            g_hash_pool[i].in_use = true;
            *dst = (spdm_crypto_hash_op_t)(i + 1U);
            return PSA_SUCCESS;
        }
    }
    return PSA_ERROR_INSUFFICIENT_MEMORY;
}

psa_status_t spdm_crypto_hash_abort(spdm_crypto_hash_op_t op)
{
    spdm_hash_slot_t *slot = hash_slot_from_op(op);
    if (slot == NULL) {
        /* Aborting an unknown / already-released handle is a no-op success,
         * matching psa_hash_abort() on a zero-initialised operation. */
        return PSA_SUCCESS;
    }
    (void)psa_hash_abort(&slot->op);
    slot->in_use = false;
    return PSA_SUCCESS;
}

/******************************************************************************
 * AES-256-GCM AEAD
 *****************************************************************************/

static psa_status_t aead_import_key(const uint8_t *key, size_t key_size,
                                    psa_algorithm_t alg, psa_key_usage_t usage,
                                    mbedtls_svc_key_id_t *key_id)
{
    psa_key_attributes_t attr = PSA_KEY_ATTRIBUTES_INIT;
    psa_status_t st;

    psa_set_key_usage_flags(&attr, usage);
    psa_set_key_algorithm(&attr, alg);
    psa_set_key_type(&attr, PSA_KEY_TYPE_AES);
    psa_set_key_bits(&attr, key_size * 8U);

    st = psa_import_key(&attr, key, key_size, key_id);
    psa_reset_key_attributes(&attr);
    return st;
}

psa_status_t spdm_crypto_aead_encrypt(const uint8_t *key, size_t key_size,
                                      const uint8_t *iv, size_t iv_size,
                                      const uint8_t *a_data, size_t a_data_size,
                                      const uint8_t *data_in, size_t data_in_size,
                                      uint8_t *tag_out, size_t tag_size,
                                      uint8_t *data_out, size_t *data_out_size)
{
    psa_aead_operation_t op = PSA_AEAD_OPERATION_INIT;
    mbedtls_svc_key_id_t key_id = MBEDTLS_SVC_KEY_ID_INIT;
    psa_algorithm_t alg;
    psa_status_t status = PSA_ERROR_GENERIC_ERROR;
    size_t out_len = 0;
    size_t fin_len = 0;
    size_t tag_len = 0;

    if ((key == NULL) || (iv == NULL) || (tag_out == NULL) ||
        (data_out == NULL) || (data_out_size == NULL) ||
        ((a_data == NULL) && (a_data_size != 0U)) ||
        ((data_in == NULL) && (data_in_size != 0U))) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (((key_size != 16U) && (key_size != 32U)) || (iv_size != 12U) ||
        (tag_size < 12U) || (tag_size > 16U)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }

    alg = PSA_ALG_AEAD_WITH_SHORTENED_TAG(PSA_ALG_GCM, tag_size);
    status = aead_import_key(key, key_size, alg, PSA_KEY_USAGE_ENCRYPT, &key_id);
    if (status != PSA_SUCCESS) {
        return status;
    }

    status = psa_aead_encrypt_setup(&op, key_id, alg);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    status = psa_aead_set_lengths(&op, a_data_size, data_in_size);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    status = psa_aead_set_nonce(&op, iv, iv_size);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    if (a_data_size != 0U) {
        status = psa_aead_update_ad(&op, a_data, a_data_size);
        if (status != PSA_SUCCESS) {
            goto cleanup;
        }
    }
    status = psa_aead_update(&op, data_in, data_in_size, data_out, data_in_size,
                             &out_len);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    status = psa_aead_finish(&op, data_out + out_len, data_in_size - out_len,
                             &fin_len, tag_out, tag_size, &tag_len);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    if (tag_len != tag_size) {
        status = PSA_ERROR_GENERIC_ERROR;
        goto cleanup;
    }

    *data_out_size = out_len + fin_len;

cleanup:
    if (status != PSA_SUCCESS) {
        (void)psa_aead_abort(&op);
    }
    (void)psa_destroy_key(key_id);
    return status;
}

psa_status_t spdm_crypto_aead_decrypt(const uint8_t *key, size_t key_size,
                                      const uint8_t *iv, size_t iv_size,
                                      const uint8_t *a_data, size_t a_data_size,
                                      const uint8_t *data_in, size_t data_in_size,
                                      const uint8_t *tag, size_t tag_size,
                                      uint8_t *data_out, size_t *data_out_size)
{
    psa_aead_operation_t op = PSA_AEAD_OPERATION_INIT;
    mbedtls_svc_key_id_t key_id = MBEDTLS_SVC_KEY_ID_INIT;
    psa_algorithm_t alg;
    psa_status_t status = PSA_ERROR_GENERIC_ERROR;
    size_t out_len = 0;
    size_t fin_len = 0;

    if ((key == NULL) || (iv == NULL) || (tag == NULL) ||
        (data_out == NULL) || (data_out_size == NULL) ||
        ((a_data == NULL) && (a_data_size != 0U)) ||
        ((data_in == NULL) && (data_in_size != 0U))) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (((key_size != 16U) && (key_size != 32U)) || (iv_size != 12U) ||
        (tag_size < 12U) || (tag_size > 16U)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }

    alg = PSA_ALG_AEAD_WITH_SHORTENED_TAG(PSA_ALG_GCM, tag_size);
    status = aead_import_key(key, key_size, alg, PSA_KEY_USAGE_DECRYPT, &key_id);
    if (status != PSA_SUCCESS) {
        return status;
    }

    status = psa_aead_decrypt_setup(&op, key_id, alg);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    status = psa_aead_set_lengths(&op, a_data_size, data_in_size);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    status = psa_aead_set_nonce(&op, iv, iv_size);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    if (a_data_size != 0U) {
        status = psa_aead_update_ad(&op, a_data, a_data_size);
        if (status != PSA_SUCCESS) {
            goto cleanup;
        }
    }
    status = psa_aead_update(&op, data_in, data_in_size, data_out, data_in_size,
                             &out_len);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }
    /* psa_aead_verify performs the constant-time tag check and fails closed. */
    status = psa_aead_verify(&op, data_out + out_len, data_in_size - out_len,
                             &fin_len, tag, tag_size);
    if (status != PSA_SUCCESS) {
        goto cleanup;
    }

    *data_out_size = out_len + fin_len;

cleanup:
    if (status != PSA_SUCCESS) {
        (void)psa_aead_abort(&op);
    }
    (void)psa_destroy_key(key_id);
    return status;
}

/******************************************************************************
 * Device key unwrapping -- shared by the ECDSA and ML-DSA-87 device-sign paths
 *****************************************************************************/

/* PAS slot holding the device identity key (written by the provisioner). */
#define SPDM_DEV_KEY_SLOT       (0U)

/* AES-256-GCM device private-key wrapping (must match the provisioner). Shared
 * by the ECDSA and ML-DSA-87 device-key unwrap paths. */
#define SPDM_DEV_WRAP_ALG       PSA_ALG_GCM
#define SPDM_DEV_WRAP_KEY_BITS  (256U)
#define SPDM_DEV_HUK_BYTES      (32U)
#define SPDM_DEV_GCM_NONCE      (12U)
#define SPDM_DEV_WRAP_OVERHEAD  (SPDM_DEV_GCM_NONCE + 16U)          /* 28 */

/**
 * @brief Derive the device key-wrapping key (volatile AES-256 PSA key).
 *
 * Mirrors the provisioning application: HKDF-SHA256 over the device HUK with a
 * domain-separation label. Because the HUK is unique per silicon and only
 * readable by the secure world, the wrapping key — and therefore the wrapped
 * private key — is bound to this device and cannot be unwrapped off-chip.
 *
 * The HKDF secret (IKM) must be supplied as a DERIVE key object (not raw bytes)
 * or deriving a key output is rejected with PSA_ERROR_NOT_PERMITTED.
 */
static psa_status_t spdm_device_wrap_key(psa_key_id_t *key_id)
{
    /* Same domain-separation label the provisioner bound into the HKDF 'info'. */
    static const uint8_t k_wrap_info[] = "PROV_DEV_WRAP_KEY_v1";

    psa_key_derivation_operation_t op = PSA_KEY_DERIVATION_OPERATION_INIT;
    psa_key_attributes_t attr = PSA_KEY_ATTRIBUTES_INIT;
    psa_key_attributes_t huk_attr = PSA_KEY_ATTRIBUTES_INIT;
    psa_key_id_t huk_id = PSA_KEY_ID_NULL;
    psa_status_t status;

    *key_id = PSA_KEY_ID_NULL;

    psa_set_key_usage_flags(&huk_attr, PSA_KEY_USAGE_DERIVE);
    psa_set_key_algorithm(&huk_attr, PSA_ALG_HKDF(PSA_ALG_SHA_256));
    psa_set_key_type(&huk_attr, PSA_KEY_TYPE_DERIVE);
    status = psa_import_key(&huk_attr, (const uint8_t *)SFLASH->HUK,
                            SPDM_DEV_HUK_BYTES, &huk_id);
    psa_reset_key_attributes(&huk_attr);
    if (status != PSA_SUCCESS) {
        return status;
    }

    status = psa_key_derivation_setup(&op, PSA_ALG_HKDF(PSA_ALG_SHA_256));
    if (status == PSA_SUCCESS) {
        status = psa_key_derivation_input_key(&op,
                                              PSA_KEY_DERIVATION_INPUT_SECRET,
                                              huk_id);
    }
    if (status == PSA_SUCCESS) {
        status = psa_key_derivation_input_bytes(&op,
                                                PSA_KEY_DERIVATION_INPUT_INFO,
                                                k_wrap_info,
                                                sizeof(k_wrap_info) - 1U);
    }
    if (status == PSA_SUCCESS) {
        psa_set_key_usage_flags(&attr,
                                PSA_KEY_USAGE_ENCRYPT | PSA_KEY_USAGE_DECRYPT);
        psa_set_key_algorithm(&attr, SPDM_DEV_WRAP_ALG);
        psa_set_key_type(&attr, PSA_KEY_TYPE_AES);
        psa_set_key_bits(&attr, SPDM_DEV_WRAP_KEY_BITS);
        status = psa_key_derivation_output_key(&attr, &op, key_id);
    }

    psa_reset_key_attributes(&attr);
    (void)psa_key_derivation_abort(&op);
    (void)psa_destroy_key(huk_id);
    return status;
}

/** Unwrap the device private scalar: nonce(12) || ct(32) || tag(16). */
static psa_status_t spdm_device_unwrap(const uint8_t *wrapped, size_t wrapped_len,
                                       uint8_t *out, size_t out_cap,
                                       size_t *out_len)
{
    psa_key_id_t key_id = PSA_KEY_ID_NULL;
    psa_status_t status;
    psa_status_t dstatus;

    if ((wrapped == NULL) || (out == NULL) || (out_len == NULL)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (wrapped_len < SPDM_DEV_WRAP_OVERHEAD) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }

    status = spdm_device_wrap_key(&key_id);
    if (status != PSA_SUCCESS) {
        return status;
    }

    status = psa_aead_decrypt(key_id, SPDM_DEV_WRAP_ALG,
                              wrapped, SPDM_DEV_GCM_NONCE,
                              NULL, 0U,
                              wrapped + SPDM_DEV_GCM_NONCE,
                              wrapped_len - SPDM_DEV_GCM_NONCE,
                              out, out_cap, out_len);
    dstatus = psa_destroy_key(key_id);
    return (status != PSA_SUCCESS) ? status : dstatus;
}

/******************************************************************************
 * Device-identity signing (ECDSA P-256/P-384/P-521)
 *****************************************************************************/
#if SPDM_HAVE_ECDSA

/* Randomised ECDSA over the profile's device-key hash -- the algorithm the ECDSA
 * device key uses. Randomised (not deterministic) so MXCRYPTOLITE accelerates
 * it. Must match the algorithm the provisioning application signed with. */
#define SPDM_DEV_ECDSA_SIGN_ALG PSA_ALG_ECDSA(SPDM_DEV_HASH_ALG)

/* Private-scalar and wrapped-blob geometry for the device-key curve:
 * wrapped = nonce(12) || ct(scalar) || tag(16). The raw scalar is the curve's
 * coordinate length (32 / 48 / 66 bytes for P-256 / P-384 / P-521). */
#define SPDM_DEV_PRIV_LEN       (SPDM_DEV_EC_BYTES)
#define SPDM_DEV_WRAP_LEN       (SPDM_DEV_PRIV_LEN + SPDM_DEV_WRAP_OVERHEAD)

/* Upper bound on the slot-0 key payload: header + raw public point (2*scalar)
 * + wrapped scalar (scalar + overhead), rounded up for margin. P-256 -> 140,
 * P-521 -> 242. */
#define SPDM_DEV_KEY_PAYLOAD_MAX \
    (16U + (2U * SPDM_DEV_EC_BYTES) + SPDM_DEV_WRAP_LEN)

psa_status_t spdm_crypto_device_sign(bool is_data_hash,
                                     const uint8_t *message, size_t message_size,
                                     uint8_t *signature, size_t signature_cap,
                                     size_t *signature_size)
{
    uint8_t payload[SPDM_DEV_KEY_PAYLOAD_MAX];
    uint8_t priv[SPDM_DEV_PRIV_LEN];
    const uint8_t *wrapped = NULL;
    uint16_t wrapped_len = 0U;
    uint32_t got = 0U;
    size_t priv_len = 0U;
    size_t sig_len = 0U;
    psa_key_attributes_t attr = PSA_KEY_ATTRIBUTES_INIT;
    psa_key_id_t key_id = PSA_KEY_ID_NULL;
    psa_status_t status;

    if ((message == NULL) || (signature == NULL) || (signature_size == NULL)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (signature_cap < SPDM_CRYPTO_SIG_LEN) {
        return PSA_ERROR_BUFFER_TOO_SMALL;
    }
    *signature_size = 0U;

    /* 1. Read the slot-0 key payload and locate the wrapped private scalar. */
    if (pas_slot_read(SPDM_DEV_KEY_SLOT, 0U, payload, sizeof(payload), &got)
        != PAS_OK) {
        return PSA_ERROR_DOES_NOT_EXIST;
    }
    if (key_slot_get_wrapped(payload, got, &wrapped, &wrapped_len) != 0) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (wrapped_len != SPDM_DEV_WRAP_LEN) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }

    /* 2. Unwrap the private scalar with the HUK-derived key. */
    status = spdm_device_unwrap(wrapped, wrapped_len, priv, sizeof(priv),
                                &priv_len);
    if ((status != PSA_SUCCESS) || (priv_len != SPDM_DEV_PRIV_LEN)) {
        (void)memset(priv, 0, sizeof(priv));
        return (status == PSA_SUCCESS) ? PSA_ERROR_INVALID_ARGUMENT : status;
    }

    /* 3. Import the key pair, sign once, then destroy it. */
    psa_set_key_usage_flags(&attr,
                            PSA_KEY_USAGE_SIGN_HASH | PSA_KEY_USAGE_SIGN_MESSAGE);
    psa_set_key_algorithm(&attr, SPDM_DEV_ECDSA_SIGN_ALG);
    psa_set_key_type(&attr, PSA_KEY_TYPE_ECC_KEY_PAIR(SPDM_DEV_EC_FAMILY));
    psa_set_key_bits(&attr, SPDM_DEV_EC_BITS);
    status = psa_import_key(&attr, priv, priv_len, &key_id);
    psa_reset_key_attributes(&attr);
    (void)memset(priv, 0, sizeof(priv));
    if (status != PSA_SUCCESS) {
        return status;
    }

    if (is_data_hash) {
        /* message is the pre-computed digest: sign it directly. */
        status = psa_sign_hash(key_id, SPDM_DEV_ECDSA_SIGN_ALG,
                               message, message_size,
                               signature, signature_cap, &sig_len);
    } else {
        /* message is the raw data: hash-then-sign. */
        status = psa_sign_message(key_id, SPDM_DEV_ECDSA_SIGN_ALG,
                                  message, message_size,
                                  signature, signature_cap, &sig_len);
    }
    (void)psa_destroy_key(key_id);

    if (status != PSA_SUCCESS) {
        return status;
    }
    if (sig_len != SPDM_CRYPTO_SIG_LEN) {
        return PSA_ERROR_GENERIC_ERROR;
    }
    *signature_size = sig_len;
    return PSA_SUCCESS;
}
#endif /* SPDM_HAVE_ECDSA */

/******************************************************************************
 * Ephemeral ECDHE key exchange (P-256/P-384/P-521) -- context pool + API
 *****************************************************************************/
#if SPDM_HAVE_ECDHE

/* Ephemeral ECDHE context pool. Only one secure session is supported
 * (MAX_SESSION_COUNT == 1); two slots give headroom for an in-flight
 * generate/compute overlap. */
#define SPDM_EC_POOL_COUNT      (2U)

typedef struct {
    bool         in_use;
    psa_key_id_t key_id;
} spdm_ec_slot_t;

static spdm_ec_slot_t g_ec_pool[SPDM_EC_POOL_COUNT];

static spdm_ec_slot_t *ec_slot_from_op(spdm_crypto_ec_op_t op)
{
    if ((op < 1) || (op > (spdm_crypto_ec_op_t)SPDM_EC_POOL_COUNT)) {
        return NULL;
    }
    spdm_ec_slot_t *slot = &g_ec_pool[op - 1];
    return slot->in_use ? slot : NULL;
}

psa_status_t spdm_crypto_ec_new(spdm_crypto_ec_op_t *op)
{
    if (op == NULL) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    *op = SPDM_CRYPTO_EC_OP_NONE;

    for (uint32_t i = 0U; i < SPDM_EC_POOL_COUNT; i++) {
        if (!g_ec_pool[i].in_use) {
            g_ec_pool[i].in_use = true;
            g_ec_pool[i].key_id = PSA_KEY_ID_NULL;
            *op = (spdm_crypto_ec_op_t)(i + 1U);
            return PSA_SUCCESS;
        }
    }
    return PSA_ERROR_INSUFFICIENT_MEMORY;
}

psa_status_t spdm_crypto_ec_generate(spdm_crypto_ec_op_t op,
                                     uint8_t *public_key, size_t public_key_cap,
                                     size_t *public_key_size)
{
    spdm_ec_slot_t *slot = ec_slot_from_op(op);
    psa_key_attributes_t attr = PSA_KEY_ATTRIBUTES_INIT;
    uint8_t pub_full[1U + SPDM_CRYPTO_EC_PUB_LEN];   /* 0x04 || X || Y */
    size_t out_len = 0U;
    psa_status_t status;

    if ((slot == NULL) || (public_key == NULL) || (public_key_size == NULL)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (public_key_cap < SPDM_CRYPTO_EC_PUB_LEN) {
        return PSA_ERROR_BUFFER_TOO_SMALL;
    }
    *public_key_size = 0U;
    if (slot->key_id != PSA_KEY_ID_NULL) {
        return PSA_ERROR_BAD_STATE;   /* key already generated for this context */
    }

    psa_set_key_usage_flags(&attr, PSA_KEY_USAGE_DERIVE);
    psa_set_key_algorithm(&attr, PSA_ALG_ECDH);
    psa_set_key_type(&attr, PSA_KEY_TYPE_ECC_KEY_PAIR(SPDM_KEX_EC_FAMILY));
    psa_set_key_bits(&attr, SPDM_KEX_EC_BITS);
    status = psa_generate_key(&attr, &slot->key_id);
    psa_reset_key_attributes(&attr);
    if (status != PSA_SUCCESS) {
        slot->key_id = PSA_KEY_ID_NULL;
        return status;
    }

    status = psa_export_public_key(slot->key_id, pub_full, sizeof(pub_full),
                                   &out_len);
    if ((status != PSA_SUCCESS) || (out_len != sizeof(pub_full)) ||
        (pub_full[0] != 0x04U)) {
        (void)psa_destroy_key(slot->key_id);
        slot->key_id = PSA_KEY_ID_NULL;
        return (status == PSA_SUCCESS) ? PSA_ERROR_GENERIC_ERROR : status;
    }

    (void)memcpy(public_key, &pub_full[1], SPDM_CRYPTO_EC_PUB_LEN);
    *public_key_size = SPDM_CRYPTO_EC_PUB_LEN;
    return PSA_SUCCESS;
}

psa_status_t spdm_crypto_ec_compute(spdm_crypto_ec_op_t op,
                                    const uint8_t *peer_public,
                                    size_t peer_public_size,
                                    uint8_t *secret, size_t secret_cap,
                                    size_t *secret_size)
{
    spdm_ec_slot_t *slot = ec_slot_from_op(op);
    uint8_t peer_full[1U + SPDM_CRYPTO_EC_PUB_LEN];   /* 0x04 || X || Y */

    if ((slot == NULL) || (peer_public == NULL) || (secret == NULL) ||
        (secret_size == NULL)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (slot->key_id == PSA_KEY_ID_NULL) {
        return PSA_ERROR_BAD_STATE;   /* generate() has not run */
    }
    if (peer_public_size != SPDM_CRYPTO_EC_PUB_LEN) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (secret_cap < SPDM_CRYPTO_EC_SECRET_LEN) {
        return PSA_ERROR_BUFFER_TOO_SMALL;
    }
    *secret_size = 0U;

    /* PSA expects the uncompressed point form 0x04 || X || Y. */
    peer_full[0] = 0x04U;
    (void)memcpy(&peer_full[1], peer_public, SPDM_CRYPTO_EC_PUB_LEN);

    return psa_raw_key_agreement(PSA_ALG_ECDH, slot->key_id,
                                 peer_full, sizeof(peer_full),
                                 secret, secret_cap, secret_size);
}

psa_status_t spdm_crypto_ec_free(spdm_crypto_ec_op_t op)
{
    spdm_ec_slot_t *slot = ec_slot_from_op(op);
    if (slot == NULL) {
        /* Freeing an unknown / already-released handle is a no-op success. */
        return PSA_SUCCESS;
    }
    if (slot->key_id != PSA_KEY_ID_NULL) {
        (void)psa_destroy_key(slot->key_id);
        slot->key_id = PSA_KEY_ID_NULL;
    }
    slot->in_use = false;
    return PSA_SUCCESS;
}

#endif /* SPDM_HAVE_ECDHE */

#if SPDM_HAVE_MLDSA87
/******************************************************************************
 * Device-identity signing (ML-DSA-87) -- PQC suite
 *
 * Same PAS slot-0 / HUK-unwrap trust model as the ECDSA path above, but the
 * private key is an ML-DSA-87 (FIPS 204, category 5) key and signing is done by
 * wolfCrypt. The signature is a pure ML-DSA signature over the caller's message
 * with the supplied FIPS-204 signing context (the SPDM per-op-code
 * signing-context string), matching a libspdm requester's verification.
 *****************************************************************************/

/* ML-DSA-87 raw private key / wrapped-blob geometry (must match the provisioner:
 * wrapped = nonce(12) || ct(priv) || tag(16) = priv + SPDM_DEV_WRAP_OVERHEAD). */
#define SPDM_DEV_MLDSA_PRIV_LEN     (4896U)
#define SPDM_DEV_MLDSA_WRAP_LEN     (SPDM_DEV_MLDSA_PRIV_LEN + SPDM_DEV_WRAP_OVERHEAD) /* 4924 */

/* wolfCrypt working objects are large (a dilithium_key embeds the 2592-byte
 * public and 4896-byte private key); keep the persistent key/RNG in static
 * secure BSS. The wrapped blob and unwrapped private key are transient: they
 * are freed before wc_MlDsaKey_SignCtx allocates its ~26 KB working set, so
 * they live on the heap to keep that ~9.6 KB out of steady-state BSS (which in
 * turn grows the leftover-sized heap that the signer draws from). Only one SPDM
 * session signs at a time; s_mldsa_busy guards against re-entrancy. */
static dilithium_key s_mldsa_key;
static WC_RNG        s_mldsa_rng;
static bool          s_mldsa_busy;

psa_status_t spdm_crypto_device_sign_mldsa87(const uint8_t *context,
                                             size_t context_size,
                                             const uint8_t *message,
                                             size_t message_size,
                                             uint8_t *signature,
                                             size_t signature_cap,
                                             size_t *signature_size)
{
    uint8_t hdr[KEY_SLOT_HDR_LEN];
    uint16_t pub_len;
    uint16_t wrapped_len = 0U;
    uint32_t got = 0U;
    size_t priv_len = 0U;
    word32 out_sig_len = 0U;
    psa_status_t status = PSA_ERROR_GENERIC_ERROR;
    uint8_t *wrapped = NULL;
    uint8_t *priv = NULL;
    bool key_init = false;
    bool rng_init = false;
    int ret;

    if ((message == NULL) || (signature == NULL) || (signature_size == NULL)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if ((context == NULL) && (context_size != 0U)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (signature_cap < SPDM_CRYPTO_MLDSA87_SIG_LEN) {
        return PSA_ERROR_BUFFER_TOO_SMALL;
    }
    if ((message_size > (size_t)UINT32_MAX) ||
        (context_size > (size_t)UINT32_MAX) ||
        (signature_cap > (size_t)UINT32_MAX)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    *signature_size = 0U;

    if (s_mldsa_busy) {
        return PSA_ERROR_BAD_STATE;
    }
    s_mldsa_busy = true;

    /* 1. Read the slot-0 header to locate the wrapped private key, then read
     *    just the wrapped blob (the public key is not needed for signing). */
    if (pas_slot_read(SPDM_DEV_KEY_SLOT, 0U, hdr, sizeof(hdr), &got) != PAS_OK) {
        status = PSA_ERROR_DOES_NOT_EXIST;
        goto cleanup;
    }
    if (got != KEY_SLOT_HDR_LEN) {
        status = PSA_ERROR_INVALID_ARGUMENT;
        goto cleanup;
    }
    pub_len = (uint16_t)((uint16_t)hdr[0] | ((uint16_t)hdr[1] << 8));
    wrapped_len = (uint16_t)((uint16_t)hdr[2] | ((uint16_t)hdr[3] << 8));
    if (wrapped_len != SPDM_DEV_MLDSA_WRAP_LEN) {
        status = PSA_ERROR_INVALID_ARGUMENT;
        goto cleanup;
    }

    /* Both buffers are freed before the signer's ~26 KB allocation, so keep
     * them on the heap rather than in steady-state secure BSS. */
    wrapped = malloc(wrapped_len);
    priv = malloc(SPDM_DEV_MLDSA_PRIV_LEN);
    if ((wrapped == NULL) || (priv == NULL)) {
        status = PSA_ERROR_INSUFFICIENT_MEMORY;
        goto cleanup;
    }

    if (pas_slot_read(SPDM_DEV_KEY_SLOT,
                      (uint32_t)KEY_SLOT_HDR_LEN + (uint32_t)pub_len,
                      wrapped, wrapped_len, &got) != PAS_OK) {
        status = PSA_ERROR_DOES_NOT_EXIST;
        goto cleanup;
    }
    if (got != wrapped_len) {
        status = PSA_ERROR_INVALID_ARGUMENT;
        goto cleanup;
    }

    /* 2. Unwrap the private key with the HUK-derived key, then release the
     *    wrapped blob so its heap is free for the signer. */
    status = spdm_device_unwrap(wrapped, wrapped_len,
                                priv, SPDM_DEV_MLDSA_PRIV_LEN, &priv_len);
    if ((status != PSA_SUCCESS) || (priv_len != SPDM_DEV_MLDSA_PRIV_LEN)) {
        status = (status == PSA_SUCCESS) ? PSA_ERROR_INVALID_ARGUMENT : status;
        goto cleanup;
    }
    (void)memset(wrapped, 0, wrapped_len);
    free(wrapped);
    wrapped = NULL;

    /* 3. Import the private key, sign once with the FIPS-204 context. */
    status = PSA_ERROR_GENERIC_ERROR;
    ret = wc_MlDsaKey_Init(&s_mldsa_key, NULL, INVALID_DEVID);
    if (ret == 0) {
        key_init = true;
        ret = wc_MlDsaKey_SetParams(&s_mldsa_key, WC_ML_DSA_87);
    }
    if (ret == 0) {
        ret = wc_MlDsaKey_ImportPrivRaw(&s_mldsa_key, priv, (word32)priv_len);
        /* Key is now copied into s_mldsa_key; release the private-key heap so
         * it is available for the signer's ~26 KB working set. */
        (void)memset(priv, 0, SPDM_DEV_MLDSA_PRIV_LEN);
        free(priv);
        priv = NULL;
    }
    if (ret == 0) {
        ret = wc_InitRng(&s_mldsa_rng);
        if (ret == 0) {
            rng_init = true;
        }
    }
    if (ret == 0) {
        out_sig_len = (word32)signature_cap;
        ret = wc_MlDsaKey_SignCtx(&s_mldsa_key,
                                  context, (word32)context_size,
                                  signature, &out_sig_len,
                                  message, (word32)message_size,
                                  &s_mldsa_rng);
    }
    if ((ret == 0) && (out_sig_len == SPDM_CRYPTO_MLDSA87_SIG_LEN)) {
        *signature_size = (size_t)out_sig_len;
        status = PSA_SUCCESS;
    } else if (ret == 0) {
        status = PSA_ERROR_GENERIC_ERROR;
    }

cleanup:
    if (priv != NULL) {
        (void)memset(priv, 0, SPDM_DEV_MLDSA_PRIV_LEN);
        free(priv);
    }
    if (wrapped != NULL) {
        (void)memset(wrapped, 0, wrapped_len);
        free(wrapped);
    }
    if (rng_init) {
        (void)wc_FreeRng(&s_mldsa_rng);
    }
    if (key_init) {
        (void)wc_MlDsaKey_Free(&s_mldsa_key);
    }
    s_mldsa_busy = false;
    return status;
}
#endif /* SPDM_HAVE_MLDSA87 */

#if SPDM_HAVE_MLKEM1024
/******************************************************************************
 * Key establishment (ML-KEM-1024 encapsulate) -- PQC suite
 *
 * Decodes the requester's raw ML-KEM-1024 public key, runs one encapsulate and
 * returns the ciphertext + shared secret. Unlike the ML-DSA signer there is no
 * persistent key object: the MlKemKey and wolfCrypt's encapsulate working set
 * are both transient, so the key is heap-allocated and freed within the call
 * (WOLFSSL_MLKEM_ENCAPSULATE_SMALL_MEM caps that working set at a few KB). This
 * runs before the ML-DSA sign in the same KEY_EXCHANGE, so its peak reuses the
 * heap high-water mark rather than adding steady-state secure BSS. Only one
 * session establishes a key at a time; s_mlkem_busy guards re-entrancy.
 *****************************************************************************/

static bool s_mlkem_busy;

psa_status_t spdm_crypto_mlkem_encapsulate(const uint8_t *peer_encap_key,
                                           size_t peer_encap_key_size,
                                           uint8_t *cipher_text,
                                           size_t cipher_text_cap,
                                           size_t *cipher_text_size,
                                           uint8_t *shared_secret,
                                           size_t shared_secret_cap,
                                           size_t *shared_secret_size)
{
    MlKemKey *key = NULL;
    WC_RNG   rng;
    bool     key_init = false;
    bool     rng_init = false;
    psa_status_t status = PSA_ERROR_GENERIC_ERROR;
    int ret;

    if ((peer_encap_key == NULL) || (cipher_text == NULL) ||
        (shared_secret == NULL) || (cipher_text_size == NULL) ||
        (shared_secret_size == NULL)) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if (peer_encap_key_size != SPDM_CRYPTO_MLKEM1024_PUB_LEN) {
        return PSA_ERROR_INVALID_ARGUMENT;
    }
    if ((cipher_text_cap < SPDM_CRYPTO_MLKEM1024_CT_LEN) ||
        (shared_secret_cap < SPDM_CRYPTO_MLKEM1024_SS_LEN)) {
        return PSA_ERROR_BUFFER_TOO_SMALL;
    }
    *cipher_text_size = 0U;
    *shared_secret_size = 0U;

    if (s_mlkem_busy) {
        return PSA_ERROR_BAD_STATE;
    }
    s_mlkem_busy = true;

    /* The key object and encapsulate working set are transient; keep them on
     * the heap so they stay out of steady-state secure BSS. */
    key = malloc(sizeof(*key));
    if (key == NULL) {
        status = PSA_ERROR_INSUFFICIENT_MEMORY;
        goto cleanup;
    }

    ret = wc_MlKemKey_Init(key, WC_ML_KEM_1024, NULL, INVALID_DEVID);
    if (ret == 0) {
        key_init = true;
        ret = wc_MlKemKey_DecodePublicKey(key, peer_encap_key,
                                          (word32)peer_encap_key_size);
        if (ret != 0) {
            status = PSA_ERROR_INVALID_ARGUMENT;
        }
    }
    if (ret == 0) {
        ret = wc_InitRng(&rng);
        if (ret == 0) {
            rng_init = true;
        }
    }
    if (ret == 0) {
        ret = wc_MlKemKey_Encapsulate(key, cipher_text, shared_secret, &rng);
    }
    if (ret == 0) {
        *cipher_text_size = SPDM_CRYPTO_MLKEM1024_CT_LEN;
        *shared_secret_size = SPDM_CRYPTO_MLKEM1024_SS_LEN;
        status = PSA_SUCCESS;
    }

cleanup:
    if (rng_init) {
        (void)wc_FreeRng(&rng);
    }
    if (key_init) {
        (void)wc_MlKemKey_Free(key);
    }
    if (key != NULL) {
        free(key);
    }
    s_mlkem_busy = false;
    return status;
}
#endif /* SPDM_HAVE_MLKEM1024 */

/* [] END OF FILE */
