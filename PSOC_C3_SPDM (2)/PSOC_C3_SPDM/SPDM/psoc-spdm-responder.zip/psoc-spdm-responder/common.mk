################################################################################
# \file common.mk
# \version 1.0
#
# \brief
# Settings shared across all projects.
#
################################################################################
# \copyright
# (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
# Technologies AG.  SPDX-License-Identifier: Apache-2.0
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################

MTB_TYPE=PROJECT

# Target board/hardware (BSP).
# To change the target, it is recommended to use the Library manager
# ('make library-manager' from command line), which will also update Eclipse IDE launch
# configurations.
TARGET=APP_KIT_PSC3M6_EVAL

# Name of toolchain to use. Options include:
#
# GCC_ARM -- GCC provided with ModusToolbox software
# ARM     -- ARM Compiler (must be installed separately)
# IAR     -- IAR Compiler (must be installed separately)
#
# See also: CY_COMPILER_PATH below
TOOLCHAIN=GCC_ARM

# Map the selected TARGET to exactly one device-guard macro. Device-specific
# source (e.g. the secure TrustZone bring-up in proj_cm33_s/main.c) is gated on
# these macros. PSC3M5 is the odd one out: it hand-configures SAU + PPC in
# firmware, whereas PSC3M6/PSC3M8 (and later devices) have SAU/MPC/PPC generated
# by the Device Configurator (design.modus) and applied inside cybsp_init(). Add
# one line per new board; the positive DEVICE_PSC3M5 guard keeps the manual
# bring-up compiled in only where it is needed. PSC3M8 is a multicore part but
# only its main CM33 (TrustZone) core is used here, so it tracks PSC3M6.
ifeq ($(TARGET),APP_KIT_PSC3M5_EVK)
DEVICE_GUARD=DEVICE_PSC3M5
else ifeq ($(TARGET),APP_KIT_PSC3M6_EVAL)
DEVICE_GUARD=DEVICE_PSC3M6
else ifeq ($(TARGET),APP_KIT_PSC3M8_EVK)
DEVICE_GUARD=DEVICE_PSC3M8
endif
ifneq ($(DEVICE_GUARD),)
DEFINES+=$(DEVICE_GUARD)
endif

# SPDM profile selector (build-time, exclusive). A profile is a cipher-suite
# bundle chosen by include path: the build adds profiles/$(SPDM_PROFILE) to the
# include path and every consumer does a fixed #include "profile.h". See
# profiles/ for the available profiles (each profiles/<name>/profile.h documents
# its cipher suite) and profiles/_template to author one. Each platform's
# detect_platform.mk lists the profiles its device can run
# (SPDM_PROFILES_SUPPORTED).
#
# The selected profile.h defines the orthogonal SPDM_HAVE_* capability flags the
# app/config headers derive from; profile.mk carries the build-graph delta.
SPDM_PROFILE ?= P4
SPDM_PROFILE_DIR := ../profiles/$(SPDM_PROFILE)
ifeq ($(wildcard $(SPDM_PROFILE_DIR)/profile.h),)
$(error Unknown SPDM_PROFILE '$(SPDM_PROFILE)' (no profiles/$(SPDM_PROFILE)/profile.h))
endif
include $(SPDM_PROFILE_DIR)/profile.mk

# Auto-detect PLATFORM from TARGET so each device pins its own dependency
# versions (see platforms/$(PLATFORM)/deps, selected via CY_GETLIBS_DEPS_PATH in
# the project Makefiles). Each platforms/*/detect_platform.mk sets PLATFORM for
# its own TARGET list; add a new board there rather than editing this file.
-include $(wildcard ../platforms/*/detect_platform.mk)
ifndef PLATFORM
$(error Unrecognized TARGET='$(TARGET)'. Add it to a platforms/*/detect_platform.mk to set PLATFORM)
endif

# Each platform lists the profiles it can run (SPDM_PROFILES_SUPPORTED, set in
# its detect_platform.mk). Reject a profile the selected device cannot support.
ifeq ($(filter $(SPDM_PROFILE),$(SPDM_PROFILES_SUPPORTED)),)
$(error SPDM_PROFILE='$(SPDM_PROFILE)' is not supported on $(PLATFORM) (supported: $(SPDM_PROFILES_SUPPORTED)))
endif

# Secure/non-secure partition split for the SPDM Responder application.
#
# The SPDM engine (libspdm) runs entirely in the NON-secure app (proj_cm33_ns);
# the secure app (proj_cm33_s) holds only the device private key (PAS slot 0)
# and the PSA crypto that uses it, exposed to NS through NSC veneers (added in
# later stages). The secure partition is sized now (32 KB SRAM / 100 KB flash)
# to match that future secure PSA/mbedTLS crypto footprint so the memory map
# does not change (and the device does not need re-provisioning) once crypto is
# added.
#
# This is the single source of truth for the secure split: proj_cm33_s/Makefile
# derives USER_SRAM_S_SIZE / USER_FLASH_S_SIZE from these. The MPC RAM & flash
# splits in ns_policy/policy_oem_provisioning.json must still be kept in sync by
# hand (re-provision after changing). Total on-chip SRAM is 64 KB; total flash
# is 256 KB.
#
# PSC3M5 only: on PSC3M6/PSC3M8 the memory map is owned entirely by the Device
# Configurator (design.modus -> generated cymem_*.ld / partition_psc3.h), so
# these knobs are defined-but-unused there and are guarded out to avoid a second
# (conflicting) source of truth. _size_S_* feeds the linker; USER_*_S_SIZE feeds
# partition_psc3.h -> TZ_SAU_Setup(), which is itself M5-only.
ifeq ($(TARGET),APP_KIT_PSC3M5_EVK)
SECURE_SRAM_SIZE=0x8000
SECURE_FLASH_SIZE=0x19000

ifeq ($(TOOLCHAIN),IAR)
LDFLAGS+=--config_def _size_S_SRAM=$(SECURE_SRAM_SIZE) --config_def _size_S_FLASH=$(SECURE_FLASH_SIZE)
else ifeq ($(TOOLCHAIN),GCC_ARM)
LDFLAGS+=-Wl,--defsym=_size_S_SRAM=$(SECURE_SRAM_SIZE),--defsym=_size_S_FLASH=$(SECURE_FLASH_SIZE)
else ifeq ($(TOOLCHAIN),ARM)
LDFLAGS+=--predefine="-D_size_S_SRAM=$(SECURE_SRAM_SIZE)" --predefine="-D_size_S_FLASH=$(SECURE_FLASH_SIZE)"
endif
endif

# Post-build combine (PSC3M6 and later). Each project is linked at its C-BUS
# execution alias, but the flash programmer needs the S-BUS programmable alias.
# This recipe relocates each project hex C-BUS->S-BUS and merges them into a
# single build/app_combined.hex; the {{ CYMEM_* }} tokens are resolved from the
# secure ELF so the addresses track the generated M6/M8 memory map. On PSC3M5
# each project is already linked at its S-BUS alias and the build system merges
# them automatically, so no combine recipe is needed there.
ifneq ($(TARGET),APP_KIT_PSC3M5_EVK)
COMBINE_SIGN_JSON ?= configs/signer_combiner.json
endif

# Default build configuration. Options include:
#
# Debug -- build with minimal optimizations, focus on debugging.
# Release -- build with full optimizations
# Custom -- build with custom configuration, set the optimization flag in CFLAGS
# 
# If CONFIG is manually edited, ensure to update or regenerate launch configurations 
# for your IDE.
CONFIG=Debug

include ../common_app.mk
