# PSOC&trade; Control C3 MCU: SPDM Responder (device application)

This code example implements an on-device **SPDM Responder** for the PSOC&trade;
Control C3 MCU. The device answers SPDM (Security Protocol and Data Model)
requests from a host **SPDM Requester** to provide:

1. **Identity / authenticity** &mdash; the device proves who it is with the
   provisioned device key and certificate chain
   (`GET_VERSION` &rarr; `GET_CAPABILITIES` &rarr; `NEGOTIATE_ALGORITHMS` &rarr;
   `GET_DIGESTS` &rarr; `GET_CERTIFICATE` &rarr; `CHALLENGE`/`CHALLENGE_AUTH`).
2. **Measurements / state** &mdash; the device reports signed measurements of
   its firmware and configuration (`GET_MEASUREMENTS`).
3. **Secure session** &mdash; a key exchange (`KEY_EXCHANGE`/`FINISH`)
   establishes an AES-256-GCM encrypted channel over the transport.

**Attestation** is the combination of the first two: identity (who the device
is) plus measurements (what state it is in).

The SPDM engine is [libspdm](https://github.com/DMTF/libspdm) (pinned to
4.0.0-rc), which runs entirely in the **non-secure** application. The device
private key and all cryptography that touches it stay in the **secure**
application and are reached over Non-Secure-Callable (NSC) veneers &mdash; a
two-project (secure + non-secure) TrustZone&reg; structure.

### Cipher profiles (`SPDM_PROFILE`)

The responder is built for exactly **one** cipher *profile*, selected at build
time by the `SPDM_PROFILE` make variable (there is no runtime negotiation
between profiles). Each profile lives in its own folder under
*profiles/&lt;name&gt;/* and is a small truth table of five algorithm selectors
(signature, base hash, measurement hash, key exchange, AEAD) that the build and
the SPDM capability advertisement derive from. Four profiles are shipped today,
`P1`&ndash;`P4`:

| `SPDM_PROFILE` | SPDM version | Signature / KEM | Hash | Compliance | Kits |
| -------------- | ------------ | --------------- | ---- | ---------- | ---- |
| `P1` | up to 1.4 (tested at 1.4) | ECDSA / ECDHE **P-256** | SHA-256 | &mdash; | PSC3M5, PSC3M6 and PSC3M8 |
| `P2` | up to 1.4 | ECDSA / ECDHE **P-384** | SHA-384 | CNSA 1.0 | PSC3M5, PSC3M6 and PSC3M8 |
| `P3` | up to 1.4 | ECDSA / ECDHE **P-521** | SHA-512 | &mdash; | PSC3M5, PSC3M6 and PSC3M8 |
| `P4` (default) | 1.4 | **ML-DSA-87** / **ML-KEM-1024** (PQC) | SHA-384 | CNSA 2.0 | PSC3M6 and PSC3M8 |

All four profiles share AES-256-GCM for the secure session. `P1`&ndash;`P3` run
their crypto entirely on PSA / mbedTLS. `P4` additionally pulls **wolfCrypt**
into the secure
project for ML-DSA-87 signing and ML-KEM-1024 encapsulation; it is
PSC3M6/PSC3M8-only because of the extra SRAM/flash footprint. Build a specific
profile with, for example,
`make build TARGET=APP_KIT_PSC3M6_EVAL SPDM_PROFILE=P4`. The device must be
provisioned with an identity chain that matches the selected profile (an ECDSA
P-256/P-384/P-521 chain for `P1`&ndash;`P3`, an ML-DSA-87 chain for `P4`).

Which profiles a given kit may build is declared per device in
*platforms/&lt;platform&gt;/detect_platform.mk* (the `SPDM_PROFILES_SUPPORTED`
allow-list); the build errors out if you select a profile a kit does not list.
To compose your own profile, copy *profiles/_template/* to a new
*profiles/&lt;name&gt;/* and edit its *profile.h* &mdash; see the
[custom-profile authoring guide](docs/implementation.md) in
*docs/implementation.md* for the five selectors and the rules the build
enforces.

### Provisioning

Two independent kinds of provisioning are involved; keep them distinct:

- **SPDM asset provisioning** &mdash; for the responder to answer requests, the
  device must already be provisioned with the SPDM assets it serves: the device
  key (PAS slot 0) and the host-assembled certificate chain (in a PAS slot).
- **Device OEM Policy provisioning** &mdash; on **KIT_PSC3M5_EVK** this
  application requires an OEM policy that configures the secure/non-secure memory
  split (MPC) so the two projects can run; see [Operation](#operation), step 4.
  On **KIT_PSC3M6_EVAL** and **KIT_PSC3M8_EVK** the split is owned by the Device
  Configurator (*design.modus*) and applied during `cybsp_init()`, so no OEM
  policy is needed. This is separate from the SPDM asset provisioning above and
  unrelated to the assets the responder serves.

See [Implementation](docs/implementation.md) for the
project structure, build infrastructure, memory split, and initialization flow,
and [Architecture and security](docs/architecture_and_security.md) for the threat
model, trust boundaries, security properties, and design rationale.


## Requirements

- [ModusToolbox&trade;](https://www.infineon.com/modustoolbox) v3.9 or later
- Board support package (BSP) minimum required version for:
   - KIT_PSC3M5_EVK : v3.0.1
   - KIT_PSC3M6_EVAL: v1.0.0
   - KIT_PSC3M8_EVK : v2.2.0
- Programming language: C (device firmware)
- Associated parts: [PSOC&trade; Control C3 MCU](https://www.infineon.com/products/microcontroller/32-bit-psoc-arm-cortex/32-bit-psoc-control-arm-cortex-m33-mcu)


## Supported toolchains (make variable 'TOOLCHAIN')

- GNU Arm&reg; Embedded Compiler v14.2.1 (`GCC_ARM`) &ndash; Default value of `TOOLCHAIN`


## Supported kits (make variable 'TARGET')

- [PSOC&trade; Control C3M5 Evaluation Kit](https://www.infineon.com/KIT_PSC3M5_EVK)
   (`APP_KIT_PSC3M5_EVK`)
- [PSOC&trade; Control C3M6 Evaluation Kit](https://www.infineon.com/KIT_PSC3M6_EVAL)
   (`APP_KIT_PSC3M6_EVAL`) &ndash; Default value of `TARGET`
- [PSOC&trade; Control C3M8 Evaluation Kit](https://www.infineon.com/KIT_PSC3M8_EVK)
  (`APP_KIT_PSC3M8_EVK`)


## Hardware setup

This example uses the kit's default configuration. See the kit user guide to
ensure that the kit is configured correctly.

The host communicates with the device over I2C, and the same link carries the
SPDM (DFU) command transport. How that link is provided depends on the kit:

- **KIT_PSC3M5_EVK (M5):** the on-board KitProg3 bridge provides both
  programming/debug and the I2C transport over a single USB cable — no extra
  hardware is required.
- **KIT_PSC3M8_EVK (M8):** same as M5 — the on-board KitProg3 bridge provides
  programming/debug, the UART log, and the I2C transport over a single USB
  cable; no extra hardware is required.
- **KIT_PSC3M6_EVAL (M6):** the on-board SEGGER J-Link handles programming/debug
   only. The I2C transport requires an external USB-I2C bridge. The following
   **MiniProg4** wiring was verified using its **12-pin, 2x6 communication
   header**, not either SWD connector:

   Board connector/pin | Signal | MiniProg4 pin
   :------------------ | :----- | :------------
   J16.5 (P9.0)        | SCL    | Pin 4
   J16.6 (P9.2)        | SDA    | Pin 2
    J15.7               | VTARG (3.3 V) | Pin 1
    J15.8               | GND    | Pin 12

**Correction to the original wiring table:** PSC3M6 **J15.7 is 3.3 V** and
**J15.8 is GND**. The earlier table had these reversed. Do not follow the
reversed mapping in another copy of the example.

A physically detached **KitProg3 section from CY8CPROTO-062-4343W** was also
used as the USB-I2C bridge. Its connector layout differs from MiniProg4:

| Detached KitProg3 connection | Signal | PSC3M6 connection |
| --------------------------- | ------ | ----------------- |
| `P12.1` / `12.1`, connector J7 pin 5 | SDA | J16.6 / P9.2 |
| `P12.0` / `12.0`, connector J7 pin 4 | SCL | J16.5 / P9.0 |
| J4 pin 1, VTARG | 3.3 V reference input | J15.7 / 3.3 V |
| J4 pin 2, GND | Common ground | J15.8 / GND |

`J7.5` means **pin 5 of connector J7**; the board may label that GPIO `12.1`
rather than `J7.5`. J4 is the five-pin SWD connector: **only VTARG and GND
belong there for this I2C setup**. SWDIO and SWDCLK are not SDA and SCL.

For the detached KitProg3, VTARG is an **input** needed for voltage-level
translation, not a power output for the PSC3. Power the PSC3 through its
on-board J-Link USB connector **J13**, and power the bridge through its own
USB connector. Disconnect both USB supplies before rewiring. Do not connect
VBUS/5 V to the PSC3's 3.3 V reference or I2C pins. Do not join independently
driven supply rails if the KitProg3 section is still attached to another board.

The pin assignments were checked against the manufacturer kit guides:
[KIT_PSC3M6_EVAL](https://www.infineon.com/evaluation-board/KIT-PSC3M6-EVAL),
[MiniProg4](https://www.infineon.com/assets/row/public/documents/30/44/infineon-cy8ckit-005-miniprog4-program-and-debug-kit-guide-usermanual-en.pdf), and
[CY8CPROTO-062-4343W](https://www.infineon.com/assets/row/public/documents/30/44/infineon-cy8cproto-062-4343w-psoc-6-wi-fi-bt-prototyping-kit-guide-usermanual-en.pdf)
(KitProg3 connectors: pages 21 and 31).


## Software setup

See the [ModusToolbox&trade; tools package installation guide](https://www.infineon.com/ModusToolboxInstallguide)
for information about installing and configuring the tools package.

**CMake is required to build libspdm.** The SPDM engine
([libspdm](https://github.com/DMTF/libspdm), pinned to 4.0.0-rc) is vendored as a
git submodule and compiled from source into static archives by a CMake build
that the non-secure project runs as a `PREBUILD` step. ModusToolbox&trade; does
not bundle CMake, so install a native **CMake 3.5 or later** and make sure it is
on your `PATH`. ModusToolbox&trade; does bundle **Ninja**, which the build uses
as the CMake generator, so no separate Ninja install is needed.

<details><summary><b>ModusToolbox&trade; Edge Protect Security Suite</b></summary>

The device-policy provisioning step uses the **Edge Protect Tools**
(`edgeprotecttools`) CLI.

1. Download and install the [Infineon Developer Center Launcher](https://www.infineon.com/cms/en/design-support/tools/utilities/infineon-developer-center-idc-launcher).

2. Login using your Infineon credentials.

3. Download and install the "ModusToolbox&trade; Edge Protect Security Suite" from the Developer Center Launcher.

    > **Note:** The default installation directory of the Edge Protect Security Suite on Windows is *C:/Users/`<USER>`/Infineon/Tools*.

4. After installing the Edge Protect Security Suite, add the Edge Protect tools executable to the system PATH variable. The executable is located in *<Edge-Protect-Security-Suite-install-path>/ModusToolbox-Edge-Protect-Security-Suite-`<version>`/tools/edgeprotecttools/bin*.

</details>


## Verified Windows setup and changes (PSC3M6)

The following records the setup completed on **2026-11-10/11**. The successful
outcome was a built and programmed responder, working SPDM negotiation and
certificate-fragment transfers, and an Eclipse import. **A complete
`CHALLENGE_AUTH` run was not finished**; see the verification status below.

### Build defaults and environment

The application defaults in `common.mk` were changed from PSC3M5/P1 to
`TARGET=APP_KIT_PSC3M6_EVAL` and `SPDM_PROFILE=P4`, matching the actual board
and its ML-DSA-87 identity. No manual change to the cryptographic algorithms
was needed for this bring-up.

The working tool combination was ModusToolbox tools **3.9**, GNU Arm **14.2.1**,
native Windows **CMake 3.31.6**, and Edge Protect Security Suite **2.4.0**.
CMake was missing initially and was added as a portable installation. Its
`bin` directory must be on the PATH used by both command-line builds and
Eclipse; ModusToolbox's bundled Ninja was sufficient.

The original deeply nested path contained spaces and parentheses and broke
the Windows/Cygwin build. A temporary `subst P:` mapping to the directory
containing the SPDM applications avoided that problem without copying files.
Prefer a short checkout path for a new installation. `P:` is only a local
alias and must be recreated after a Windows restart if the generated project
paths still use it.

For example, adapt the paths below to your installation. The example assumes
that `P:` maps to the parent containing `psoc-spdm-responder`, and that native
CMake is installed under `C:/Tools/cmake`:

```powershell
$env:CY_TOOLS_PATHS = 'C:/Infineon/Tools/ModusToolbox/tools_3.9'
$env:HOME = $env:USERPROFILE.Replace('\', '/')
$env:PATH = 'C:/Tools/cmake/bin;C:/Infineon/Tools/ModusToolbox/tools_3.9/modus-shell/bin;' + $env:PATH
$make = Join-Path $env:CY_TOOLS_PATHS 'modus-shell/bin/make.exe'
& $make -C P:/psoc-spdm-responder getlibs
& $make -C P:/psoc-spdm-responder build TARGET=APP_KIT_PSC3M6_EVAL SPDM_PROFILE=P4
& $make -C P:/psoc-spdm-responder eclipse TARGET=APP_KIT_PSC3M6_EVAL SPDM_PROFILE=P4 BSP_PROGRAM_INTERFACE=JLink
```

Run the environment setup again in a new shell. Changes to one shell's PATH
do not update an already running Eclipse process. GCC and Edge Protect tools
also need to be discoverable by the IDE build; the local Eclipse starter used
for this setup was extended with the CMake path. This machine-specific starter
is outside the responder repository, so configure your own launcher or IDE
environment for a fresh checkout.

### Repairing stale generated BSP files

The first responder build lacked device-library metadata. Running `make
getlibs` restored it. The Device Configurator then rejected changed/stale
generated symbols. The existing `GeneratedSource` directory was backed up,
and the files were regenerated from the existing `design.modus`:

```powershell
& (Join-Path $env:CY_TOOLS_PATHS 'device-configurator/device-configurator-cli.exe') --build 'P:/psoc-spdm-responder/bsps/TARGET_APP_KIT_PSC3M6_EVAL/config/design.modus' --readonly --force
```

This was a recovery step, not a required action on every build. Back up any
manual generated-file changes before using `--force`. The source
`design.modus` and the PSC3M6 security/lifecycle policy were not changed; the
M6 memory partition comes from the Device Configurator, not M5 OEM-policy
provisioning.

### USB bridge firmware and mode

- The original MiniProg4 was in DAPLink mode, which the Windows DFU host did
   not expose as an I2C bridge. Switching that selected probe to `kp3-hid`
   restored I2C enumeration. Its firmware was not updated during this test.
- The detached CY8CPROTO KitProg3 initially ran firmware **1.01.158**. Its
   firmware was updated, with explicit approval, to **2.90.1804** using the
   installed `fw-loader --update-kp3` command for that probe's serial number.
   This updates the programmer, not the PSC3 application.
- For that updated KitProg3, **`kp3-bulk`** was the mode that actually exposed
   I2C to `dfuh-cli`; HID did not. Do not apply a blanket HID/BULK rule across
   different hardware and firmware versions. Check the actual enumeration with
   `dfuh-cli --display-hw` and select the corresponding `--hwid`.
- The MODE button is not a start button for the SPDM test. No special SPDM
   firmware is needed on KitProg3: the standard firmware supplies the bridge.

The tested I2C address was **0x08**. MiniProg4 worked at **400 kHz**; the final
KitProg3 transfer tests used **100 kHz**. Wrong SWD-vs-I2C connections, reversed
reference/ground wires, disconnected jumpers, USB unplugging, and a laptop
power interruption were encountered during bring-up. Keep the data wires
securely attached and the laptop on external power for long tests. A failed
initial Enter-DFU write (`dfuh-cli` error 3 / exit 8195) happens **before SPDM**
and is not evidence of a certificate or signature rejection.

### Provisioning and programming the responder

The separate provisioning application and host utility were used first. The
Python host environment required **PyYAML** and **cryptography >= 46** for
ML-DSA support; the installed cryptography version was 50.0.2. The device
generated its own ML-DSA-87 key in **PAS slot 0**. A CSR was signed with a demo
CA, and the resulting **15,168-byte** SPDM certificate chain was stored in
**PAS slot 1**, exposed by the responder as **SPDM certificate slot 0**.
Readback matched the uploaded chain byte-for-byte, and the provisioning
`prove-cert` command verified possession of the device key.

The responder was then built and programmed through the PSC3's **on-board
J-Link**, not through the I2C-only KitProg3 wiring. The selected probe variable
was **`MTB_PROBE_SERIAL`**, not `PROBE_SERIAL`; set it to your board's J-Link
serial when multiple probes are connected. Programming and verification
succeeded and retained the provisioned assets. No full-device erase,
`--freeze`/finalize operation, or lifecycle change was performed. Do not erase
the PAS assets when switching between provisioning and responder applications.

### Eclipse export and import

`make eclipse` generated all three projects:

- `psoc-spdm-responder` (application)
- `psoc-spdm-responder.proj_cm33_s` (secure)
- `psoc-spdm-responder.proj_cm33_ns` (non-secure)

Import the application **in place**, with copying into the workspace disabled.
If Eclipse's generic existing-projects importer finds only the application,
import `proj_cm33_s` and `proj_cm33_ns` separately as well. All three were
imported into the existing workspace without replacing its previous projects.

Eclipse initially logged workspace-lock errors while saving imported project
preferences, and interrupted local-history backup jobs on a subsequent load.
Regular exits/restarts after the import completed produced a clean final
session; the workspace and project preferences were not deleted.

Build and Program/Debug use the **J-Link** launch configuration. Eclipse runs
the device firmware; the Windows **SPDM Requester remains a separate host
program**. Opening the project in Eclipse does not automatically run
`CHALLENGE_AUTH` or remove the DFU host's per-transfer overhead.

### Verification status and remaining work

| Check | Observed result |
| ----- | --------------- |
| P4 responder build and programming | Passed; programming verification succeeded |
| Asset provisioning, readback and `prove-cert` | Passed; no freeze/finalize |
| Responder startup | Certificate chain loaded, context ready, I2C listening |
| SPDM negotiation | SPDM 1.4, ML-DSA-87, ML-KEM-1024, SHA-384, AES-256-GCM |
| SPDM certificate transfer | Successful fragments observed; full SPDM certificate validation not completed |
| Eclipse export and import | All three projects imported; clean final restarted session |
| `CHALLENGE_AUTH`, signed measurements, secure session and encrypted exchange | Not verified end-to-end |

The final authentication run was deliberately cancelled before completion to
continue with the Eclipse import. Earlier runs were also interrupted by
physical disconnection or power loss. A manually cancelled run reporting
`SPDM_REQ_EAUTH` is **not** proof of an invalid signature. Provisioning
`prove-cert` is a different check from SPDM `CHALLENGE_AUTH`.

Measured Windows host/bridge initialization took about **11 seconds per DFU
transaction**, while a small actual GET_VERSION exchange completed in under
one second after initialization. Certificate and ML-DSA-87 signature responses
are fragmented into small packets, so a full run can take many minutes.
Allow it to finish uninterrupted before claiming authenticated SPDM success.

For GitHub, publish portable sources, BSP templates, dependency definitions
and the libspdm submodule; exclude build/IDE caches, local test artefacts and
private keys. Do not rely on a developer's personal paths, `P:` mapping or
external Eclipse starter. The provisioning applications and host tools are
separate from this responder repository and must be obtained separately.


## Operation

### 1. Get the project

Obtain the application either by cloning the repository (recommended) or by
extracting the delivered zip package into your working directory:

   ```
   git clone <repo-url>
   ```

The SPDM engine (libspdm) is vendored as a **git submodule** at
`third_party/libspdm`. Whether you cloned the repository or started from the zip
package, populate just that submodule before building:

   ```
   git submodule update --init third_party/libspdm
   ```

> **Note:** Initialize **only** `third_party/libspdm` as shown above (no
> `--recursive`, and avoid `git clone --recurse-submodules`). libspdm has its own
> nested submodules that this application does not build; pulling them is
> unnecessary.


### 2. Create the project

The ModusToolbox&trade; tools package provides the Project Creator as both a GUI
tool and a command line tool.

<details><summary><b>Use Project Creator GUI</b></summary>

1. Open the Project Creator GUI tool.

   There are several ways to do this, including launching it from the dashboard
   or from inside the Eclipse IDE. For more details, see the
   [Project Creator user guide](https://www.infineon.com/assets/row/public/documents/30/44/infineon-modustoolbox-project-creator-user-guide-usermanual-en.pdf)
   (locally available at *{ModusToolbox&trade; install directory}/tools_{version}/project-creator/docs/project-creator.pdf*).

2. On the **Choose Board Support Package (BSP)** page, select a kit supported by
   this code example. See [Supported kits](#supported-kits-make-variable-target).

   > **Note:** To use this code example for a kit not listed here, you may need
   > to update the source files. If the kit does not have the required
   > resources, the application may not work.

3. On the **Select Application** page, use **Browse for application** to point
   the Project Creator at this local *psoc-spdm-responder* folder
   (this code example is not listed among the catalog examples). For details, see section *3.3.4 Browse for application* of the [Project Creator user guide](https://www.infineon.com/assets/row/public/documents/30/44/infineon-modustoolbox-project-creator-user-guide-usermanual-en.pdf).

   a. Select the **Target IDE**.

      > **Note:** Depending on how you open the Project Creator tool, this field
      > may be pre-selected for you.

   b. (Optional) Change the suggested **New Application Name** and **New BSP Name**.

   c. Click **Create** to complete the application creation process.

</details>

<details><summary><b>Use Project Creator CLI</b></summary>

The 'project-creator-cli' tool can be used to create applications from a CLI
terminal or from within batch files or shell scripts. This tool is available in
the *{ModusToolbox&trade; install directory}/tools_{version}/project-creator/*
directory.

Use a CLI terminal to invoke the 'project-creator-cli' tool. On Windows, use the
command-line 'modus-shell' program provided in the ModusToolbox&trade;
installation instead of a standard Windows command-line application. This shell
provides access to all ModusToolbox&trade; tools. You can access it by typing
"modus-shell" in the search box in the Windows menu. In Linux and macOS, you can
use any terminal application.

The following example creates the responder application from this local
*psoc-spdm-responder* template with the desired name "SpdmResponder" configured
for the *KIT_PSC3M5_EVK* BSP into the specified working directory,
*C:/mtb_projects*:

   ```
   project-creator-cli --board-id KIT_PSC3M5_EVK --app-path <path-to>/psoc-spdm-responder --user-app-name SpdmResponder --target-dir "C:/mtb_projects"
   ```

> **Note:** To target the PSOC&trade; Control C3M6 kit instead, pass
> `--board-id KIT_PSC3M6_EVAL`.

The 'project-creator-cli' tool has the following arguments:

Argument | Description | Required/optional
---------|-------------|-----------
`--board-id` | Defined in the <id> field of the [BSP](https://github.com/Infineon?q=bsp-manifest&type=&language=&sort=) manifest | Required
`--app-path`   | Path of this local *psoc-spdm-responder* template to copy | Required
`--target-dir`| Specify the directory in which the application is to be created if you prefer not to use the default current working directory | Optional
`--user-app-name`| Specify the name of the application if you prefer to have a name other than the example's default name | Optional

</details>

> **Note:** The Project Creator copies the application and runs `make getlibs`
> to import the required libraries. For details, see the "Project creator tools"
> section of the
> [ModusToolbox&trade; tools package user guide](https://www.infineon.com/ModusToolboxUserGuide)
> (locally available at {ModusToolbox&trade; install directory}/docs_{version}/mtb_user_guide.pdf).


### 3. Open the project

After fetching the libraries, you can open the application in your preferred
development environment.

<details><summary><b>Eclipse IDE</b></summary>

Import the application into the Eclipse IDE for ModusToolbox&trade;. For more
details, see the
[Eclipse IDE for ModusToolbox&trade; user guide](https://www.infineon.com/MTBEclipseIDEUserGuide)
(locally available at *{ModusToolbox&trade; install directory}/docs_{version}/mt_ide_user_guide.pdf*).

</details>

<details><summary><b>Visual Studio (VS) Code</b></summary>

Launch VS Code manually, and then open the generated *{project-name}.code-workspace*
file located in the project directory.

For more details, see the
[Visual Studio Code for ModusToolbox&trade; user guide](https://www.infineon.com/MTBVSCodeUserGuide)
(locally available at *{ModusToolbox&trade; install directory}/docs_{version}/mt_vscode_user_guide.pdf*).

</details>

<details><summary><b>Command line</b></summary>

If you prefer to use the CLI, open the appropriate terminal, and navigate to the
project directory. On Windows, use the command-line 'modus-shell' program; on
Linux and macOS, you can use any terminal application. From there, you can run
various `make` commands.

For more details, see the
[ModusToolbox&trade; tools package user guide](https://www.infineon.com/ModusToolboxUserGuide)
(locally available at *{ModusToolbox&trade; install directory}/docs_{version}/mtb_user_guide.pdf*).

</details>


### 4. (KIT_PSC3M5_EVK only) Provision the device with the OEM policy

Connect the board to your PC using the provided USB cable. On KIT_PSC3M6_EVAL,
also connect the external MiniProg4 I2C bridge to the device (see
[Hardware setup](#hardware-setup)) — it carries the I2C host transport.

On KIT_PSC3M6_EVAL this step is **not** required: the secure/non-secure memory
split (SAU/MPC/PPC) is owned by the Device Configurator (*design.modus*) and
applied during `cybsp_init()`, so skip straight to building and programming.

On KIT_PSC3M5_EVK the device must be provisioned with a policy that configures
the correct secure/non-secure memory split (MPC) for this two-project
application. Helper scripts are provided.

From the *psoc-spdm-responder* directory, run the provisioning script with
modus-shell or Git Bash:

   ```
   sh scripts/provisioning.sh
   ```

To restore the device to its default configuration later, run:

   ```
   sh scripts/restore_provisioning.sh
   ```

> **Note:** If you change the application's memory map &mdash; the
> secure/non-secure split in *common.mk* / *proj_cm33_s/Makefile*, or the
> Provisioning Asset Store (PAS) region &mdash; update the MPC configuration in
> *ns_policy/policy_oem_provisioning.json* accordingly and re-provision the
> device. The PAS region must be mapped as secure by the MPC.


### 5. (KIT_PSC3M6_EVAL / KIT_PSC3M8_EVK only) Select the cipher profile

The image is built for exactly **one** cipher profile, fixed at build time by
the `SPDM_PROFILE` make variable in *common.mk*. Open *common.mk* and set it to
the profile you want:

   ```make
   # P1 = ECDSA/ECDHE P-256, SHA-256, SPDM up to 1.4
   # P2 = ECDSA/ECDHE P-384, SHA-384, SPDM up to 1.4
   # P3 = ECDSA/ECDHE P-521, SHA-512, SPDM up to 1.4
   # P4 = ML-DSA-87 / ML-KEM-1024, SHA-384, SPDM 1.4 (CNSA 2.0 PQC)
   SPDM_PROFILE ?= P4
   ```

Alternatively, pass it on the `make` command line in the next step, for example
`make program TARGET=APP_KIT_PSC3M6_EVAL SPDM_PROFILE=P4`. See
[Cipher profiles (`SPDM_PROFILE`)](#cipher-profiles-spdm_profile)
for the full profile matrix. Changing the profile requires a `make clean` first.

> **Note:** This step is **not applicable to KIT_PSC3M5_EVK**, which runs the
> classic profiles `P1`, `P2` and `P3` only (the PQC profile `P4` is
> PSC3M6/PSC3M8-only). Leave `SPDM_PROFILE` at its `P1` default on M5 unless you
> want `P2` or `P3`.


### 6. Build and program

Make sure board is connected. Build and program both projects together using one of the
following methods.

<details><summary><b>Using Eclipse IDE</b></summary>

   1. Select the application project in the Project Explorer.

   2. In the **Quick Panel**, click **\<Application Name> Program** to build and
      program the board.

   If required, in the **Quick Panel**, scroll down, and click **Build Application** to
   only build the firmware. Similary, you can use **Clean Application** to remove the
   build output
</details>

<details><summary><b>Using CLI</b></summary>

   From the application directory, execute the `make program` command to build
   and program both projects using the default toolchain to the default target:
   ```
   make program TOOLCHAIN=GCC_ARM
   ```

   The top-level Makefile builds and programs both the secure (`proj_cm33_s`) and
   non-secure (`proj_cm33_ns`) projects. Use `make build TOOLCHAIN=GCC_ARM` to
   build without programming, and `make clean` to remove build output.
</details>




### 7. (Optional) Observe the output

Open a terminal program and select the kit's COM port (KitProg3 on
KIT_PSC3M5_EVK and KIT_PSC3M8_EVK, J-Link virtual COM on KIT_PSC3M6_EVAL). Set
the serial port parameters to 8N1 and 115200 baud to view firmware log output.

On that COM port the non-secure app logs its startup
banner and the application version, the secure NSC ABI version (confirming the
non-secure&rarr;secure call path), the linked libspdm module version, and the
bring-up progress of the DFU middleware, SPDM router, SPDM responder, and I2C
transport. Once running, the user LED toggles as an idle heartbeat while the
device waits for host commands.


### 8. Exercise the SPDM capabilities

With the device provisioned, programmed, and waiting for host commands, use the
companion **SPDM Requester** host tool (`spdm-requester.exe`) to drive the
device over the I2C bridge (on-board KitProg3 on M5 and M8, external MiniProg4
on M6) and try out the SPDM capabilities &mdash;
identity/authenticity, measurements, and secure session (for example
`challenge`, `session`, and `exchange`).


## Related resources

Resources  | Links
-----------|----------------------------------
Application notes  | [AN238329](https://www.infineon.com/cms/en/product/microcontroller/32-bit-psoc-arm-cortex-microcontroller/32-bit-psoc-control-arm-cortex-m33-mcu/psoc-control-c3m/#!documents) &ndash; Getting started with PSOC&trade; Control C3 MCU on ModusToolbox&trade; software
Device documentation | [PSOC&trade; Control C3 MCU documents](https://www.infineon.com/cms/en/product/microcontroller/32-bit-psoc-arm-cortex-microcontroller/32-bit-psoc-control-arm-cortex-m33-mcu/psoc-control-c3m/#!documents)
SPDM | [DMTF libspdm](https://github.com/DMTF/libspdm) &middot; [DSP0274 SPDM specification](https://www.dmtf.org/standards/spdm)
Libraries on GitHub  | [mtb-pdl-cat1](https://github.com/Infineon/mtb-pdl-cat1) &ndash; Peripheral Driver Library (PDL) <br> [mtb-hal-psc3](https://github.com/Infineon/mtb-hal-psc3) &ndash; Hardware Abstraction Layer (HAL) Library <br> [retarget-io](https://github.com/Infineon/retarget-io) &ndash; Retarget STDIO to a UART port <br> [dfu](https://github.com/Infineon/dfu) &ndash; Device Firmware Update Middleware (DFU MW)
Tools  | [ModusToolbox&trade;](https://www.infineon.com/modustoolbox)

<br>


## Other resources

Infineon provides a wealth of data at [www.infineon.com](https://www.infineon.com) to help you select the right device, and quickly and effectively integrate it into your design.


## Document history

 Version | Description of change
 ------- | ---------------------
 1.0.0   | Initial SPDM Responder device application documentation
 1.1.0   | Memory optimization
 2.0.0   | Support KIT_PSC3M6_EVAL at parity with KIT_PSC3M5_EVK
 3.0.0   | Add CNSA 2.0 PQC suite (SPDM 1.4, ML-DSA-87 / ML-KEM-1024 / SHA-384) selectable via `SPDM_SIG_SUITE`; libspdm updated to 4.0.0-rc
 4.0.0   | Add support for KIT_PSC3M8_EVK (tracks KIT_PSC3M6_EVAL; classic and cnsa2 suites)
 4.1.0   | Restructure cipher suites as composable build-time profiles under *profiles/&lt;name&gt;/*; rename the `SPDM_SIG_SUITE` make variable to `SPDM_PROFILE`; rename the shipped profiles to `P1` (was `classic`) and `P2` (was `cnsa2`)
 5.0.0   | Extend the classic profile family with higher-strength elliptic curves: add `P2` (ECDSA/ECDHE P-384, SHA-384) and `P3` (ECDSA/ECDHE P-521, SHA-512), renumber the PQC profile to `P4` (was `P2`)
<br>


All referenced product or service names and trademarks are the property of their respective owners.

The Bluetooth&reg; word mark and logos are registered trademarks owned by Bluetooth SIG, Inc., and any use of such marks by Infineon is under license.

PSOC&trade;, formerly known as PSoC&trade;, is a trademark of Infineon Technologies. Any references to PSoC&trade; in this document or others shall be deemed to refer to PSOC&trade;.

---------------------------------------------------------

(c) 2026, Infineon Technologies AG, or an affiliate of Infineon Technologies AG. All rights reserved.
This software, associated documentation and materials ("Software") is owned by Infineon Technologies AG or one of its affiliates ("Infineon") and is protected by and subject to worldwide patent protection, worldwide copyright laws, and international treaty provisions. Therefore, you may use this Software only as provided in the license agreement accompanying the software package from which you obtained this Software. If no license agreement applies, then any use, reproduction, modification, translation, or compilation of this Software is prohibited without the express written permission of Infineon.
<br>
Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A SPECIFIC USE/PURPOSE OR MERCHANTABILITY. Infineon reserves the right to make changes to the Software without notice. You are responsible for properly designing, programming, and testing the functionality and safety of your intended application of the Software, as well as complying with any legal requirements related to its use. Infineon does not guarantee that the Software will be free from intrusion, data theft or loss, or other breaches ("Security Breaches"), and Infineon shall have no liability arising out of any Security Breaches. Unless otherwise explicitly approved by Infineon, the Software may not be used in any application where a failure of the Product or any consequences of the use thereof can reasonably be expected to result in personal injury.
