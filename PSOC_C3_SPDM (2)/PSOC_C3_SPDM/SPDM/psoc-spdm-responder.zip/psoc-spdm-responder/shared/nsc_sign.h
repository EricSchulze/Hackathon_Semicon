/*****************************************************************************
 * File Name        : nsc_sign.h
 *
 * Description      : Non-Secure-Callable (NSC) contract for device-identity
 *                    signing in the SPDM Responder.
 *
 *                    libspdm (non-secure) asks the responder to sign challenge
 *                    and measurement transcripts with the device identity key.
 *                    That key is provisioned into PAS slot 0 in AES-GCM-wrapped
 *                    form and may only be unwrapped inside the SPE, so the
 *                    signing operation is exposed here as a single hardened
 *                    veneer: the non-secure world passes the message (or its
 *                    hash) and a signature buffer, and receives only the raw
 *                    ECDSA signature (R||S) over the profile's curve. The
 *                    private key never leaves the secure world.
 *
 *                    This contract is deliberately separate from the generic
 *                    PSA-shaped crypto contract (nsc_psa.h): it is an
 *                    application-specific identity operation, not a generic
 *                    primitive, and it reads a provisioned asset (PAS slot 0)
 *                    rather than taking key material as an argument.
 *
 *                    The signing operands exceed the four-register CMSE
 *                    argument limit, so they are marshalled through a single
 *                    parameter block passed by pointer.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef NSC_SIGN_H
#define NSC_SIGN_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "profile.h"  /* SPDM_HAVE_* capability flags + ECDSA device-key geometry */

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Macros / Types
 *****************************************************************************/

/* Raw ECDSA signature size (R||S), derived from the device-key curve:
 * 64 (P-256), 96 (P-384), 132 (P-521). Defined only for an ECDSA device key. */
#if SPDM_HAVE_ECDSA
#define NSC_SIGN_ECDSA_SIG_SIZE         (2U * SPDM_DEV_EC_BYTES)
#endif

/* Raw ML-DSA-87 signature size (FIPS 204, category 5). Used by profiles with
 * SPDM_HAVE_MLDSA87. */
#define NSC_SIGN_MLDSA87_SIG_SIZE       (4627U)

/* Function return status; value-compatible with psa_status_t (0 == success). */
typedef int32_t nsc_sign_status_t;

#define NSC_SIGN_SUCCESS                ((nsc_sign_status_t)0)     /* PSA_SUCCESS */
#define NSC_SIGN_ERROR_INVALID_ARGUMENT ((nsc_sign_status_t)-135)  /* PSA_ERROR_INVALID_ARGUMENT */

/**
 * Parameter block for nsc_device_sign().
 *
 * is_data_hash mirrors libspdm's convention (ECDSA sign path only):
 *   is_data_hash == true  -> message is the raw data to be hashed then signed.
 *   is_data_hash == false -> message is the pre-computed digest to be signed.
 *
 * context / context_size carry the ML-DSA (FIPS 204) signing context used by
 * profiles with SPDM_HAVE_MLDSA87: the SPE signs the message buffer
 * directly with this context (the per-op-code SPDM signing-context string, e.g.
 * SPDM_CHALLENGE_AUTH_SIGN_CONTEXT), matching how a libspdm requester verifies
 * an ML-DSA signature. For the ECDSA sign path they are unused and MUST be
 * set to { NULL, 0 }.
 */
typedef struct {
    bool           is_data_hash;
    const uint8_t *message;
    size_t         message_size;
    uint8_t       *signature;
    size_t         signature_cap;
    size_t        *signature_size;  /* in/out: capacity in, bytes written out */
    const uint8_t *context;         /* ML-DSA signing context; NULL for ECDSA   */
    size_t         context_size;    /* context length; 0 for ECDSA              */
} nsc_sign_params_t;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Sign a message (or digest) with the device identity key (PAS slot 0).
 *
 * The wrapped private key is read from PAS slot 0, unwrapped, used once and
 * destroyed inside the SPE; only the raw ECDSA signature is returned.
 *
 * @param params  Parameter block (validated and copied into secure memory).
 * @return NSC_SIGN_SUCCESS on success, or a value-compatible PSA error code.
 */
nsc_sign_status_t nsc_device_sign(const nsc_sign_params_t *params);

#if defined(__cplusplus)
}
#endif

#endif /* NSC_SIGN_H */

/* [] END OF FILE */
