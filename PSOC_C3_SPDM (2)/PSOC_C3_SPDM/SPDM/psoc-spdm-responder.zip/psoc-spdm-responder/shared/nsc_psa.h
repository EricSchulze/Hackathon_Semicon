/*****************************************************************************
 * File Name        : nsc_psa.h
 *
 * Description      : PSA-shaped crypto interface for the SPDM Responder
 *                    Non-Secure-Callable (NSC) boundary. This header is shared
 *                    between the secure application (which implements the NSC
 *                    veneers) and the non-secure application (which calls them).
 *
 *                    The crypto veneers are deliberately PSA-shaped: their
 *                    names, handle model and parameter types mirror the PSA
 *                    Crypto API so that a future migration to TF-M (whose NS
 *                    interface exposes the standard psa_* functions) is a
 *                    mechanical rename rather than a redesign. The boundary
 *                    therefore exposes GENERIC primitives -- a multipart hash
 *                    (psa_hash_* shape) and a one-call AEAD -- plus the RNG.
 *                    HMAC-SHA256 and HKDF-SHA256 are NOT veneers: PSA has no MAC
 *                    clone but the SPDM key schedule duplicates a partial HMAC
 *                    context, so they are reconstructed in the non-secure world
 *                    on top of the generic hash veneers (see
 *                    proj_cm33_ns/spdm/cryptlib/mac.c and kdf.c).
 *
 *                    Each veneer validates the non-secure caller's buffers with
 *                    cmse_check_address_range() before touching them and then
 *                    forwards to the secure PSA crypto service (see
 *                    proj_cm33_s/core/spdm_crypto.c). The device-key ECDSA sign,
 *                    the ECDHE key agreement and the persistent-key management
 *                    veneers (import/destroy) are added in a later stage.
 *
 *                    A streaming hash operation lives in the secure world and is
 *                    referenced across the boundary by an opaque non-zero handle
 *                    (nsc_psa_hash_op_t); the non-secure world never receives a
 *                    secure pointer.
 *
 *                    The scalar parameter types and constants below are
 *                    value-compatible with their PSA counterparts (each is
 *                    annotated with the PSA name it mirrors) so the non-secure
 *                    world stays free of any mbedTLS/PSA header dependency while
 *                    the TF-M port remains a straight typedef/name swap.
 *
 *                    The boundary-wide ABI version handshake lives in nsc.h.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef NSC_PSA_H
#define NSC_PSA_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "profile.h"  /* SPDM_HAVE_* capability flags for the selected profile */

#if defined(__cplusplus)
extern "C" {
#endif

/*---------------------------------------------------------------------------
 * PSA-compatible scalar types
 *
 * Each is value-compatible with the PSA Crypto type it mirrors, so migrating
 * the non-secure cryptlib to TF-M's psa_* interface is a typedef/name swap.
 *-------------------------------------------------------------------------*/

/* Function return status; mirrors psa_status_t (0 == PSA_SUCCESS). */
typedef int32_t  nsc_psa_status_t;

/* Algorithm identifier; mirrors psa_algorithm_t. */
typedef uint32_t nsc_psa_algorithm_t;

/* Opaque handle to a secure streaming hash operation. Value 0 is always
 * "no operation"; any non-zero value is a token into a secure operation pool.
 * Plays the role psa_hash_operation_t plays in a native PSA client. */
typedef int32_t  nsc_psa_hash_op_t;

/* Status values (value-compatible with the matching PSA_* codes). */
#define NSC_PSA_SUCCESS                 ((nsc_psa_status_t)0)      /* PSA_SUCCESS */
#define NSC_PSA_ERROR_INVALID_ARGUMENT  ((nsc_psa_status_t)-135)   /* PSA_ERROR_INVALID_ARGUMENT */

/* "No operation" hash handle. */
#define NSC_PSA_HASH_OP_NONE            ((nsc_psa_hash_op_t)0)

/* Algorithm constants actually used by the negotiated cipher suite. Values are
 * identical to the corresponding PSA_ALG_* macros. The secure hash gateway
 * forwards the algorithm verbatim to psa_hash_setup(), so adding a value here is
 * sufficient (no veneer/ABI change): a profile may use SHA-256, SHA-384 and/or
 * SHA-512. */
#define NSC_PSA_ALG_SHA_256             ((nsc_psa_algorithm_t)0x02000009U) /* PSA_ALG_SHA_256 */
#define NSC_PSA_ALG_SHA_384             ((nsc_psa_algorithm_t)0x0200000AU) /* PSA_ALG_SHA_384 */
#define NSC_PSA_ALG_SHA_512             ((nsc_psa_algorithm_t)0x0200000BU) /* PSA_ALG_SHA_512 */

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/*---------------------------------------------------------------------------
 * Random number generation -- mirrors psa_generate_random()
 *-------------------------------------------------------------------------*/

nsc_psa_status_t nsc_psa_generate_random(uint8_t *output, size_t output_size);

/*---------------------------------------------------------------------------
 * Multipart hash -- mirrors the psa_hash_* API
 *
 * setup() allocates a secure operation and returns its handle through *op;
 * update()/finish()/clone()/abort() take that handle by value. finish()
 * consumes the operation (its handle becomes stale). There is no one-shot
 * compute veneer: psa_hash_compute is just setup+update+finish, so the
 * non-secure world recomposes it from these primitives (this also keeps every
 * hash veneer within the four-register CMSE argument limit).
 *-------------------------------------------------------------------------*/

nsc_psa_status_t nsc_psa_hash_setup(nsc_psa_hash_op_t *op,
                                    nsc_psa_algorithm_t alg);
nsc_psa_status_t nsc_psa_hash_update(nsc_psa_hash_op_t op,
                                     const uint8_t *input, size_t input_size);
nsc_psa_status_t nsc_psa_hash_finish(nsc_psa_hash_op_t op, uint8_t *hash,
                                     size_t hash_size, size_t *hash_length);
nsc_psa_status_t nsc_psa_hash_clone(nsc_psa_hash_op_t src,
                                    nsc_psa_hash_op_t *dst);
nsc_psa_status_t nsc_psa_hash_abort(nsc_psa_hash_op_t op);

/*---------------------------------------------------------------------------
 * AES-GCM AEAD (one call per record)
 *
 * The negotiated suite fixes the primitive to AES-GCM, so the key material is
 * passed as raw bytes and imported/destroyed inside the secure call (the
 * per-call volatile-key lifetime agreed for this design). The tag is produced
 * / consumed in a buffer separate from the payload, matching the libspdm
 * cryptlib contract; the secure side uses the PSA multipart AEAD internally to
 * keep the tag separate without a payload-sized bounce buffer. Under TF-M this
 * one call is re-expressed as psa_import_key + psa_aead_* + psa_destroy_key in
 * proj_cm33_ns/spdm/cryptlib/aead.c.
 *
 * A GCM record has far more operands than the four core registers a
 * Non-Secure-Callable gateway may use, so the operands are marshalled through a
 * single parameter block passed by pointer (the only argument). The secure
 * veneer validates the block pointer, copies it into secure memory, then
 * validates each buffer pointer it contains before use.
 *-------------------------------------------------------------------------*/

/* Parameter block for nsc_psa_aead_encrypt. */
typedef struct {
    const uint8_t *key;
    size_t         key_size;
    const uint8_t *iv;
    size_t         iv_size;
    const uint8_t *a_data;
    size_t         a_data_size;
    const uint8_t *data_in;
    size_t         data_in_size;
    uint8_t       *tag_out;
    size_t         tag_size;
    uint8_t       *data_out;
    size_t        *data_out_size;  /* in/out: capacity in, bytes written out */
} nsc_psa_aead_encrypt_params_t;

/* Parameter block for nsc_psa_aead_decrypt (tag is an input here). */
typedef struct {
    const uint8_t *key;
    size_t         key_size;
    const uint8_t *iv;
    size_t         iv_size;
    const uint8_t *a_data;
    size_t         a_data_size;
    const uint8_t *data_in;
    size_t         data_in_size;
    const uint8_t *tag;
    size_t         tag_size;
    uint8_t       *data_out;
    size_t        *data_out_size;  /* in/out: capacity in, bytes written out */
} nsc_psa_aead_decrypt_params_t;

nsc_psa_status_t nsc_psa_aead_encrypt(const nsc_psa_aead_encrypt_params_t *params);

nsc_psa_status_t nsc_psa_aead_decrypt(const nsc_psa_aead_decrypt_params_t *params);

#if SPDM_HAVE_ECDHE
/*---------------------------------------------------------------------------
 * Ephemeral ECDHE key agreement (P-256/P-384/P-521) -- mirrors
 * psa_key_agreement / psa_raw_key_agreement over a secure context pool.
 *
 * new()      allocates a secure context, returning an opaque handle through
 *            *op (never a secure pointer).
 * generate() creates the ephemeral key pair and exports the raw public point
 *            (X||Y, NSC_PSA_EC_PUB_LEN bytes).
 * compute()  runs ECDH against the peer's raw public point and returns the raw
 *            shared secret (NSC_PSA_EC_SECRET_LEN bytes). Its operands exceed
 *            the four-register CMSE limit, so they are marshalled through a
 *            single parameter block passed by pointer.
 * free()     destroys the ephemeral key and releases the context.
 *-------------------------------------------------------------------------*/

/* EC boundary sizes, derived from the profile's ECDHE curve: P-256 -> 64/32,
 * P-384 -> 96/48, P-521 -> 132/66. */
#define NSC_PSA_EC_PUB_LEN              (2U * SPDM_KEX_EC_BYTES) /* raw public point X||Y */
#define NSC_PSA_EC_SECRET_LEN           (SPDM_KEX_EC_BYTES)      /* ECDH shared secret    */

/* Opaque handle to a secure ephemeral-EC context. Value 0 == "no operation". */
typedef int32_t  nsc_psa_ec_op_t;

#define NSC_PSA_EC_OP_NONE              ((nsc_psa_ec_op_t)0)

/* Parameter block for nsc_psa_ec_compute. */
typedef struct {
    nsc_psa_ec_op_t op;
    const uint8_t  *peer_public;
    size_t          peer_public_size;
    uint8_t        *secret;
    size_t          secret_cap;
    size_t         *secret_size;   /* in/out: capacity in, bytes written out */
} nsc_psa_ec_compute_params_t;

nsc_psa_status_t nsc_psa_ec_new(nsc_psa_ec_op_t *op);
nsc_psa_status_t nsc_psa_ec_generate(nsc_psa_ec_op_t op, uint8_t *public_key,
                                     size_t public_key_cap,
                                     size_t *public_key_size);
nsc_psa_status_t nsc_psa_ec_compute(const nsc_psa_ec_compute_params_t *params);
nsc_psa_status_t nsc_psa_ec_free(nsc_psa_ec_op_t op);
#endif /* SPDM_HAVE_ECDHE */

#if SPDM_HAVE_MLKEM1024
/*---------------------------------------------------------------------------
 * ML-KEM-1024 encapsulation (FIPS 203) -- CNSA 2.0 key establishment.
 *
 * The Responder is the KEM encapsulator in the CNSA 2.0 SPDM KEY_EXCHANGE. The
 * secure side decodes the requester's raw public encapsulation key, runs one
 * encapsulate, and returns the ciphertext plus the shared secret; the whole
 * wolfCrypt key/working set is transient and never leaves the SPE. There is no
 * context handle: a single stateless call mirrors the responder-only usage
 * (no key generation, no decapsulation on this side). Its operands exceed the
 * four-register CMSE limit, so they are marshalled through one parameter block
 * passed by pointer. Only present when SPDM_HAVE_MLKEM1024 is enabled.
 *-------------------------------------------------------------------------*/

/* ML-KEM-1024 sizes at the boundary (FIPS 203, category 5). */
#define NSC_PSA_MLKEM1024_PUB_LEN       (1568U) /* peer encapsulation key     */
#define NSC_PSA_MLKEM1024_CT_LEN        (1568U) /* ciphertext                 */
#define NSC_PSA_MLKEM1024_SS_LEN        (32U)   /* shared secret              */

/* Parameter block for nsc_psa_mlkem_encapsulate. */
typedef struct {
    const uint8_t *peer_encap_key;
    size_t         peer_encap_key_size;
    uint8_t       *cipher_text;
    size_t         cipher_text_cap;
    size_t        *cipher_text_size;    /* in/out: capacity in, bytes out    */
    uint8_t       *shared_secret;
    size_t         shared_secret_cap;
    size_t        *shared_secret_size;  /* in/out: capacity in, bytes out    */
} nsc_psa_mlkem_encapsulate_params_t;

nsc_psa_status_t nsc_psa_mlkem_encapsulate(
    const nsc_psa_mlkem_encapsulate_params_t *params);
#endif /* SPDM_HAVE_MLKEM1024 */

#if defined(__cplusplus)
}
#endif

#endif /* NSC_PSA_H */
