/*****************************************************************************
 * File Name        : nsc_meas.h
 *
 * Description      : Non-Secure-Callable (NSC) contract for SPDM measurement
 *                    sourcing in the SPDM Responder.
 *
 *                    The non-secure libspdm responder must answer
 *                    GET_MEASUREMENTS and embed a measurement_summary_hash in
 *                    CHALLENGE_AUTH / KEY_EXCHANGE_RSP. To keep the measured
 *                    state trustworthy, the raw measurement values, the
 *                    assembled DMTF measurement record, and the measurement
 *                    summary hash are all produced INSIDE the secure world
 *                    (SPE) rather than in the non-secure application:
 *
 *                      - nsc_get_measurement_record() serialises the DMTF
 *                        measurement block(s) requested by index and hands the
 *                        bytes back for the non-secure world to transport.
 *                      - nsc_get_measurement_summary() builds the record
 *                        internally, selects the requested subset (TCB / all)
 *                        and returns ONLY the hash. A compromised non-secure
 *                        world therefore cannot forge the signed summary hash,
 *                        because it never assembles or hashes the record.
 *
 *                    The negotiated SPDM hash algorithms are passed across the
 *                    boundary (base_hash_algo for the summary hash,
 *                    measurement_hash_algo for the digest blocks) so the secure
 *                    world hashes with the negotiated algorithm rather than a
 *                    hard-coded one.
 *
 *                    This header is only the boundary ABI -- status codes,
 *                    parameter blocks and prototypes. The measurement values
 *                    come from the secure provider (core/spdm_meas) and the
 *                    DMTF measurement-block wire layout is framed privately in
 *                    the secure veneer (nsc/nsc_meas.c); neither is exposed
 *                    here, so the non-secure world sees only opaque record
 *                    bytes and the summary hash.
 *
 *                    Both operations exceed the four-register CMSE argument
 *                    limit, so each is marshalled through a single parameter
 *                    block passed by pointer.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef NSC_MEAS_H
#define NSC_MEAS_H

#include <stddef.h>
#include <stdint.h>

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Status codes
 *****************************************************************************/

/* Function return status; value-compatible with psa_status_t (0 == success). */
typedef int32_t nsc_meas_status_t;

#define NSC_MEAS_SUCCESS                ((nsc_meas_status_t)0)      /* PSA_SUCCESS */
#define NSC_MEAS_ERROR_GENERIC          ((nsc_meas_status_t)-132)   /* PSA_ERROR_GENERIC_ERROR */
#define NSC_MEAS_ERROR_NOT_SUPPORTED    ((nsc_meas_status_t)-134)   /* PSA_ERROR_NOT_SUPPORTED */
#define NSC_MEAS_ERROR_INVALID_ARGUMENT ((nsc_meas_status_t)-135)   /* PSA_ERROR_INVALID_ARGUMENT */
#define NSC_MEAS_ERROR_BUFFER_TOO_SMALL ((nsc_meas_status_t)-138)   /* PSA_ERROR_BUFFER_TOO_SMALL */
#define NSC_MEAS_ERROR_DOES_NOT_EXIST   ((nsc_meas_status_t)-140)   /* PSA_ERROR_DOES_NOT_EXIST */

/******************************************************************************
 * Parameter blocks
 *****************************************************************************/

/**
 * Parameter block for nsc_get_measurement_record().
 *
 * measurement_index selects the operation:
 *   0x00       -> write nothing to @record; report the block count in
 *                 @block_count and set *@record_size to 0.
 *   0xFF       -> serialise every block into @record.
 *   1 .. count -> serialise that single block.
 */
typedef struct {
    uint32_t measurement_hash_algo;  /* negotiated SPDM measurement hash id */
    uint8_t  measurement_index;      /* 0x00 count, 0xFF all, else single */
    uint8_t *record;                 /* non-secure destination buffer */
    size_t   record_cap;             /* capacity of @record in bytes */
    size_t  *record_size;            /* out: bytes written to @record */
    uint8_t *block_count;            /* out: total number of blocks */
} nsc_meas_record_params_t;

/**
 * Parameter block for nsc_get_measurement_summary().
 *
 * The secure world assembles the full record internally, selects the subset
 * named by @summary_type and returns only the resulting hash.
 */
typedef struct {
    uint32_t base_hash_algo;         /* negotiated SPDM base hash id (summary) */
    uint32_t measurement_hash_algo;  /* negotiated SPDM measurement hash id */
    uint8_t  summary_type;           /* 0x01 TCB subset, 0xFF all */
    uint8_t *summary_hash;           /* non-secure destination buffer */
    size_t   summary_cap;            /* capacity of @summary_hash in bytes */
    size_t  *summary_size;           /* out: bytes written to @summary_hash */
} nsc_meas_summary_params_t;

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Serialise the requested DMTF measurement record block(s).
 *
 * The secure world owns the measurement policy: it builds each block, computing
 * the digest blocks with the negotiated measurement hash algorithm, and copies
 * the requested bytes into the caller's non-secure buffer.
 *
 * @param params  Parameter block (validated and copied into secure memory).
 * @return NSC_MEAS_SUCCESS on success;
 *         NSC_MEAS_ERROR_INVALID_ARGUMENT for an unusable pointer/argument;
 *         NSC_MEAS_ERROR_NOT_SUPPORTED if the hash algorithm is not supported;
 *         NSC_MEAS_ERROR_DOES_NOT_EXIST if the index names no block;
 *         NSC_MEAS_ERROR_BUFFER_TOO_SMALL if @record is too small.
 */
nsc_meas_status_t nsc_get_measurement_record(const nsc_meas_record_params_t *params);

/**
 * @brief Compute the SPDM measurement summary hash inside the secure world.
 *
 * The record is assembled and hashed entirely in the SPE, so the non-secure
 * world cannot influence the value that is later signed.
 *
 * @param params  Parameter block (validated and copied into secure memory).
 * @return NSC_MEAS_SUCCESS on success;
 *         NSC_MEAS_ERROR_INVALID_ARGUMENT for an unusable pointer/argument;
 *         NSC_MEAS_ERROR_NOT_SUPPORTED if a hash algorithm is not supported;
 *         NSC_MEAS_ERROR_BUFFER_TOO_SMALL if @summary_hash is too small;
 *         NSC_MEAS_ERROR_GENERIC on an internal hashing failure.
 */
nsc_meas_status_t nsc_get_measurement_summary(const nsc_meas_summary_params_t *params);

#if defined(__cplusplus)
}
#endif

#endif /* NSC_MEAS_H */

/* [] END OF FILE */
