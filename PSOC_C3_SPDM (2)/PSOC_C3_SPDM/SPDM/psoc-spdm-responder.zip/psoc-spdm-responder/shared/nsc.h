/*****************************************************************************
 * File Name        : nsc.h
 *
 * Description      : Boundary-wide interface for the SPDM Responder
 *                    Non-Secure-Callable (NSC) trust boundary. This header is
 *                    shared between the secure application (which implements the
 *                    veneers) and the non-secure application (which calls them).
 *
 *                    It carries the concerns that span the WHOLE NS <-> S seam
 *                    rather than any single veneer family: currently just the
 *                    ABI version handshake. Domain-specific contracts live in
 *                    their own headers -- the PSA-shaped crypto veneers are in
 *                    nsc_psa.h, and the device-key sign / cert-chain read
 *                    veneers (added in later stages) get their own siblings.
 *                    All of them share the single monotonic ABI version defined
 *                    here.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef NSC_H
#define NSC_H

#include <stdint.h>

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Macros
 *****************************************************************************/

/* Version of the SPDM Responder NSC boundary ABI. This is one monotonic number
 * for the ENTIRE NS <-> S seam (crypto today, device-key sign and cert-chain
 * reads later); bump it whenever the set or signatures of any exported veneer
 * change. The non-secure and secure images are linked separately, so the value
 * lets bring-up confirm both halves agree.
 *   0x0001 - baseline: version-query veneer only.
 *   0x0002 - added cryptlib-shaped crypto veneers (RNG, SHA-256, HMAC-SHA256,
 *            HKDF-SHA256, AES-GCM AEAD).
 *   0x0003 - PSA-shaped crypto veneers: generic multipart hash (psa_hash_*
 *            shape) + one-call AEAD + RNG (see nsc_psa.h). HMAC/HKDF moved to
 *            the non-secure world; the algorithm-specific SHA-256/HMAC/HKDF
 *            veneers removed.
 *   0x0004 - added the device-identity ECDSA-P256 sign veneer (nsc_sign.h,
 *            reads PAS slot 0) and the ephemeral ECDHE-P256 key-agreement
 *            veneers (nsc_psa.h: ec_new/generate/compute/free).
 *   0x0005 - added the certificate-chain read veneer (nsc_cert.h,
 *            nsc_read_cert_chain, reads a PAS certificate slot) so the
 *            responder can serve the provisioned SPDM cert chain verbatim.
 *   0x0006 - added the measurement sourcing veneers (nsc_meas.h,
 *            nsc_get_measurement_record / nsc_get_measurement_summary) so the
 *            secure world assembles the DMTF measurement record and computes
 *            the measurement summary hash with the negotiated algorithm.
 *   0x0007 - extended the device-identity sign contract (nsc_sign.h): the
 *            parameter block gained an ML-DSA signing-context pointer/length so
 *            profiles with SPDM_HAVE_MLDSA87 can sign the SPDM
 *            transcript with ML-DSA-87. The ECDSA sign path leaves them { NULL, 0 }.
 *   0x0008 - added the ML-KEM-1024 encapsulate veneer (nsc_psa.h,
 *            nsc_psa_mlkem_encapsulate) so profiles with SPDM_HAVE_MLKEM1024 can
 *            establish the SPDM KEY_EXCHANGE shared secret in the SPE; other
 *            profiles do not export it. */
#define NSC_ABI_VERSION                 (0x0008U)

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Return the version of the SPDM Responder NSC boundary ABI.
 *
 * A Non-Secure-Callable veneer that lets the non-secure application confirm the
 * secure world is present and both images agree on the veneer ABI.
 *
 * @return NSC_ABI_VERSION.
 */
uint32_t nsc_get_abi_version(void);

#if defined(__cplusplus)
}
#endif

#endif /* NSC_H */
