/*****************************************************************************
 * File Name        : nsc_cert.h
 *
 * Description      : Non-Secure-Callable (NSC) contract for reading the SPDM
 *                    certificate chain from the Provisioning Asset Store (PAS).
 *
 *                    The SPDM certificate chain is provisioned into a PAS
 *                    certificate slot by the SEPARATE provisioning application
 *                    as a single, fully-formatted SPDM cert_chain buffer
 *                    (Length | Reserved | RootHash | certificates). The device
 *                    serves it VERBATIM for GET_CERTIFICATE and hashes it for
 *                    GET_DIGESTS; it never parses it. The chain is public key
 *                    material, so this veneer simply copies it out of the
 *                    secure PAS flash into a non-secure buffer for libspdm to
 *                    hand back over the wire.
 *
 *                    This contract is deliberately separate from the crypto
 *                    (nsc_psa.h) and device-sign (nsc_sign.h) contracts: it is
 *                    a read of a provisioned public asset, not a cryptographic
 *                    primitive or a private-key operation. All three share the
 *                    single monotonic ABI version in nsc.h.
 *
 * Related Document : See README.md and docs/implementation.md
 *
 *******************************************************************************
 * (c) 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * This software, associated documentation and materials ("Software") is
 * owned by Infineon Technologies AG or one of its affiliates ("Infineon")
 * and is protected by and subject to worldwide patent protection, worldwide
 * copyright laws, and international treaty provisions. Therefore, you may use
 * this Software only as provided in the license agreement accompanying the
 * software package from which you obtained this Software. If no license
 * agreement applies, then any use, reproduction, modification, translation, or
 * compilation of this Software is prohibited without the express written
 * permission of Infineon.
 *
 * Disclaimer: UNLESS OTHERWISE EXPRESSLY AGREED WITH INFINEON, THIS SOFTWARE
 * IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING, BUT NOT LIMITED TO, ALL WARRANTIES OF NON-INFRINGEMENT OF
 * THIRD-PARTY RIGHTS AND IMPLIED WARRANTIES SUCH AS WARRANTIES OF FITNESS FOR A
 * SPECIFIC USE/PURPOSE OR MERCHANTABILITY.
 * Infineon reserves the right to make changes to the Software without notice.
 * You are responsible for properly designing, programming, and testing the
 * functionality and safety of your intended application of the Software, as
 * well as complying with any legal requirements related to its use. Infineon
 * does not guarantee that the Software will be free from intrusion, data theft
 * or loss, or other breaches ("Security Breaches"), and Infineon shall have
 * no liability arising out of any Security Breaches. Unless otherwise
 * explicitly approved by Infineon, the Software may not be used in any
 * application where a failure of the Product or any consequences of the use
 * thereof can reasonably be expected to result in personal injury.
 *****************************************************************************/

#ifndef NSC_CERT_H
#define NSC_CERT_H

#include <stddef.h>
#include <stdint.h>

#if defined(__cplusplus)
extern "C" {
#endif

/******************************************************************************
 * Macros / Types
 *****************************************************************************/

/* Function return status; value-compatible with psa_status_t (0 == success). */
typedef int32_t nsc_cert_status_t;

#define NSC_CERT_SUCCESS                ((nsc_cert_status_t)0)      /* PSA_SUCCESS */
#define NSC_CERT_ERROR_INVALID_ARGUMENT ((nsc_cert_status_t)-135)   /* PSA_ERROR_INVALID_ARGUMENT */
#define NSC_CERT_ERROR_BUFFER_TOO_SMALL ((nsc_cert_status_t)-138)   /* PSA_ERROR_BUFFER_TOO_SMALL */
#define NSC_CERT_ERROR_DOES_NOT_EXIST   ((nsc_cert_status_t)-140)   /* PSA_ERROR_DOES_NOT_EXIST */

/******************************************************************************
 * Function Prototypes
 *****************************************************************************/

/**
 * @brief Copy the SPDM certificate chain from a PAS certificate slot.
 *
 * The slot must hold a valid certificate payload (a fully-formatted SPDM
 * cert_chain buffer). The payload is copied verbatim into the caller's
 * non-secure buffer; it is not parsed or validated beyond the PAS slot CRC.
 *
 * All four operands fit the CMSE four-register argument limit, so no parameter
 * block is required.
 *
 * @param slot_id  PAS slot index holding the certificate chain.
 * @param out      Destination buffer (non-secure).
 * @param out_cap  Capacity of @p out in bytes.
 * @param out_len  On success, receives the number of bytes copied.
 *
 * @return NSC_CERT_SUCCESS on success;
 *         NSC_CERT_ERROR_INVALID_ARGUMENT if a pointer is not wholly in
 *         non-secure memory with the required access;
 *         NSC_CERT_ERROR_DOES_NOT_EXIST if the slot holds no valid certificate;
 *         NSC_CERT_ERROR_BUFFER_TOO_SMALL if the payload exceeds @p out_cap.
 */
nsc_cert_status_t nsc_read_cert_chain(uint8_t slot_id, uint8_t *out,
                                      size_t out_cap, size_t *out_len);

#if defined(__cplusplus)
}
#endif

#endif /* NSC_CERT_H */

/* [] END OF FILE */
