#ifndef SPDM_PROFILE_SCHEMA_H
#define SPDM_PROFILE_SCHEMA_H

/******************************************************************************
 * SPDM profile schema -- the vocabulary a profile.h speaks.
 *
 * A "profile" is a build-time selection of the SPDM cipher suite, chosen by
 * include path: the build adds profiles/<name> to the include path and every
 * consumer does a fixed #include "profile.h". A profile.h defines just five
 * selectors from the tokens below; profile_derive.h expands them into the
 * SPDM_HAVE_* capability flags and ECDSA device-key geometry the implementation
 * consumes, and profile_check.h validates the selection.
 *
 * This header only declares the vocabulary; it selects nothing itself.
 *
 * ---- The five selectors a profile.h defines -------------------------------
 *
 *   SPDM_DEV_ID        device identity / asymmetric signature primitive:
 *                        SPDM_DEV_ID_ECDSA_P256   ECDSA over NIST P-256
 *                        SPDM_DEV_ID_ECDSA_P384   ECDSA over NIST P-384
 *                        SPDM_DEV_ID_ECDSA_P521   ECDSA over NIST P-521
 *                        SPDM_DEV_ID_MLDSA87      ML-DSA-87 / FIPS 204
 *   SPDM_BASE_HASH     transcript / key-schedule hash:
 *                        SPDM_HASH_SHA256 | SPDM_HASH_SHA384 | SPDM_HASH_SHA512
 *   SPDM_MEAS_HASH     measurement-block hash (same tokens as SPDM_BASE_HASH).
 *                      Optional; defaults to SPDM_BASE_HASH.
 *   SPDM_KEX           session key-exchange method:
 *                        SPDM_KEX_ECDHE_P256      ECDHE over NIST P-256
 *                        SPDM_KEX_ECDHE_P384      ECDHE over NIST P-384
 *                        SPDM_KEX_ECDHE_P521      ECDHE over NIST P-521
 *                        SPDM_KEX_MLKEM1024       ML-KEM-1024 / FIPS 203
 *   SPDM_AEAD_SUITE    session AEAD cipher:
 *                        SPDM_AEAD_AES256_GCM     AES-256-GCM
 *
 * ---- Derived (profile_derive.h -- a profile never defines these) ----------
 *
 *   SPDM_HAVE_ECDSA_P256 / _ECDSA_P384 / _ECDSA_P521 / _MLDSA87 / _ECDHE_P256 /
 *   _ECDHE_P384 / _ECDHE_P521 / _MLKEM1024 / _AES256_GCM / _SHA256 / _SHA384 /
 *   _SHA512 / _PSK   capability flags the libspdm config and crypto backends
 *     switch on; each expands to 0 or 1 from the selectors above. SPDM_HAVE_ECDSA
 *     and SPDM_HAVE_ECDHE aggregate the per-curve flags (any NIST-curve ECDSA /
 *     ECDHE) for the curve-agnostic machinery.
 *   SPDM_DEV_HASH_ALG / SPDM_DEV_EC_FAMILY / SPDM_DEV_EC_BITS / SPDM_DEV_EC_BYTES
 *     ECDSA device-key geometry, and SPDM_KEX_EC_FAMILY / SPDM_KEX_EC_BITS /
 *     SPDM_KEX_EC_BYTES the ECDHE key-exchange geometry, implied by SPDM_DEV_ID /
 *     SPDM_KEX and the pinned base hash. The PSA family/hash tokens expand only
 *     at the secure use site, so neither this header nor profile_derive.h
 *     includes <psa/crypto.h>; the *_BYTES lengths are plain integers.
 *****************************************************************************/

/* Selector token values are arbitrary distinct integers usable in preprocessor
 * #if comparisons; they are not the SPDM wire identifiers. */

/* SPDM_BASE_HASH / SPDM_MEAS_HASH */
#define SPDM_HASH_SHA256        256
#define SPDM_HASH_SHA384        384
#define SPDM_HASH_SHA512        512

/* SPDM_DEV_ID -- classic (NIST-curve ECDSA) first, then PQC */
#define SPDM_DEV_ID_ECDSA_P256  1
#define SPDM_DEV_ID_ECDSA_P384  2
#define SPDM_DEV_ID_ECDSA_P521  3
#define SPDM_DEV_ID_MLDSA87     4

/* SPDM_KEX -- classic (NIST-curve ECDHE) first, then PQC */
#define SPDM_KEX_ECDHE_P256     1
#define SPDM_KEX_ECDHE_P384     2
#define SPDM_KEX_ECDHE_P521     3
#define SPDM_KEX_MLKEM1024      4

/* SPDM_AEAD_SUITE */
#define SPDM_AEAD_AES256_GCM    1

#endif /* SPDM_PROFILE_SCHEMA_H */
