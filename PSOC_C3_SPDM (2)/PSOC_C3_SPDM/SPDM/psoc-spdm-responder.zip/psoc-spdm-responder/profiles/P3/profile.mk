################################################################################
# \file profile.mk (P3)
#
# \brief
# Build-graph delta for the P3 SPDM profile. Included by common.mk when
# SPDM_PROFILE=P3. The P3 suite uses only the PSA / mbedTLS backend
# already present in the secure project, so there is no extra backend to pull
# in here.
################################################################################

# No post-quantum backend: the ECDSA/ECDHE P-521 device-sign path stays on
# PSA / mbedTLS and never links wolfCrypt.
SPDM_PROFILE_USES_WOLFCRYPT := 0
