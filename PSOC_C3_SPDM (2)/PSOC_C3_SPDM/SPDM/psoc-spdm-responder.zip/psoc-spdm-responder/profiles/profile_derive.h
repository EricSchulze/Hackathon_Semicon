#ifndef SPDM_PROFILE_DERIVE_H
#define SPDM_PROFILE_DERIVE_H

/******************************************************************************
 * SPDM profile derivation.
 *
 * Included by every profile.h after its five selectors, before profile_check.h.
 * Expands the selectors (SPDM_DEV_ID, SPDM_BASE_HASH, SPDM_MEAS_HASH,
 * SPDM_KEX, SPDM_AEAD_SUITE) into the SPDM_HAVE_* capability flags and
 * the ECDSA device-key geometry the implementation consumes, so a profile
 * states each choice exactly once. See profile_schema.h for the vocabulary.
 *****************************************************************************/

/* Measurement hash follows the base hash unless a profile pins it explicitly. */
#ifndef SPDM_MEAS_HASH
#define SPDM_MEAS_HASH SPDM_BASE_HASH
#endif

/* ---- Capability flags (each expands to 0 or 1) --------------------------- */

/* Signature */
#define SPDM_HAVE_ECDSA_P256    (SPDM_DEV_ID == SPDM_DEV_ID_ECDSA_P256)
#define SPDM_HAVE_ECDSA_P384    (SPDM_DEV_ID == SPDM_DEV_ID_ECDSA_P384)
#define SPDM_HAVE_ECDSA_P521    (SPDM_DEV_ID == SPDM_DEV_ID_ECDSA_P521)
#define SPDM_HAVE_MLDSA87       (SPDM_DEV_ID == SPDM_DEV_ID_MLDSA87)

/* Any NIST-curve ECDSA device key -- gates the curve-agnostic sign machinery. */
#define SPDM_HAVE_ECDSA \
    (SPDM_HAVE_ECDSA_P256 || SPDM_HAVE_ECDSA_P384 || SPDM_HAVE_ECDSA_P521)

/* Key exchange */
#define SPDM_HAVE_ECDHE_P256    (SPDM_KEX == SPDM_KEX_ECDHE_P256)
#define SPDM_HAVE_ECDHE_P384    (SPDM_KEX == SPDM_KEX_ECDHE_P384)
#define SPDM_HAVE_ECDHE_P521    (SPDM_KEX == SPDM_KEX_ECDHE_P521)
#define SPDM_HAVE_MLKEM1024     (SPDM_KEX == SPDM_KEX_MLKEM1024)

/* Any NIST-curve ECDHE key agreement -- gates the curve-agnostic KEX machinery. */
#define SPDM_HAVE_ECDHE \
    (SPDM_HAVE_ECDHE_P256 || SPDM_HAVE_ECDHE_P384 || SPDM_HAVE_ECDHE_P521)

/* AEAD */
#define SPDM_HAVE_AES256_GCM    (SPDM_AEAD_SUITE == SPDM_AEAD_AES256_GCM)

/* A hash primitive is enabled if either the base or the measurement hash uses it. */
#define SPDM_HAVE_SHA256 \
    ((SPDM_BASE_HASH == SPDM_HASH_SHA256) || (SPDM_MEAS_HASH == SPDM_HASH_SHA256))
#define SPDM_HAVE_SHA384 \
    ((SPDM_BASE_HASH == SPDM_HASH_SHA384) || (SPDM_MEAS_HASH == SPDM_HASH_SHA384))
#define SPDM_HAVE_SHA512 \
    ((SPDM_BASE_HASH == SPDM_HASH_SHA512) || (SPDM_MEAS_HASH == SPDM_HASH_SHA512))

/* Pre-shared key is unused in every profile. */
#define SPDM_HAVE_PSK           0

/* ---- ECDSA device-key geometry ------------------------------------------- *
 * Implied by SPDM_DEV_ID (the curve) and the pinned base hash: the ECDSA
 * signature is taken over the transcript hash, so the signature hash is always
 * the negotiated base hash. PSA family/hash tokens are emitted as bare
 * identifiers, evaluated only at the secure use site (which includes
 * <psa/crypto.h>), so this header does not include it; SPDM_DEV_EC_BYTES is a
 * plain integer (coordinate / scalar length) usable anywhere. */
#if SPDM_HAVE_ECDSA

#if SPDM_BASE_HASH == SPDM_HASH_SHA256
#define SPDM_DEV_HASH_ALG   PSA_ALG_SHA_256
#elif SPDM_BASE_HASH == SPDM_HASH_SHA384
#define SPDM_DEV_HASH_ALG   PSA_ALG_SHA_384
#elif SPDM_BASE_HASH == SPDM_HASH_SHA512
#define SPDM_DEV_HASH_ALG   PSA_ALG_SHA_512
#endif

#define SPDM_DEV_EC_FAMILY  PSA_ECC_FAMILY_SECP_R1

#if SPDM_HAVE_ECDSA_P256
#define SPDM_DEV_EC_BITS    256
#elif SPDM_HAVE_ECDSA_P384
#define SPDM_DEV_EC_BITS    384
#elif SPDM_HAVE_ECDSA_P521
#define SPDM_DEV_EC_BITS    521
#endif

/* Coordinate / scalar length in bytes (ceil(bits / 8)): 32 (P-256), 48 (P-384),
 * 66 (P-521). The raw public point is X||Y (2 * bytes) and the ECDSA signature
 * is R||S (2 * bytes). */
#define SPDM_DEV_EC_BYTES   (((SPDM_DEV_EC_BITS) + 7) / 8)

#endif /* SPDM_HAVE_ECDSA */

/* ---- ECDHE key-exchange geometry ----------------------------------------- *
 * The ephemeral key-agreement curve, implied by SPDM_KEX. The EC context pool
 * in the secure crypto service is always compiled (even for a pure-PQC KEX
 * profile, where it is unused), so the geometry defaults to P-256 when no ECDHE
 * curve is selected. SPDM_KEX_EC_FAMILY is a bare PSA token (secure use site
 * only); SPDM_KEX_EC_BYTES is a plain integer. */
#define SPDM_KEX_EC_FAMILY  PSA_ECC_FAMILY_SECP_R1

#if SPDM_HAVE_ECDHE_P384
#define SPDM_KEX_EC_BITS    384
#elif SPDM_HAVE_ECDHE_P521
#define SPDM_KEX_EC_BITS    521
#else   /* ECDHE P-256, or no ECDHE curve selected (EC pool unused) */
#define SPDM_KEX_EC_BITS    256
#endif

#define SPDM_KEX_EC_BYTES   (((SPDM_KEX_EC_BITS) + 7) / 8)

#endif /* SPDM_PROFILE_DERIVE_H */
