#ifndef SPDM_PROFILE_H
#define SPDM_PROFILE_H

/******************************************************************************
 * P1 profile -- SPDM up to 1.4, ECDSA/ECDHE P-256, SHA-256, AES-256-GCM.
 *
 * Selected by SPDM_PROFILE=P1 (see common.mk); the build puts
 * profiles/P1 on the include path so consumers resolve this via
 * #include "profile.h". Vocabulary: ../profile_schema.h. Rules: ../profile_check.h.
 *****************************************************************************/

#include "../profile_schema.h"

#define SPDM_DEV_ID         SPDM_DEV_ID_ECDSA_P256
#define SPDM_BASE_HASH      SPDM_HASH_SHA256
#define SPDM_MEAS_HASH      SPDM_HASH_SHA256
#define SPDM_KEX            SPDM_KEX_ECDHE_P256
#define SPDM_AEAD_SUITE     SPDM_AEAD_AES256_GCM

#include "../profile_derive.h"
#include "../profile_check.h"

#endif /* SPDM_PROFILE_H */
