#ifndef SPDM_PROFILE_H
#define SPDM_PROFILE_H

/******************************************************************************
 * P2 profile -- CNSA 2.0: SPDM 1.4, ML-DSA-87 + ML-KEM-1024, SHA-384,
 * AES-256-GCM. Requires the wolfCrypt backend (PSC3M6 / PSC3M8 only).
 *
 * Selected by SPDM_PROFILE=P2 (see common.mk); the build puts
 * profiles/P2 on the include path so consumers resolve this via
 * #include "profile.h". Vocabulary: ../profile_schema.h. Rules: ../profile_check.h.
 *****************************************************************************/

#include "../profile_schema.h"

#define SPDM_DEV_ID         SPDM_DEV_ID_MLDSA87
#define SPDM_BASE_HASH      SPDM_HASH_SHA384
#define SPDM_MEAS_HASH      SPDM_HASH_SHA384
#define SPDM_KEX            SPDM_KEX_MLKEM1024
#define SPDM_AEAD_SUITE     SPDM_AEAD_AES256_GCM

#include "../profile_derive.h"
#include "../profile_check.h"

#endif /* SPDM_PROFILE_H */
