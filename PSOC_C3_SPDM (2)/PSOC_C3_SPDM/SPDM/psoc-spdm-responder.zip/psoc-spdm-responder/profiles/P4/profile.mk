################################################################################
# \file profile.mk (P2)
#
# \brief
# Build-graph delta for the CNSA 2.0 SPDM profile. Included by common.mk when
# SPDM_PROFILE=P2. Selects the wolfCrypt backend that provides ML-DSA-87
# signing and ML-KEM-1024 encapsulation; the secure project's Makefile wires
# the wolfCrypt sources/defines when SPDM_PROFILE_USES_WOLFCRYPT is 1. Supported
# on PSC3M6 / PSC3M8 only (enforced via SPDM_PROFILES_SUPPORTED in each
# platform's detect_platform.mk).
################################################################################

# Pull in the wolfCrypt (ifx-wolfcrypto) backend for the post-quantum primitives.
SPDM_PROFILE_USES_WOLFCRYPT := 1
