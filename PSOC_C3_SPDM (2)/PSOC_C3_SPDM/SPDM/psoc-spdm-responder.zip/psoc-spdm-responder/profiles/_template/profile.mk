################################################################################
# \file profile.mk (template)
#
# \brief
# Build-graph delta for a new SPDM profile -- copy this file alongside your
# profile.h (profiles/<your-name>/) and edit as needed. Included by common.mk
# when SPDM_PROFILE=<your-name>, after profile.h is selected on the include
# path. Carries only make-level build-graph choices (backend selection, extra
# sources/defines); the cipher-suite itself is declared by the five selectors
# in profile.h.
################################################################################

# Post-quantum backend selection.
#
# Set to 1 if the profile's signature or key-exchange primitive needs the
# wolfCrypt backend (ML-DSA / ML-KEM); the secure project's Makefile then wires
# the wolfCrypt sources/defines. Leave 0 for a suite served entirely by
# PSA / mbedTLS (ECDSA/ECDHE P-256, SHA-2, AES-GCM).
#
# A profile that sets this to 1 may only be built on a device whose
# platforms/<PLATFORM>/detect_platform.mk declares PLATFORM_SUPPORTS_WOLFCRYPT
# (the secure Makefile errors out otherwise), so also list the profile in that
# device's SPDM_PROFILES_SUPPORTED.
SPDM_PROFILE_USES_WOLFCRYPT := 0
