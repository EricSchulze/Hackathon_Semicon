#ifndef SPDM_PROFILE_H
#define SPDM_PROFILE_H

/******************************************************************************
 * SPDM profile template -- copy this directory to profiles/<your-name>/ and
 * edit the five selectors below to author a new cipher-suite profile.
 *
 * Selection is by include path: build with SPDM_PROFILE=<your-name> and the
 * build adds profiles/<your-name> to the include path; every consumer resolves
 * this file through a fixed #include "profile.h".
 *
 * Define exactly these five selectors (tokens are listed in
 * ../profile_schema.h); profile_derive.h expands them into the SPDM_HAVE_*
 * capability flags and ECDSA device-key geometry, and profile_check.h validates
 * the selection:
 *   - SPDM_DEV_ID        asymmetric signature primitive
 *   - SPDM_BASE_HASH     transcript hash
 *   - SPDM_MEAS_HASH     measurement hash (optional; defaults to SPDM_BASE_HASH)
 *   - SPDM_KEX           session key exchange
 *   - SPDM_AEAD_SUITE    session AEAD
 *
 * Also add a sibling profile.mk (build-graph delta, e.g. backend selection)
 * and list the profile name in each supporting platform's
 * platforms/<PLATFORM>/detect_platform.mk SPDM_PROFILES_SUPPORTED.
 *****************************************************************************/

#include "../profile_schema.h"

/* ---- Device identity / signature: SPDM_DEV_ID_ECDSA_P256 | SPDM_DEV_ID_MLDSA87 ---- */
#define SPDM_DEV_ID         SPDM_DEV_ID_ECDSA_P256

/* ---- Transcript hash: SPDM_HASH_SHA256 | SPDM_HASH_SHA384 ---- */
#define SPDM_BASE_HASH      SPDM_HASH_SHA256

/* ---- Measurement hash (optional; omit to default to SPDM_BASE_HASH) ---- */
/* #define SPDM_MEAS_HASH   SPDM_HASH_SHA256 */

/* ---- Key exchange: SPDM_KEX_ECDHE_P256 | SPDM_KEX_MLKEM1024 ---- */
#define SPDM_KEX            SPDM_KEX_ECDHE_P256

/* ---- AEAD: SPDM_AEAD_AES256_GCM ---- */
#define SPDM_AEAD_SUITE     SPDM_AEAD_AES256_GCM

#include "../profile_derive.h"
#include "../profile_check.h"

#endif /* SPDM_PROFILE_H */
