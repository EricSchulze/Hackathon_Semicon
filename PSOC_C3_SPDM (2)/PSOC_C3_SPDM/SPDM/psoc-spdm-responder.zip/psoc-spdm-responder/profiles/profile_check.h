#ifndef SPDM_PROFILE_CHECK_H
#define SPDM_PROFILE_CHECK_H

/******************************************************************************
 * SPDM profile validation.
 *
 * Included at the end of every profile.h, after the five selectors and
 * profile_derive.h. Rejects an invalid selection at compile time with a
 * #error. See profile_schema.h for the vocabulary these rules enforce.
 *****************************************************************************/

/* (1) Device identity / signature primitive. */
#if !defined(SPDM_DEV_ID)
#error "SPDM profile: SPDM_DEV_ID must be defined (SPDM_DEV_ID_ECDSA_P256/P384/P521 or SPDM_DEV_ID_MLDSA87)"
#elif (SPDM_DEV_ID != SPDM_DEV_ID_ECDSA_P256) && \
      (SPDM_DEV_ID != SPDM_DEV_ID_ECDSA_P384) && \
      (SPDM_DEV_ID != SPDM_DEV_ID_ECDSA_P521) && \
      (SPDM_DEV_ID != SPDM_DEV_ID_MLDSA87)
#error "SPDM profile: SPDM_DEV_ID must be SPDM_DEV_ID_ECDSA_P256/P384/P521 or SPDM_DEV_ID_MLDSA87"
#endif

/* (2) Base transcript hash. */
#if !defined(SPDM_BASE_HASH)
#error "SPDM profile: SPDM_BASE_HASH must be defined (SPDM_HASH_SHA256, SHA384 or SHA512)"
#elif (SPDM_BASE_HASH != SPDM_HASH_SHA256) && \
      (SPDM_BASE_HASH != SPDM_HASH_SHA384) && \
      (SPDM_BASE_HASH != SPDM_HASH_SHA512)
#error "SPDM profile: SPDM_BASE_HASH must be SPDM_HASH_SHA256, SPDM_HASH_SHA384 or SPDM_HASH_SHA512"
#endif

/* (3) Measurement hash (defaulted to the base hash by profile_derive.h). */
#if (SPDM_MEAS_HASH != SPDM_HASH_SHA256) && \
    (SPDM_MEAS_HASH != SPDM_HASH_SHA384) && \
    (SPDM_MEAS_HASH != SPDM_HASH_SHA512)
#error "SPDM profile: SPDM_MEAS_HASH must be SPDM_HASH_SHA256, SPDM_HASH_SHA384 or SPDM_HASH_SHA512"
#endif

/* (4) Session key exchange. */
#if !defined(SPDM_KEX)
#error "SPDM profile: SPDM_KEX must be defined (SPDM_KEX_ECDHE_P256/P384/P521 or SPDM_KEX_MLKEM1024)"
#elif (SPDM_KEX != SPDM_KEX_ECDHE_P256) && \
      (SPDM_KEX != SPDM_KEX_ECDHE_P384) && \
      (SPDM_KEX != SPDM_KEX_ECDHE_P521) && \
      (SPDM_KEX != SPDM_KEX_MLKEM1024)
#error "SPDM profile: SPDM_KEX must be SPDM_KEX_ECDHE_P256/P384/P521 or SPDM_KEX_MLKEM1024"
#endif

/* (5) Session AEAD. */
#if !defined(SPDM_AEAD_SUITE)
#error "SPDM profile: SPDM_AEAD_SUITE must be defined (SPDM_AEAD_AES256_GCM)"
#elif (SPDM_AEAD_SUITE != SPDM_AEAD_AES256_GCM)
#error "SPDM profile: SPDM_AEAD_SUITE must be SPDM_AEAD_AES256_GCM"
#endif

/* (6) ECDSA device-key geometry must have been derived (profile_derive.h). */
#if SPDM_HAVE_ECDSA
#if !defined(SPDM_DEV_HASH_ALG) || !defined(SPDM_DEV_EC_FAMILY) || \
    !defined(SPDM_DEV_EC_BITS) || !defined(SPDM_DEV_EC_BYTES)
#error "SPDM profile: ECDSA device-key geometry not derived; extend profile_derive.h for this profile"
#endif
#endif

#endif /* SPDM_PROFILE_CHECK_H */
